import React, { useState } from 'react';
import { CricketMatch } from '../types/cricket';
import { LiveMatches } from '../components/LiveMatches';
import { TodayMatches } from '../components/TodayMatches';
import { TomorrowMatches } from '../components/TomorrowMatches';
import { TomorrowSchedule } from '../components/TomorrowSchedule';
import { UpcomingMatches } from '../components/UpcomingMatches';
import { RecentResults } from '../components/RecentResults';
import { Radio, Calendar, CalendarDays, Flame, ChevronRight } from 'lucide-react';

interface HomeProps {
  liveMatches: CricketMatch[];
  todayMatches: CricketMatch[];
  tomorrowMatches: CricketMatch[];
  dayAfterMatches: CricketMatch[];
  upcomingMatches: CricketMatch[];
  recentResults: CricketMatch[];
  onViewScorecard: (match: CricketMatch) => void;
  onNavigateToTomorrow?: () => void;
}

export const Home: React.FC<HomeProps> = ({
  liveMatches,
  todayMatches,
  tomorrowMatches,
  dayAfterMatches,
  upcomingMatches,
  recentResults,
  onViewScorecard,
  onNavigateToTomorrow
}) => {
  const [activeSubView, setActiveSubView] = useState<'live-today' | 'tomorrow-schedule'>('live-today');

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      
      {/* Visual Stadium Hero Banner */}
      <div className="relative rounded-2xl overflow-hidden border border-slate-800 mb-6 bg-slate-900 shadow-2xl">
        <div className="absolute inset-0 z-0">
          <img
            src="/src/assets/images/cricvault_hero_stadium_1790268854182.jpg"
            alt="Cricket Stadium Floodlights"
            className="w-full h-full object-cover object-center opacity-30 mix-blend-luminosity scale-105 filter blur-[0.5px]"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-950/80 to-slate-950/40" />
        </div>

        <div className="relative z-10 p-6 sm:p-8 max-w-2xl">
          <div className="flex items-center gap-2 mb-3 text-xs text-emerald-400 font-semibold uppercase tracking-wider">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span>Real-Time Broadcast Scoreboard</span>
          </div>

          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-black text-white tracking-tight font-['Cabinet_Grotesk'] mb-2.5">
            Cric<span className="text-emerald-400">Vault</span> Live Arena
          </h1>
          
          <p className="text-slate-300 text-xs sm:text-sm leading-relaxed mb-4">
            Follow live scores, automatic date-based fixtures, detailed ball-by-ball scorecards, and genuine player performance across all international and domestic tournaments.
          </p>

          <div className="flex flex-wrap items-center gap-4 text-xs font-mono text-slate-300">
            <div className="flex items-center gap-1.5">
              <span className="text-emerald-400 font-bold">{liveMatches.length}</span>
              <span className="text-slate-400 font-sans">Live Matches</span>
            </div>
            <span className="text-slate-600">·</span>
            <div className="flex items-center gap-1.5">
              <span className="text-emerald-400 font-bold">{todayMatches.length}</span>
              <span className="text-slate-400 font-sans">Today's Fixtures</span>
            </div>
            <span className="text-slate-600">·</span>
            <div className="flex items-center gap-1.5">
              <span className="text-emerald-400 font-bold">{tomorrowMatches.length}</span>
              <span className="text-slate-400 font-sans">Tomorrow</span>
            </div>
            <span className="text-slate-600">·</span>
            <div className="flex items-center gap-1.5">
              <span className="text-teal-400 font-bold">{dayAfterMatches.length}</span>
              <span className="text-slate-400 font-sans">Day After</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Switcher: Live & Today vs Tomorrow Schedule */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-6 bg-slate-900/90 p-2 rounded-xl border border-slate-800">
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setActiveSubView('live-today')}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
              activeSubView === 'live-today'
                ? 'bg-emerald-500 text-slate-950 shadow-md font-black'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <Radio className="w-4 h-4" />
            <span>Live & Today</span>
            {liveMatches.length > 0 && (
              <span className="w-2 h-2 rounded-full bg-red-500 animate-ping ml-1" />
            )}
          </button>

          {/* Tomorrow Schedule button right next to Live & Today */}
          <button
            onClick={() => setActiveSubView('tomorrow-schedule')}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
              activeSubView === 'tomorrow-schedule'
                ? 'bg-emerald-500 text-slate-950 shadow-md font-black'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <CalendarDays className="w-4 h-4 text-emerald-400" />
            <span>Tomorrow Schedule</span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950 border border-emerald-700/60 text-emerald-300">
              Next 2 Days ({tomorrowMatches.length + dayAfterMatches.length})
            </span>
          </button>
        </div>

        {activeSubView === 'live-today' && (
          <button
            onClick={() => setActiveSubView('tomorrow-schedule')}
            className="text-xs text-emerald-400 hover:text-emerald-300 font-semibold flex items-center gap-1 px-3 py-1.5 rounded bg-slate-950 border border-slate-800 cursor-pointer ml-auto"
          >
            <span>View All Tomorrow Matches</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {activeSubView === 'tomorrow-schedule' ? (
        /* Full Tomorrow & Day After Tomorrow Schedule View */
        <TomorrowSchedule
          tomorrowMatches={tomorrowMatches}
          dayAfterMatches={dayAfterMatches}
          onViewScorecard={onViewScorecard}
        />
      ) : (
        /* Live & Today View with All Sections */
        <>
          {/* 1. LIVE NOW SECTION */}
          <LiveMatches
            matches={liveMatches}
            onViewScorecard={onViewScorecard}
          />

          {/* 2. TODAY'S MATCHES SECTION (Dynamic Current Date) */}
          <TodayMatches
            matches={todayMatches}
            onViewScorecard={onViewScorecard}
          />

          {/* 3. TOMORROW'S MATCHES SECTION (Men's & Women's Split) */}
          <div className="relative">
            <div className="flex items-center justify-between mb-2">
              <div />
              <button
                onClick={() => setActiveSubView('tomorrow-schedule')}
                className="text-xs text-emerald-400 hover:underline flex items-center gap-1 font-medium cursor-pointer"
              >
                <span>View all {tomorrowMatches.length + dayAfterMatches.length} matches for Tomorrow & Day After →</span>
              </button>
            </div>
            <TomorrowMatches
              matches={tomorrowMatches}
              onViewScorecard={onViewScorecard}
            />
          </div>

          {/* 4. UPCOMING MATCHES */}
          <UpcomingMatches
            matches={upcomingMatches}
            onViewScorecard={onViewScorecard}
          />

          {/* 5. RECENT RESULTS */}
          <RecentResults
            matches={recentResults}
            onViewScorecard={onViewScorecard}
          />
        </>
      )}

    </div>
  );
};

