export type MatchFormat = 'Test' | 'ODI' | 'T20' | 'T20 League' | 'Domestic' | 'International';
export type MatchCategory = "Men's" | "Women's";
export type MatchStatus = 'LIVE' | 'UPCOMING' | 'COMPLETED' | 'STUMPS' | 'TEA' | 'INNINGS BREAK' | 'DELAYED';

export interface BatsmanLive {
  name: string;
  runs: number;
  balls: number;
  fours: number;
  sixes: number;
  strikeRate: number;
  isOnStrike: boolean;
  dismissal?: string;
}

export interface BowlerLive {
  name: string;
  overs: number;
  maidens: number;
  runs: number;
  wickets: number;
  economy: number;
}

export interface InningsScorecard {
  teamName: string;
  teamShort: string;
  runs: number;
  wickets: number;
  overs: number;
  declared?: boolean;
  batting: BatsmanLive[];
  bowling: BowlerLive[];
  extras: {
    total: number;
    byes: number;
    legByes: number;
    wides: number;
    noBalls: number;
  };
  fallOfWickets: {
    score: number;
    wicket: number;
    batsman: string;
    over: number;
  }[];
}

export interface CricketMatch {
  id: string;
  series: string;
  matchTitle: string; // e.g. "2nd ODI", "70th Match, Day 1"
  format: MatchFormat;
  category: MatchCategory;
  dateStr: string; // YYYY-MM-DD
  timeStr: string; // e.g. "5:00 PM LOCAL"
  gmtTime: string; // e.g. "11:30 AM GMT"
  venue: string;
  city: string;
  country: string;
  status: MatchStatus;
  statusNote: string; // e.g. "Need 42 runs in 36 balls", "Somerset lead by 84 runs", "RSA won by 4 wkts"
  
  team1: {
    name: string;
    shortName: string;
    code: string;
    logo?: string;
    flagColor?: string;
    score?: string; // "248/8 (50.0)" or "184 & 210/4"
    runs?: number;
    wickets?: number;
    overs?: number;
  };
  team2: {
    name: string;
    shortName: string;
    code: string;
    logo?: string;
    flagColor?: string;
    score?: string; // "195/4 (38.2)"
    runs?: number;
    wickets?: number;
    overs?: number;
  };
  
  // Live specific properties
  isLive?: boolean;
  tossWinner?: string;
  tossDecision?: 'bat' | 'bowl';
  tossText?: string;
  currentBattingTeam?: string;
  currentRunRate?: number;
  requiredRunRate?: number;
  target?: number;
  runsRequired?: number;
  ballsRemaining?: number;
  partnership?: {
    runs: number;
    balls: number;
    player1Runs: number;
    player2Runs: number;
  };
  currentBatsmen?: BatsmanLive[];
  currentBowler?: BowlerLive;
  winningProbability?: {
    team1: number;
    team2: number;
    tieOrDraw?: number;
  } | null;
  recentBalls?: string[]; // e.g. ["1", "4", "0", "W", "2", "6"]
  
  // Result details
  resultWinner?: string;
  resultMargin?: string;
  playerOfTheMatch?: string;

  // Detailed Innings for Scorecard
  innings?: InningsScorecard[];
}

export interface CricketPlayer {
  id: string;
  name: string;
  avatar?: string;
  country: string;
  team: string;
  role: 'Batter' | 'Bowler' | 'All-Rounder' | 'Wicketkeeper';
  category: "Men's" | "Women's";
  formats: ('Test' | 'ODI' | 'T20')[];
  isCaptain?: boolean;
  captainFormat?: string; // e.g. "ODI Captain", "Test Captain"
  isViceCaptain?: boolean;
  battingStyle: string; // e.g. "Right hand Bat"
  bowlingStyle: string; // e.g. "Right arm Fast-Medium", "Slow Left-Arm Orthodox"
  stats: {
    test?: { matches: number; runs: number; wickets: number; average: number; strikeRate: number; high: number };
    odi?: { matches: number; runs: number; wickets: number; average: number; strikeRate: number; high: number };
    t20?: { matches: number; runs: number; wickets: number; average: number; strikeRate: number; high: number };
  };
}

export interface CricketTeam {
  id: string;
  name: string;
  shortName: string;
  code: string;
  flagColor: string;
  logoUrl?: string;
  category: "Men's" | "Women's";
  ranking: {
    test?: number;
    odi?: number;
    t20?: number;
  };
  stats: {
    played: number;
    won: number;
    lost: number;
    draw: number;
    winPercentage: number;
  };
  keyPlayers: string[];
}

export interface StandingRow {
  position: number;
  team: string;
  teamCode: string;
  played: number;
  won: number;
  lost: number;
  tied: number;
  noResult: number;
  points: number;
  nrr: string;
}

export interface TournamentStandings {
  tournamentName: string;
  format: string;
  season: string;
  table: StandingRow[];
}
