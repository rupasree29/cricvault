/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import { CricketMatch } from './types/cricket';
import { cricketApi } from './services/cricketApi';
import { Navbar, NavTab } from './components/Navbar';
import { MatchTicker } from './components/MatchTicker';
import { Home } from './pages/Home';
import { TomorrowSchedule } from './components/TomorrowSchedule';
import { Schedule } from './components/Schedule';
import { TeamsList } from './components/TeamsList';
import { PointsTable } from './components/PointsTable';
import { PlayerList } from './components/PlayerList';
import { Statistics } from './components/Statistics';
import { MatchDetails } from './components/MatchDetails';
import { Footer } from './components/Footer';
import { AlertCircle } from 'lucide-react';

export default function App() {
  const [currentTab, setCurrentTab] = useState<NavTab>('home');
  const [liveMatches, setLiveMatches] = useState<CricketMatch[]>([]);
  const [todayMatches, setTodayMatches] = useState<CricketMatch[]>([]);
  const [tomorrowMatches, setTomorrowMatches] = useState<CricketMatch[]>([]);
  const [dayAfterMatches, setDayAfterMatches] = useState<CricketMatch[]>([]);
  const [upcomingMatches, setUpcomingMatches] = useState<CricketMatch[]>([]);
  const [recentResults, setRecentResults] = useState<CricketMatch[]>([]);
  const [allMatches, setAllMatches] = useState<CricketMatch[]>([]);
  
  const [selectedMatch, setSelectedMatch] = useState<CricketMatch | null>(null);
  const [selectedCountryForPlayers, setSelectedCountryForPlayers] = useState<string>('All');
  const [lastUpdatedTime, setLastUpdatedTime] = useState<string>(cricketApi.getLastUpdatedTime());
  const [isUpdating, setIsUpdating] = useState<boolean>(false);
  const [autoRefresh, setAutoRefresh] = useState<boolean>(true);
  const [apiError, setApiError] = useState<string | null>(null);

  // Fetch cricket data from the service layer
  const fetchAllCricketData = useCallback(async (isPolling = false) => {
    if (!isPolling) setIsUpdating(true);
    try {
      setApiError(null);
      
      const [live, today, tomorrow, dayAfter, upcoming, results] = await Promise.all([
        cricketApi.getLiveMatches(),
        cricketApi.getTodayMatches(),
        cricketApi.getTomorrowMatches(),
        cricketApi.getDayAfterTomorrowMatches(),
        cricketApi.getUpcomingMatches(),
        cricketApi.getRecentResults()
      ]);

      setLiveMatches(live);
      setTodayMatches(today);
      setTomorrowMatches(tomorrow);
      setDayAfterMatches(dayAfter);
      setUpcomingMatches(upcoming);
      setRecentResults(results);

      // Consolidate unique matches for schedule and ticker
      const combinedMap = new Map<string, CricketMatch>();
      [...live, ...today, ...tomorrow, ...dayAfter, ...upcoming, ...results].forEach(m => {
        combinedMap.set(m.id, m);
      });
      const combined = Array.from(combinedMap.values());
      setAllMatches(combined);

      // Keep selected match state updated if modal is open
      setSelectedMatch(prev => {
        if (!prev) return null;
        return combinedMap.get(prev.id) || prev;
      });

      setLastUpdatedTime(cricketApi.getLastUpdatedTime());
    } catch (error) {
      console.error('Error fetching live cricket data:', error);
      setApiError('Unable to fetch current cricket data. Please try again.');
    } finally {
      if (!isPolling) setIsUpdating(false);
    }
  }, []);

  // Initial load
  useEffect(() => {
    fetchAllCricketData(false);
  }, [fetchAllCricketData]);

  // Automatic live score updates interval (every 7 seconds)
  useEffect(() => {
    if (!autoRefresh) return;
    const interval = setInterval(() => {
      fetchAllCricketData(true);
    }, 7000);

    return () => clearInterval(interval);
  }, [autoRefresh, fetchAllCricketData]);

  const handleSelectMatchForModal = (match: CricketMatch) => {
    setSelectedMatch(match);
  };

  const handleCloseModal = () => {
    setSelectedMatch(null);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      
      {/* Top Navbar */}
      <Navbar
        currentTab={currentTab}
        onSelectTab={(tab) => {
          setCurrentTab(tab);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        lastUpdatedTime={lastUpdatedTime}
        isUpdating={isUpdating}
        onManualRefresh={() => fetchAllCricketData(false)}
        autoRefresh={autoRefresh}
        onToggleAutoRefresh={() => setAutoRefresh(prev => !prev)}
      />

      {/* Top Match Ticker Ribbon (Cricbuzz style) */}
      <MatchTicker
        matches={allMatches}
        selectedMatchId={selectedMatch?.id}
        onSelectMatch={handleSelectMatchForModal}
      />

      {/* Global API Error Alert Banner */}
      {apiError && (
        <div className="max-w-7xl mx-auto px-4 mt-4 w-full">
          <div className="bg-red-950/80 border border-red-800 text-red-200 px-4 py-3 rounded-lg flex items-center gap-3 text-xs">
            <AlertCircle className="w-5 h-5 text-red-400 shrink-0" />
            <div className="flex-1">{apiError}</div>
            <button
              onClick={() => fetchAllCricketData(false)}
              className="px-3 py-1 bg-red-900 hover:bg-red-800 text-white rounded font-medium cursor-pointer"
            >
              Retry
            </button>
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <main className="flex-1">
        {currentTab === 'home' && (
          <Home
            liveMatches={liveMatches}
            todayMatches={todayMatches}
            tomorrowMatches={tomorrowMatches}
            dayAfterMatches={dayAfterMatches}
            upcomingMatches={upcomingMatches}
            recentResults={recentResults}
            onViewScorecard={handleSelectMatchForModal}
            onNavigateToTomorrow={() => {
              setCurrentTab('tomorrow');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        )}

        {currentTab === 'tomorrow' && (
          <TomorrowSchedule
            tomorrowMatches={tomorrowMatches}
            dayAfterMatches={dayAfterMatches}
            onViewScorecard={handleSelectMatchForModal}
          />
        )}

        {currentTab === 'schedule' && (
          <Schedule
            matches={allMatches}
            onViewScorecard={handleSelectMatchForModal}
          />
        )}

        {currentTab === 'teams' && (
          <TeamsList
            onSelectTeam={(teamName) => {
              setSelectedCountryForPlayers(teamName);
              setCurrentTab('players');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        )}

        {currentTab === 'standings' && (
          <PointsTable />
        )}

        {currentTab === 'players' && (
          <PlayerList initialCountry={selectedCountryForPlayers} />
        )}

        {currentTab === 'stats' && (
          <Statistics />
        )}
      </main>

      {/* Match Scorecard & Details Modal */}
      {selectedMatch && (
        <MatchDetails
          match={selectedMatch}
          onClose={handleCloseModal}
        />
      )}

      {/* Footer */}
      <Footer onSelectTab={(tab) => {
        setCurrentTab(tab);
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }} />

    </div>
  );
}
