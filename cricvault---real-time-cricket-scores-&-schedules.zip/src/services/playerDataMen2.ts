import { CricketPlayer } from '../types/cricket';

export const MEN_PLAYERS_PART2: CricketPlayer[] = [
  // ================= PAKISTAN MEN (12 Players) =================
  {
    id: 'p-rizwan',
    name: 'Mohammad Rizwan',
    country: 'Pakistan',
    team: 'Pakistan',
    role: 'Wicketkeeper',
    category: "Men's",
    formats: ['Test', 'ODI', 'T20'],
    isCaptain: true,
    captainFormat: 'ODI & T20I Captain',
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Medium',
    stats: {
      test: { matches: 35, runs: 2005, wickets: 0, average: 43.58, strikeRate: 55.4, high: 171 },
      odi: { matches: 74, runs: 2088, wickets: 0, average: 40.15, strikeRate: 89.4, high: 131 },
      t20: { matches: 102, runs: 3313, wickets: 0, average: 48.72, strikeRate: 126.4, high: 104 }
    }
  },
  {
    id: 'p-babar',
    name: 'Babar Azam',
    country: 'Pakistan',
    team: 'Pakistan',
    role: 'Batter',
    category: "Men's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Offbreak',
    stats: {
      test: { matches: 55, runs: 3998, wickets: 2, average: 44.42, strikeRate: 55.1, high: 196 },
      odi: { matches: 117, runs: 5729, wickets: 0, average: 56.72, strikeRate: 88.5, high: 158 },
      t20: { matches: 123, runs: 4145, wickets: 0, average: 41.03, strikeRate: 129.0, high: 122 }
    }
  },
  {
    id: 'p-shaheen',
    name: 'Shaheen Shah Afridi',
    country: 'Pakistan',
    team: 'Pakistan',
    role: 'Bowler',
    category: "Men's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Left hand Bat',
    bowlingStyle: 'Left arm Fast',
    stats: {
      test: { matches: 31, runs: 340, wickets: 116, average: 27.08, strikeRate: 51.6, high: 28 },
      odi: { matches: 53, runs: 180, wickets: 104, average: 23.36, strikeRate: 25.5, high: 25 },
      t20: { matches: 70, runs: 112, wickets: 96, average: 20.82, strikeRate: 15.9, high: 23 }
    }
  },
  {
    id: 'p-fakhar',
    name: 'Fakhar Zaman',
    country: 'Pakistan',
    team: 'Pakistan',
    role: 'Batter',
    category: "Men's",
    formats: ['ODI', 'T20', 'Test'],
    battingStyle: 'Left hand Bat',
    bowlingStyle: 'Slow Left-Arm Orthodox',
    stats: {
      test: { matches: 3, runs: 192, wickets: 0, average: 32.0, strikeRate: 56.4, high: 94 },
      odi: { matches: 82, runs: 3492, wickets: 1, average: 46.56, strikeRate: 93.4, high: 210 },
      t20: { matches: 92, runs: 1848, wickets: 0, average: 23.4, strikeRate: 133.0, high: 91 }
    }
  },
  {
    id: 'p-saim',
    name: 'Saim Ayub',
    country: 'Pakistan',
    team: 'Pakistan',
    role: 'Batter',
    category: "Men's",
    formats: ['Test', 'T20', 'ODI'],
    battingStyle: 'Left hand Bat',
    bowlingStyle: 'Right arm Offbreak',
    stats: {
      test: { matches: 6, runs: 320, wickets: 3, average: 29.09, strikeRate: 58.0, high: 77 },
      odi: { matches: 3, runs: 142, wickets: 0, average: 47.33, strikeRate: 94.6, high: 82 },
      t20: { matches: 23, runs: 309, wickets: 4, average: 15.45, strikeRate: 130.0, high: 49 }
    }
  },
  {
    id: 'p-shadab',
    name: 'Shadab Khan',
    country: 'Pakistan',
    team: 'Pakistan',
    role: 'All-Rounder',
    category: "Men's",
    formats: ['ODI', 'T20', 'Test'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Legbreak',
    stats: {
      test: { matches: 6, runs: 300, wickets: 14, average: 33.33, strikeRate: 64.0, high: 56 },
      odi: { matches: 70, runs: 855, wickets: 85, average: 32.5, strikeRate: 36.2, high: 86 },
      t20: { matches: 104, runs: 650, wickets: 107, average: 22.8, strikeRate: 17.5, high: 52 }
    }
  },
  {
    id: 'p-naseem',
    name: 'Naseem Shah',
    country: 'Pakistan',
    team: 'Pakistan',
    role: 'Bowler',
    category: "Men's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Fast',
    stats: {
      test: { matches: 19, runs: 180, wickets: 56, average: 33.82, strikeRate: 58.4, high: 33 },
      odi: { matches: 18, runs: 55, wickets: 35, average: 22.4, strikeRate: 25.0, high: 19 },
      t20: { matches: 28, runs: 42, wickets: 24, average: 31.2, strikeRate: 23.4, high: 14 }
    }
  },
  {
    id: 'p-harisrauf',
    name: 'Haris Rauf',
    country: 'Pakistan',
    team: 'Pakistan',
    role: 'Bowler',
    category: "Men's",
    formats: ['ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Fast',
    stats: {
      odi: { matches: 40, runs: 64, wickets: 79, average: 24.58, strikeRate: 24.6, high: 16 },
      t20: { matches: 74, runs: 75, wickets: 102, average: 21.0, strikeRate: 15.2, high: 13 }
    }
  },
  {
    id: 'p-iftikhar',
    name: 'Iftikhar Ahmed',
    country: 'Pakistan',
    team: 'Pakistan',
    role: 'All-Rounder',
    category: "Men's",
    formats: ['ODI', 'T20', 'Test'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Offbreak',
    stats: {
      odi: { matches: 28, runs: 614, wickets: 16, average: 38.37, strikeRate: 105.8, high: 109 },
      t20: { matches: 66, runs: 998, wickets: 8, average: 25.58, strikeRate: 129.4, high: 60 }
    }
  },
  {
    id: 'p-salman',
    name: 'Salman Ali Agha',
    country: 'Pakistan',
    team: 'Pakistan',
    role: 'All-Rounder',
    category: "Men's",
    formats: ['Test', 'ODI', 'T20'],
    isViceCaptain: true,
    captainFormat: 'Pakistan Vice-Captain',
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Offbreak',
    stats: {
      test: { matches: 16, runs: 1050, wickets: 13, average: 43.75, strikeRate: 67.2, high: 132 },
      odi: { matches: 24, runs: 530, wickets: 6, average: 37.85, strikeRate: 88.5, high: 58 },
      t20: { matches: 12, runs: 160, wickets: 3, average: 22.8, strikeRate: 124.0, high: 38 }
    }
  },
  {
    id: 'p-abrar',
    name: 'Abrar Ahmed',
    country: 'Pakistan',
    team: 'Pakistan',
    role: 'Bowler',
    category: "Men's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Legbreak',
    stats: {
      test: { matches: 8, runs: 42, wickets: 40, average: 32.5, strikeRate: 54.0, high: 17 },
      odi: { matches: 4, runs: 8, wickets: 6, average: 28.0, strikeRate: 36.0, high: 4 },
      t20: { matches: 9, runs: 6, wickets: 11, average: 24.2, strikeRate: 18.0, high: 4 }
    }
  },
  {
    id: 'p-shan',
    name: 'Shan Masood',
    country: 'Pakistan',
    team: 'Pakistan',
    role: 'Batter',
    category: "Men's",
    formats: ['Test', 'ODI', 'T20'],
    isCaptain: true,
    captainFormat: 'Test Captain',
    battingStyle: 'Left hand Bat',
    bowlingStyle: 'Right arm Medium-Fast',
    stats: {
      test: { matches: 37, runs: 2040, wickets: 2, average: 29.56, strikeRate: 54.2, high: 156 },
      odi: { matches: 9, runs: 163, wickets: 0, average: 18.11, strikeRate: 72.4, high: 44 },
      t20: { matches: 19, runs: 395, wickets: 0, average: 30.38, strikeRate: 121.9, high: 65 }
    }
  },

  // ================= WEST INDIES MEN (12 Players) =================
  {
    id: 'p-hope',
    name: 'Shai Hope',
    country: 'West Indies',
    team: 'West Indies',
    role: 'Wicketkeeper',
    category: "Men's",
    formats: ['ODI', 'T20', 'Test'],
    isCaptain: true,
    captainFormat: 'ODI Captain',
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Wicketkeeper',
    stats: {
      test: { matches: 38, runs: 1726, wickets: 0, average: 25.01, strikeRate: 42.1, high: 147 },
      odi: { matches: 128, runs: 5240, wickets: 0, average: 50.87, strikeRate: 78.4, high: 170 },
      t20: { matches: 38, runs: 780, wickets: 0, average: 26.0, strikeRate: 134.2, high: 82 }
    }
  },
  {
    id: 'p-powell',
    name: 'Rovman Powell',
    country: 'West Indies',
    team: 'West Indies',
    role: 'All-Rounder',
    category: "Men's",
    formats: ['T20'],
    isCaptain: true,
    captainFormat: 'T20I Captain',
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Medium',
    stats: {
      odi: { matches: 51, runs: 979, wickets: 3, average: 22.76, strikeRate: 84.6, high: 101 },
      t20: { matches: 84, runs: 1540, wickets: 5, average: 26.55, strikeRate: 144.2, high: 107 }
    }
  },
  {
    id: 'p-pooran',
    name: 'Nicholas Pooran',
    country: 'West Indies',
    team: 'West Indies',
    role: 'Wicketkeeper',
    category: "Men's",
    formats: ['T20', 'ODI'],
    battingStyle: 'Left hand Bat',
    bowlingStyle: 'Right arm Offbreak',
    stats: {
      odi: { matches: 61, runs: 1983, wickets: 6, average: 39.66, strikeRate: 98.8, high: 118 },
      t20: { matches: 102, runs: 2253, wickets: 0, average: 26.82, strikeRate: 137.5, high: 98 }
    }
  },
  {
    id: 'p-russell',
    name: 'Andre Russell',
    country: 'West Indies',
    team: 'West Indies',
    role: 'All-Rounder',
    category: "Men's",
    formats: ['T20', 'ODI'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Fast',
    stats: {
      odi: { matches: 56, runs: 1034, wickets: 70, average: 27.21, strikeRate: 130.2, high: 92 },
      t20: { matches: 82, runs: 1033, wickets: 60, average: 21.52, strikeRate: 163.7, high: 71 }
    }
  },
  {
    id: 'p-hetmyer',
    name: 'Shimron Hetmyer',
    country: 'West Indies',
    team: 'West Indies',
    role: 'Batter',
    category: "Men's",
    formats: ['T20', 'ODI', 'Test'],
    battingStyle: 'Left hand Bat',
    bowlingStyle: 'Right arm Legbreak',
    stats: {
      test: { matches: 16, runs: 838, wickets: 0, average: 30.0, strikeRate: 68.0, high: 93 },
      odi: { matches: 53, runs: 1530, wickets: 0, average: 32.55, strikeRate: 106.0, high: 139 },
      t20: { matches: 62, runs: 960, wickets: 0, average: 21.33, strikeRate: 122.0, high: 81 }
    }
  },
  {
    id: 'p-bking',
    name: 'Brandon King',
    country: 'West Indies',
    team: 'West Indies',
    role: 'Batter',
    category: "Men's",
    formats: ['T20', 'ODI'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Offbreak',
    stats: {
      odi: { matches: 37, runs: 1020, wickets: 0, average: 31.87, strikeRate: 82.5, high: 112 },
      t20: { matches: 57, runs: 1460, wickets: 0, average: 28.62, strikeRate: 132.8, high: 85 }
    }
  },
  {
    id: 'p-rutherford',
    name: 'Sherfane Rutherford',
    country: 'West Indies',
    team: 'West Indies',
    role: 'Batter',
    category: "Men's",
    formats: ['T20', 'ODI'],
    battingStyle: 'Left hand Bat',
    bowlingStyle: 'Right arm Fast-Medium',
    stats: {
      odi: { matches: 5, runs: 180, wickets: 1, average: 45.0, strikeRate: 115.0, high: 67 },
      t20: { matches: 21, runs: 380, wickets: 1, average: 29.23, strikeRate: 154.0, high: 68 }
    }
  },
  {
    id: 'p-shepherd',
    name: 'Romario Shepherd',
    country: 'West Indies',
    team: 'West Indies',
    role: 'All-Rounder',
    category: "Men's",
    formats: ['T20', 'ODI'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Fast-Medium',
    stats: {
      odi: { matches: 28, runs: 320, wickets: 24, average: 38.0, strikeRate: 34.0, high: 50 },
      t20: { matches: 47, runs: 450, wickets: 48, average: 28.5, strikeRate: 151.0, high: 44 }
    }
  },
  {
    id: 'p-alzarri',
    name: 'Alzarri Joseph',
    country: 'West Indies',
    team: 'West Indies',
    role: 'Bowler',
    category: "Men's",
    formats: ['Test', 'ODI', 'T20'],
    isViceCaptain: true,
    captainFormat: 'West Indies Vice-Captain',
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Fast',
    stats: {
      test: { matches: 34, runs: 650, wickets: 96, average: 34.8, strikeRate: 54.2, high: 86 },
      odi: { matches: 68, runs: 410, wickets: 112, average: 28.16, strikeRate: 31.0, high: 49 },
      t20: { matches: 29, runs: 85, wickets: 46, average: 21.32, strikeRate: 14.8, high: 15 }
    }
  },
  {
    id: 'p-akeal',
    name: 'Akeal Hosein',
    country: 'West Indies',
    team: 'West Indies',
    role: 'Bowler',
    category: "Men's",
    formats: ['T20', 'ODI'],
    battingStyle: 'Left hand Bat',
    bowlingStyle: 'Slow Left-Arm Orthodox',
    stats: {
      odi: { matches: 38, runs: 280, wickets: 57, average: 29.8, strikeRate: 34.8, high: 60 },
      t20: { matches: 58, runs: 210, wickets: 55, average: 26.54, strikeRate: 21.0, high: 44 }
    }
  },
  {
    id: 'p-motie',
    name: 'Gudakesh Motie',
    country: 'West Indies',
    team: 'West Indies',
    role: 'Bowler',
    category: "Men's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Left hand Bat',
    bowlingStyle: 'Slow Left-Arm Orthodox',
    stats: {
      test: { matches: 8, runs: 165, wickets: 29, average: 24.8, strikeRate: 48.0, high: 23 },
      odi: { matches: 16, runs: 85, wickets: 24, average: 26.4, strikeRate: 32.0, high: 28 },
      t20: { matches: 24, runs: 45, wickets: 27, average: 20.81, strikeRate: 17.5, high: 16 }
    }
  },
  {
    id: 'p-chase',
    name: 'Roston Chase',
    country: 'West Indies',
    team: 'West Indies',
    role: 'All-Rounder',
    category: "Men's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Offbreak',
    stats: {
      test: { matches: 49, runs: 2340, wickets: 88, average: 28.5, strikeRate: 52.0, high: 137 },
      odi: { matches: 45, runs: 710, wickets: 25, average: 26.2, strikeRate: 75.0, high: 94 },
      t20: { matches: 23, runs: 390, wickets: 14, average: 27.85, strikeRate: 128.0, high: 67 }
    }
  },

  // ================= SRI LANKA MEN (12 Players) =================
  {
    id: 'p-7',
    name: 'Charith Asalanka',
    country: 'Sri Lanka',
    team: 'Sri Lanka',
    role: 'All-Rounder',
    category: "Men's",
    formats: ['ODI', 'T20'],
    isCaptain: true,
    captainFormat: 'ODI & T20I Captain',
    battingStyle: 'Left hand Bat',
    bowlingStyle: 'Right arm Offbreak',
    stats: {
      odi: { matches: 64, runs: 2014, wickets: 18, average: 42.85, strikeRate: 89.2, high: 110 },
      t20: { matches: 52, runs: 1120, wickets: 4, average: 26.66, strikeRate: 124.5, high: 80 }
    }
  },
  {
    id: 'p-8',
    name: 'Wanindu Hasaranga',
    country: 'Sri Lanka',
    team: 'Sri Lanka',
    role: 'All-Rounder',
    category: "Men's",
    formats: ['ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Legbreak',
    stats: {
      test: { matches: 4, runs: 196, wickets: 4, average: 28.0, strikeRate: 62.0, high: 59 },
      odi: { matches: 58, runs: 920, wickets: 96, average: 25.40, strikeRate: 108.2, high: 80 },
      t20: { matches: 72, runs: 680, wickets: 118, average: 15.68, strikeRate: 128.4, high: 71 }
    }
  },
  {
    id: 'p-nissanka',
    name: 'Pathum Nissanka',
    country: 'Sri Lanka',
    team: 'Sri Lanka',
    role: 'Batter',
    category: "Men's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Offbreak',
    stats: {
      test: { matches: 11, runs: 620, wickets: 0, average: 38.75, strikeRate: 51.2, high: 127 },
      odi: { matches: 59, runs: 2340, wickets: 0, average: 44.15, strikeRate: 89.6, high: 210 },
      t20: { matches: 56, runs: 1540, wickets: 0, average: 30.19, strikeRate: 122.8, high: 75 }
    }
  },
  {
    id: 'p-kmendis',
    name: 'Kusal Mendis',
    country: 'Sri Lanka',
    team: 'Sri Lanka',
    role: 'Wicketkeeper',
    category: "Men's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Legbreak',
    stats: {
      test: { matches: 65, runs: 4200, wickets: 1, average: 36.5, strikeRate: 54.0, high: 245 },
      odi: { matches: 132, runs: 3950, wickets: 0, average: 33.76, strikeRate: 85.4, high: 122 },
      t20: { matches: 70, runs: 1680, wickets: 0, average: 25.45, strikeRate: 132.8, high: 86 }
    }
  },
  {
    id: 'p-kamindu',
    name: 'Kamindu Mendis',
    country: 'Sri Lanka',
    team: 'Sri Lanka',
    role: 'All-Rounder',
    category: "Men's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Left hand Bat',
    bowlingStyle: 'Ambidextrous Offbreak / Slow Left-Arm',
    stats: {
      test: { matches: 9, runs: 1040, wickets: 4, average: 74.28, strikeRate: 64.0, high: 182 },
      odi: { matches: 14, runs: 360, wickets: 5, average: 32.72, strikeRate: 84.0, high: 57 },
      t20: { matches: 18, runs: 340, wickets: 3, average: 24.28, strikeRate: 124.0, high: 51 }
    }
  },
  {
    id: 'p-dhananjaya',
    name: 'Dhananjaya de Silva',
    country: 'Sri Lanka',
    team: 'Sri Lanka',
    role: 'All-Rounder',
    category: "Men's",
    formats: ['Test', 'ODI', 'T20'],
    isCaptain: true,
    captainFormat: 'Test Captain',
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Offbreak',
    stats: {
      test: { matches: 57, runs: 3580, wickets: 38, average: 39.77, strikeRate: 58.0, high: 173 },
      odi: { matches: 90, runs: 1860, wickets: 44, average: 26.95, strikeRate: 78.4, high: 93 },
      t20: { matches: 43, runs: 740, wickets: 14, average: 20.55, strikeRate: 115.0, high: 66 }
    }
  },
  {
    id: 'p-theekshana',
    name: 'Maheesh Theekshana',
    country: 'Sri Lanka',
    team: 'Sri Lanka',
    role: 'Bowler',
    category: "Men's",
    formats: ['ODI', 'T20', 'Test'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Offbreak',
    stats: {
      test: { matches: 2, runs: 42, wickets: 5, average: 35.0, strikeRate: 62.0, high: 38 },
      odi: { matches: 45, runs: 180, wickets: 60, average: 28.5, strikeRate: 36.8, high: 28 },
      t20: { matches: 58, runs: 65, wickets: 54, average: 25.85, strikeRate: 23.5, high: 11 }
    }
  },
  {
    id: 'p-pathirana',
    name: 'Matheesha Pathirana',
    country: 'Sri Lanka',
    team: 'Sri Lanka',
    role: 'Bowler',
    category: "Men's",
    formats: ['T20', 'ODI'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Fast',
    stats: {
      odi: { matches: 12, runs: 15, wickets: 17, average: 32.4, strikeRate: 27.5, high: 8 },
      t20: { matches: 16, runs: 10, wickets: 24, average: 18.25, strikeRate: 13.0, high: 4 }
    }
  },
  {
    id: 'p-madushanka',
    name: 'Dilshan Madushanka',
    country: 'Sri Lanka',
    team: 'Sri Lanka',
    role: 'Bowler',
    category: "Men's",
    formats: ['ODI', 'T20', 'Test'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Left arm Fast-Medium',
    stats: {
      test: { matches: 1, runs: 0, wickets: 0, average: 0, strikeRate: 0, high: 0 },
      odi: { matches: 26, runs: 30, wickets: 45, average: 25.15, strikeRate: 27.2, high: 8 },
      t20: { matches: 15, runs: 6, wickets: 14, average: 31.0, strikeRate: 21.5, high: 4 }
    }
  },
  {
    id: 'p-shanaka',
    name: 'Dasun Shanaka',
    country: 'Sri Lanka',
    team: 'Sri Lanka',
    role: 'All-Rounder',
    category: "Men's",
    formats: ['ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Medium',
    stats: {
      odi: { matches: 69, runs: 1250, wickets: 27, average: 22.72, strikeRate: 91.2, high: 108 },
      t20: { matches: 96, runs: 1450, wickets: 31, average: 20.71, strikeRate: 121.5, high: 74 }
    }
  },
  {
    id: 'p-sadeera',
    name: 'Sadeera Samarawickrama',
    country: 'Sri Lanka',
    team: 'Sri Lanka',
    role: 'Wicketkeeper',
    category: "Men's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Offbreak',
    stats: {
      test: { matches: 9, runs: 420, wickets: 0, average: 30.0, strikeRate: 58.0, high: 104 },
      odi: { matches: 42, runs: 1180, wickets: 0, average: 34.7, strikeRate: 92.4, high: 93 },
      t20: { matches: 20, runs: 280, wickets: 0, average: 17.5, strikeRate: 110.0, high: 51 }
    }
  },
  {
    id: 'p-asitha',
    name: 'Asitha Fernando',
    country: 'Sri Lanka',
    team: 'Sri Lanka',
    role: 'Bowler',
    category: "Men's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Fast-Medium',
    stats: {
      test: { matches: 17, runs: 85, wickets: 60, average: 26.55, strikeRate: 46.2, high: 12 },
      odi: { matches: 10, runs: 12, wickets: 10, average: 41.2, strikeRate: 44.0, high: 6 },
      t20: { matches: 6, runs: 2, wickets: 5, average: 38.0, strikeRate: 24.0, high: 2 }
    }
  },

  // ================= AFGHANISTAN MEN (12 Players) =================
  {
    id: 'p-rashid',
    name: 'Rashid Khan',
    country: 'Afghanistan',
    team: 'Afghanistan',
    role: 'Bowler',
    category: "Men's",
    formats: ['T20', 'ODI', 'Test'],
    isCaptain: true,
    captainFormat: 'T20I Captain',
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Legbreak',
    stats: {
      test: { matches: 5, runs: 106, wickets: 34, average: 22.35, strikeRate: 46.8, high: 51 },
      odi: { matches: 106, runs: 1320, wickets: 190, average: 20.02, strikeRate: 27.2, high: 60 },
      t20: { matches: 93, runs: 440, wickets: 152, average: 14.28, strikeRate: 13.8, high: 48 }
    }
  },
  {
    id: 'p-gurbaz',
    name: 'Rahmanullah Gurbaz',
    country: 'Afghanistan',
    team: 'Afghanistan',
    role: 'Wicketkeeper',
    category: "Men's",
    formats: ['ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Medium',
    stats: {
      test: { matches: 2, runs: 94, wickets: 0, average: 23.5, strikeRate: 64.0, high: 46 },
      odi: { matches: 43, runs: 1680, wickets: 0, average: 40.0, strikeRate: 88.5, high: 151 },
      t20: { matches: 63, runs: 1650, wickets: 0, average: 26.61, strikeRate: 135.2, high: 100 }
    }
  },
  {
    id: 'p-ibrahim',
    name: 'Ibrahim Zadran',
    country: 'Afghanistan',
    team: 'Afghanistan',
    role: 'Batter',
    category: "Men's",
    formats: ['Test', 'ODI', 'T20'],
    isViceCaptain: true,
    captainFormat: 'T20I Vice-Captain',
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Medium-Fast',
    stats: {
      test: { matches: 7, runs: 541, wickets: 1, average: 38.64, strikeRate: 48.0, high: 114 },
      odi: { matches: 32, runs: 1420, wickets: 0, average: 47.33, strikeRate: 82.4, high: 162 },
      t20: { matches: 44, runs: 1140, wickets: 0, average: 30.0, strikeRate: 115.6, high: 72 }
    }
  },
  {
    id: 'p-shahidi',
    name: 'Hashmatullah Shahidi',
    country: 'Afghanistan',
    team: 'Afghanistan',
    role: 'Batter',
    category: "Men's",
    formats: ['Test', 'ODI'],
    isCaptain: true,
    captainFormat: 'Test & ODI Captain',
    battingStyle: 'Left hand Bat',
    bowlingStyle: 'Right arm Offbreak',
    stats: {
      test: { matches: 7, runs: 535, wickets: 0, average: 44.58, strikeRate: 43.5, high: 200 },
      odi: { matches: 78, runs: 2180, wickets: 1, average: 34.06, strikeRate: 68.2, high: 97 }
    }
  },
  {
    id: 'p-nabi',
    name: 'Mohammad Nabi',
    country: 'Afghanistan',
    team: 'Afghanistan',
    role: 'All-Rounder',
    category: "Men's",
    formats: ['ODI', 'T20', 'Test'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Offbreak',
    stats: {
      test: { matches: 3, runs: 33, wickets: 8, average: 31.75, strikeRate: 52.0, high: 24 },
      odi: { matches: 165, runs: 3420, wickets: 171, average: 27.36, strikeRate: 87.2, high: 136 },
      t20: { matches: 129, runs: 2180, wickets: 96, average: 22.47, strikeRate: 136.8, high: 89 }
    }
  },
  {
    id: 'p-omarzai',
    name: 'Azmatullah Omarzai',
    country: 'Afghanistan',
    team: 'Afghanistan',
    role: 'All-Rounder',
    category: "Men's",
    formats: ['ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Medium-Fast',
    stats: {
      odi: { matches: 27, runs: 790, wickets: 22, average: 46.47, strikeRate: 98.6, high: 149 },
      t20: { matches: 42, runs: 380, wickets: 24, average: 21.11, strikeRate: 131.0, high: 36 }
    }
  },
  {
    id: 'p-farooqi',
    name: 'Fazalhaq Farooqi',
    country: 'Afghanistan',
    team: 'Afghanistan',
    role: 'Bowler',
    category: "Men's",
    formats: ['ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Left arm Fast-Medium',
    stats: {
      odi: { matches: 36, runs: 45, wickets: 53, average: 29.58, strikeRate: 31.4, high: 10 },
      t20: { matches: 45, runs: 12, wickets: 54, average: 20.44, strikeRate: 17.5, high: 5 }
    }
  },
  {
    id: 'p-naveen',
    name: 'Naveen-ul-Haq',
    country: 'Afghanistan',
    team: 'Afghanistan',
    role: 'Bowler',
    category: "Men's",
    formats: ['T20', 'ODI'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Fast-Medium',
    stats: {
      odi: { matches: 15, runs: 28, wickets: 22, average: 32.18, strikeRate: 33.0, high: 9 },
      t20: { matches: 46, runs: 52, wickets: 59, average: 21.05, strikeRate: 16.0, high: 13 }
    }
  },
  {
    id: 'p-noor',
    name: 'Noor Ahmad',
    country: 'Afghanistan',
    team: 'Afghanistan',
    role: 'Bowler',
    category: "Men's",
    formats: ['ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Left-arm Wrist Spin',
    stats: {
      odi: { matches: 10, runs: 30, wickets: 11, average: 40.2, strikeRate: 46.0, high: 15 },
      t20: { matches: 14, runs: 18, wickets: 16, average: 22.5, strikeRate: 19.5, high: 10 }
    }
  },
  {
    id: 'p-mujeeb',
    name: 'Mujeeb Ur Rahman',
    country: 'Afghanistan',
    team: 'Afghanistan',
    role: 'Bowler',
    category: "Men's",
    formats: ['ODI', 'T20', 'Test'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Offbreak',
    stats: {
      test: { matches: 1, runs: 18, wickets: 1, average: 75.0, strikeRate: 90.0, high: 15 },
      odi: { matches: 75, runs: 260, wickets: 101, average: 28.52, strikeRate: 38.4, high: 64 },
      t20: { matches: 46, runs: 55, wickets: 59, average: 18.28, strikeRate: 17.8, high: 18 }
    }
  },
  {
    id: 'p-gulbadin',
    name: 'Gulbadin Naib',
    country: 'Afghanistan',
    team: 'Afghanistan',
    role: 'All-Rounder',
    category: "Men's",
    formats: ['ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Fast-Medium',
    stats: {
      odi: { matches: 84, runs: 1280, wickets: 73, average: 21.69, strikeRate: 83.2, high: 82 },
      t20: { matches: 68, runs: 910, wickets: 32, average: 23.94, strikeRate: 129.5, high: 57 }
    }
  },
  {
    id: 'p-najibullah',
    name: 'Najibullah Zadran',
    country: 'Afghanistan',
    team: 'Afghanistan',
    role: 'Batter',
    category: "Men's",
    formats: ['ODI', 'T20'],
    battingStyle: 'Left hand Bat',
    bowlingStyle: 'Right arm Offbreak',
    stats: {
      odi: { matches: 88, runs: 2060, wickets: 0, average: 30.29, strikeRate: 89.4, high: 104 },
      t20: { matches: 107, runs: 1830, wickets: 0, average: 30.5, strikeRate: 137.8, high: 73 }
    }
  },

  // ================= BANGLADESH MEN (12 Players) =================
  {
    id: 'p-shanto',
    name: 'Najmul Hossain Shanto',
    country: 'Bangladesh',
    team: 'Bangladesh',
    role: 'Batter',
    category: "Men's",
    formats: ['Test', 'ODI', 'T20'],
    isCaptain: true,
    captainFormat: 'All-Format Captain',
    battingStyle: 'Left hand Bat',
    bowlingStyle: 'Right arm Offbreak',
    stats: {
      test: { matches: 31, runs: 1720, wickets: 0, average: 30.71, strikeRate: 48.6, high: 163 },
      odi: { matches: 45, runs: 1410, wickets: 1, average: 33.57, strikeRate: 81.2, high: 117 },
      t20: { matches: 49, runs: 960, wickets: 0, average: 23.41, strikeRate: 112.5, high: 71 }
    }
  },
  {
    id: 'p-litton',
    name: 'Litton Das',
    country: 'Bangladesh',
    team: 'Bangladesh',
    role: 'Wicketkeeper',
    category: "Men's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Wicketkeeper',
    stats: {
      test: { matches: 44, runs: 2680, wickets: 0, average: 36.21, strikeRate: 58.4, high: 141 },
      odi: { matches: 91, runs: 2560, wickets: 0, average: 31.6, strikeRate: 87.2, high: 176 },
      t20: { matches: 89, runs: 1940, wickets: 0, average: 23.65, strikeRate: 126.8, high: 83 }
    }
  },
  {
    id: 'p-mehidy',
    name: 'Mehidy Hasan Miraz',
    country: 'Bangladesh',
    team: 'Bangladesh',
    role: 'All-Rounder',
    category: "Men's",
    formats: ['Test', 'ODI', 'T20'],
    isViceCaptain: true,
    captainFormat: 'Bangladesh Vice-Captain',
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Offbreak',
    stats: {
      test: { matches: 47, runs: 1620, wickets: 174, average: 33.25, strikeRate: 59.4, high: 103 },
      odi: { matches: 97, runs: 1390, wickets: 104, average: 33.82, strikeRate: 78.5, high: 100 },
      t20: { matches: 28, runs: 275, wickets: 14, average: 15.27, strikeRate: 118.0, high: 46 }
    }
  },
  {
    id: 'p-shakib',
    name: 'Shakib Al Hasan',
    country: 'Bangladesh',
    team: 'Bangladesh',
    role: 'All-Rounder',
    category: "Men's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Left hand Bat',
    bowlingStyle: 'Slow Left-Arm Orthodox',
    stats: {
      test: { matches: 71, runs: 4600, wickets: 246, average: 38.01, strikeRate: 62.0, high: 217 },
      odi: { matches: 247, runs: 7570, wickets: 317, average: 37.29, strikeRate: 82.5, high: 134 },
      t20: { matches: 129, runs: 2551, wickets: 149, average: 23.19, strikeRate: 121.8, high: 84 }
    }
  },
  {
    id: 'p-towhid',
    name: 'Towhid Hridoy',
    country: 'Bangladesh',
    team: 'Bangladesh',
    role: 'Batter',
    category: "Men's",
    formats: ['ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Offbreak',
    stats: {
      odi: { matches: 30, runs: 840, wickets: 0, average: 35.0, strikeRate: 85.4, high: 92 },
      t20: { matches: 38, runs: 720, wickets: 0, average: 26.66, strikeRate: 132.0, high: 63 }
    }
  },
  {
    id: 'p-mahmudullah',
    name: 'Mahmudullah',
    country: 'Bangladesh',
    team: 'Bangladesh',
    role: 'All-Rounder',
    category: "Men's",
    formats: ['ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Offbreak',
    stats: {
      test: { matches: 50, runs: 2914, wickets: 43, average: 33.49, strikeRate: 54.0, high: 150 },
      odi: { matches: 232, runs: 5380, wickets: 82, average: 36.1, strikeRate: 77.2, high: 128 },
      t20: { matches: 141, runs: 2444, wickets: 40, average: 23.5, strikeRate: 117.8, high: 64 }
    }
  },
  {
    id: 'p-taskin',
    name: 'Taskin Ahmed',
    country: 'Bangladesh',
    team: 'Bangladesh',
    role: 'Bowler',
    category: "Men's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Left hand Bat',
    bowlingStyle: 'Right arm Fast',
    stats: {
      test: { matches: 14, runs: 220, wickets: 34, average: 51.5, strikeRate: 74.0, high: 75 },
      odi: { matches: 77, runs: 180, wickets: 105, average: 30.2, strikeRate: 31.8, high: 21 },
      t20: { matches: 67, runs: 125, wickets: 78, average: 22.45, strikeRate: 17.5, high: 15 }
    }
  },
  {
    id: 'p-mustafizur',
    name: 'Mustafizur Rahman',
    country: 'Bangladesh',
    team: 'Bangladesh',
    role: 'Bowler',
    category: "Men's",
    formats: ['ODI', 'T20', 'Test'],
    battingStyle: 'Left hand Bat',
    bowlingStyle: 'Left arm Fast-Medium',
    stats: {
      test: { matches: 15, runs: 66, wickets: 31, average: 36.74, strikeRate: 67.2, high: 16 },
      odi: { matches: 104, runs: 140, wickets: 164, average: 26.04, strikeRate: 29.5, high: 20 },
      t20: { matches: 106, runs: 75, wickets: 131, average: 21.65, strikeRate: 16.8, high: 10 }
    }
  },
  {
    id: 'p-shoriful',
    name: 'Shoriful Islam',
    country: 'Bangladesh',
    team: 'Bangladesh',
    role: 'Bowler',
    category: "Men's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Left hand Bat',
    bowlingStyle: 'Left arm Fast-Medium',
    stats: {
      test: { matches: 10, runs: 85, wickets: 24, average: 37.5, strikeRate: 60.0, high: 26 },
      odi: { matches: 37, runs: 65, wickets: 58, average: 26.85, strikeRate: 28.5, high: 16 },
      t20: { matches: 45, runs: 30, wickets: 48, average: 25.12, strikeRate: 18.2, high: 8 }
    }
  },
  {
    id: 'p-rishad',
    name: 'Rishad Hossain',
    country: 'Bangladesh',
    team: 'Bangladesh',
    role: 'Bowler',
    category: "Men's",
    formats: ['T20', 'ODI'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Legbreak',
    stats: {
      odi: { matches: 3, runs: 54, wickets: 4, average: 28.5, strikeRate: 30.0, high: 48 },
      t20: { matches: 27, runs: 165, wickets: 33, average: 19.85, strikeRate: 15.6, high: 53 }
    }
  },
  {
    id: 'p-tanzid',
    name: 'Tanzid Hasan',
    country: 'Bangladesh',
    team: 'Bangladesh',
    role: 'Batter',
    category: "Men's",
    formats: ['ODI', 'T20'],
    battingStyle: 'Left hand Bat',
    bowlingStyle: 'Right arm Legbreak',
    stats: {
      odi: { matches: 21, runs: 420, wickets: 0, average: 21.0, strikeRate: 88.0, high: 84 },
      t20: { matches: 23, runs: 490, wickets: 0, average: 23.33, strikeRate: 124.0, high: 67 }
    }
  },
  {
    id: 'p-mushfiqur',
    name: 'Mushfiqur Rahim',
    country: 'Bangladesh',
    team: 'Bangladesh',
    role: 'Wicketkeeper',
    category: "Men's",
    formats: ['Test', 'ODI'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Medium',
    stats: {
      test: { matches: 92, runs: 5980, wickets: 0, average: 38.58, strikeRate: 46.8, high: 219 },
      odi: { matches: 271, runs: 7792, wickets: 0, average: 36.92, strikeRate: 79.6, high: 144 },
      t20: { matches: 102, runs: 1500, wickets: 0, average: 19.48, strikeRate: 115.0, high: 72 }
    }
  },

  // ================= DOMESTIC CRICKETERS =================
  {
    id: 'p-banton',
    name: 'Tom Banton',
    country: 'England',
    team: 'Somerset',
    role: 'Batter',
    category: "Men's",
    formats: ['T20', 'ODI'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Offbreak',
    stats: {
      test: { matches: 0, runs: 0, wickets: 0, average: 0, strikeRate: 0, high: 0 },
      odi: { matches: 14, runs: 392, wickets: 0, average: 28.0, strikeRate: 94.2, high: 86 },
      t20: { matches: 28, runs: 642, wickets: 0, average: 24.69, strikeRate: 144.5, high: 107 }
    }
  }
];
