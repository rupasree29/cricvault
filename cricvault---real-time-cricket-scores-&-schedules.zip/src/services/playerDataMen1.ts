import { CricketPlayer } from '../types/cricket';

export const MEN_PLAYERS_PART1: CricketPlayer[] = [
  // ================= INDIA MEN (18 Players) =================
  {
    id: 'p-gill',
    name: 'Shubman Gill',
    country: 'India',
    team: 'India',
    role: 'Batter',
    category: "Men's",
    formats: ['ODI', 'Test', 'T20'],
    isCaptain: true,
    captainFormat: 'ODI Captain',
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Offbreak',
    stats: {
      test: { matches: 29, runs: 1800, wickets: 0, average: 36.73, strikeRate: 59.8, high: 128 },
      odi: { matches: 47, runs: 2328, wickets: 0, average: 58.20, strikeRate: 101.7, high: 208 },
      t20: { matches: 21, runs: 578, wickets: 0, average: 30.42, strikeRate: 139.3, high: 126 }
    }
  },
  {
    id: 'p-rohit',
    name: 'Rohit Sharma',
    country: 'India',
    team: 'India',
    role: 'Batter',
    category: "Men's",
    formats: ['Test', 'ODI'],
    isCaptain: true,
    captainFormat: 'Test Captain',
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Offbreak',
    stats: {
      test: { matches: 64, runs: 4233, wickets: 2, average: 43.19, strikeRate: 56.4, high: 212 },
      odi: { matches: 265, runs: 10866, wickets: 9, average: 49.16, strikeRate: 92.4, high: 264 }
    }
  },
  {
    id: 'p-sky',
    name: 'Suryakumar Yadav',
    country: 'India',
    team: 'India',
    role: 'Batter',
    category: "Men's",
    formats: ['T20'],
    isCaptain: true,
    captainFormat: 'T20I Captain',
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Medium',
    stats: {
      odi: { matches: 37, runs: 773, wickets: 0, average: 25.76, strikeRate: 105.0, high: 72 },
      t20: { matches: 74, runs: 2544, wickets: 0, average: 42.40, strikeRate: 168.2, high: 117 }
    }
  },
  {
    id: 'p-nitish',
    name: 'Nitish Kumar Reddy',
    country: 'India',
    team: 'India',
    role: 'All-Rounder',
    category: "Men's",
    formats: ['Test', 'T20', 'ODI'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Medium-Fast',
    stats: {
      test: { matches: 5, runs: 289, wickets: 7, average: 36.12, strikeRate: 64.2, high: 114 },
      odi: { matches: 3, runs: 94, wickets: 3, average: 31.33, strikeRate: 108.0, high: 45 },
      t20: { matches: 6, runs: 168, wickets: 5, average: 42.0, strikeRate: 178.7, high: 74 }
    }
  },
  {
    id: 'p-1',
    name: 'Virat Kohli',
    country: 'India',
    team: 'India',
    role: 'Batter',
    category: "Men's",
    formats: ['Test', 'ODI'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Medium',
    stats: {
      test: { matches: 118, runs: 9040, wickets: 0, average: 48.86, strikeRate: 55.6, high: 254 },
      odi: { matches: 295, runs: 13906, wickets: 5, average: 58.18, strikeRate: 93.5, high: 183 },
      t20: { matches: 125, runs: 4188, wickets: 4, average: 48.69, strikeRate: 137.0, high: 122 }
    }
  },
  {
    id: 'p-3',
    name: 'Jasprit Bumrah',
    country: 'India',
    team: 'India',
    role: 'Bowler',
    category: "Men's",
    formats: ['Test', 'ODI', 'T20'],
    isViceCaptain: true,
    captainFormat: 'Test Vice-Captain',
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Fast',
    stats: {
      test: { matches: 40, runs: 290, wickets: 181, average: 20.21, strikeRate: 44.5, high: 34 },
      odi: { matches: 89, runs: 85, wickets: 149, average: 23.55, strikeRate: 31.2, high: 16 },
      t20: { matches: 70, runs: 12, wickets: 89, average: 17.74, strikeRate: 17.1, high: 8 }
    }
  },
  {
    id: 'p-jaiswal',
    name: 'Yashasvi Jaiswal',
    country: 'India',
    team: 'India',
    role: 'Batter',
    category: "Men's",
    formats: ['Test', 'T20', 'ODI'],
    battingStyle: 'Left hand Bat',
    bowlingStyle: 'Right arm Legbreak',
    stats: {
      test: { matches: 16, runs: 1540, wickets: 0, average: 57.03, strikeRate: 68.4, high: 214 },
      odi: { matches: 4, runs: 162, wickets: 0, average: 40.5, strikeRate: 95.2, high: 68 },
      t20: { matches: 23, runs: 723, wickets: 0, average: 36.15, strikeRate: 164.3, high: 100 }
    }
  },
  {
    id: 'p-pant',
    name: 'Rishabh Pant',
    country: 'India',
    team: 'India',
    role: 'Wicketkeeper',
    category: "Men's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Left hand Bat',
    bowlingStyle: 'Right arm Medium',
    stats: {
      test: { matches: 38, runs: 2690, wickets: 0, average: 43.38, strikeRate: 73.6, high: 159 },
      odi: { matches: 31, runs: 871, wickets: 0, average: 34.84, strikeRate: 106.6, high: 125 },
      t20: { matches: 76, runs: 1209, wickets: 0, average: 23.25, strikeRate: 127.3, high: 65 }
    }
  },
  {
    id: 'p-hardik',
    name: 'Hardik Pandya',
    country: 'India',
    team: 'India',
    role: 'All-Rounder',
    category: "Men's",
    formats: ['ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Fast-Medium',
    stats: {
      test: { matches: 11, runs: 532, wickets: 17, average: 31.29, strikeRate: 73.8, high: 108 },
      odi: { matches: 86, runs: 1769, wickets: 84, average: 34.01, strikeRate: 110.3, high: 92 },
      t20: { matches: 104, runs: 1641, wickets: 87, average: 27.81, strikeRate: 141.2, high: 71 }
    }
  },
  {
    id: 'p-rahul',
    name: 'KL Rahul',
    country: 'India',
    team: 'India',
    role: 'Wicketkeeper',
    category: "Men's",
    formats: ['ODI', 'Test'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Medium',
    stats: {
      test: { matches: 53, runs: 2981, wickets: 0, average: 34.26, strikeRate: 52.8, high: 199 },
      odi: { matches: 77, runs: 2851, wickets: 0, average: 49.15, strikeRate: 87.6, high: 112 },
      t20: { matches: 72, runs: 2265, wickets: 0, average: 37.75, strikeRate: 139.1, high: 110 }
    }
  },
  {
    id: 'p-iyer',
    name: 'Shreyas Iyer',
    country: 'India',
    team: 'India',
    role: 'Batter',
    category: "Men's",
    formats: ['ODI', 'Test'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Offbreak',
    stats: {
      test: { matches: 14, runs: 811, wickets: 0, average: 36.86, strikeRate: 63.2, high: 105 },
      odi: { matches: 62, runs: 2421, wickets: 0, average: 47.47, strikeRate: 100.8, high: 128 },
      t20: { matches: 51, runs: 1104, wickets: 0, average: 30.66, strikeRate: 136.1, high: 74 }
    }
  },
  {
    id: 'p-axar',
    name: 'Axar Patel',
    country: 'India',
    team: 'India',
    role: 'All-Rounder',
    category: "Men's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Left hand Bat',
    bowlingStyle: 'Slow Left-Arm Orthodox',
    stats: {
      test: { matches: 14, runs: 646, wickets: 55, average: 35.88, strikeRate: 56.7, high: 84 },
      odi: { matches: 60, runs: 538, wickets: 64, average: 21.52, strikeRate: 98.5, high: 64 },
      t20: { matches: 62, runs: 478, wickets: 58, average: 21.72, strikeRate: 143.5, high: 65 }
    }
  },
  {
    id: 'p-kuldeep',
    name: 'Kuldeep Yadav',
    country: 'India',
    team: 'India',
    role: 'Bowler',
    category: "Men's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Left hand Bat',
    bowlingStyle: 'Left-arm Wrist Spin',
    stats: {
      test: { matches: 13, runs: 188, wickets: 56, average: 22.16, strikeRate: 41.5, high: 40 },
      odi: { matches: 106, runs: 182, wickets: 172, average: 26.01, strikeRate: 29.8, high: 19 },
      t20: { matches: 40, runs: 46, wickets: 69, average: 14.07, strikeRate: 12.2, high: 23 }
    }
  },
  {
    id: 'p-siraj',
    name: 'Mohammed Siraj',
    country: 'India',
    team: 'India',
    role: 'Bowler',
    category: "Men's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Fast',
    stats: {
      test: { matches: 31, runs: 114, wickets: 80, average: 29.82, strikeRate: 49.8, high: 16 },
      odi: { matches: 44, runs: 38, wickets: 71, average: 24.04, strikeRate: 27.4, high: 9 },
      t20: { matches: 16, runs: 6, wickets: 14, average: 33.78, strikeRate: 25.7, high: 5 }
    }
  },
  {
    id: 'p-arshdeep',
    name: 'Arshdeep Singh',
    country: 'India',
    team: 'India',
    role: 'Bowler',
    category: "Men's",
    formats: ['T20', 'ODI'],
    battingStyle: 'Left hand Bat',
    bowlingStyle: 'Left arm Fast-Medium',
    stats: {
      odi: { matches: 9, runs: 28, wickets: 14, average: 25.28, strikeRate: 28.5, high: 18 },
      t20: { matches: 60, runs: 48, wickets: 95, average: 18.29, strikeRate: 13.4, high: 12 }
    }
  },
  {
    id: 'p-rinku',
    name: 'Rinku Singh',
    country: 'India',
    team: 'India',
    role: 'Batter',
    category: "Men's",
    formats: ['T20', 'ODI'],
    battingStyle: 'Left hand Bat',
    bowlingStyle: 'Right arm Offbreak',
    stats: {
      odi: { matches: 2, runs: 55, wickets: 1, average: 27.5, strikeRate: 134.1, high: 38 },
      t20: { matches: 28, runs: 518, wickets: 2, average: 57.55, strikeRate: 172.6, high: 69 }
    }
  },
  {
    id: 'p-sundar',
    name: 'Washington Sundar',
    country: 'India',
    team: 'India',
    role: 'All-Rounder',
    category: "Men's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Left hand Bat',
    bowlingStyle: 'Right arm Offbreak',
    stats: {
      test: { matches: 6, runs: 352, wickets: 18, average: 44.0, strikeRate: 52.4, high: 96 },
      odi: { matches: 22, runs: 315, wickets: 23, average: 26.25, strikeRate: 85.3, high: 51 },
      t20: { matches: 52, runs: 161, wickets: 47, average: 23.44, strikeRate: 20.8, high: 50 }
    }
  },
  {
    id: 'p-harshit',
    name: 'Harshit Rana',
    country: 'India',
    team: 'India',
    role: 'Bowler',
    category: "Men's",
    formats: ['ODI', 'T20', 'Test'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Fast',
    stats: {
      test: { matches: 1, runs: 12, wickets: 4, average: 22.5, strikeRate: 36.0, high: 12 },
      odi: { matches: 3, runs: 18, wickets: 6, average: 24.3, strikeRate: 27.0, high: 14 },
      t20: { matches: 5, runs: 24, wickets: 8, average: 19.8, strikeRate: 14.2, high: 15 }
    }
  },

  // ================= AUSTRALIA MEN (13 Players) =================
  {
    id: 'p-4',
    name: 'Pat Cummins',
    country: 'Australia',
    team: 'Australia',
    role: 'Bowler',
    category: "Men's",
    formats: ['Test', 'ODI', 'T20'],
    isCaptain: true,
    captainFormat: 'Test & ODI Captain',
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Fast',
    stats: {
      test: { matches: 64, runs: 1380, wickets: 272, average: 22.48, strikeRate: 46.5, high: 64 },
      odi: { matches: 88, runs: 450, wickets: 141, average: 28.14, strikeRate: 32.8, high: 37 },
      t20: { matches: 58, runs: 220, wickets: 66, average: 24.31, strikeRate: 18.9, high: 28 }
    }
  },
  {
    id: 'p-marsh',
    name: 'Mitchell Marsh',
    country: 'Australia',
    team: 'Australia',
    role: 'All-Rounder',
    category: "Men's",
    formats: ['T20', 'ODI', 'Test'],
    isCaptain: true,
    captainFormat: 'T20I Captain',
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Medium',
    stats: {
      test: { matches: 42, runs: 2010, wickets: 51, average: 30.45, strikeRate: 58.2, high: 181 },
      odi: { matches: 89, runs: 2780, wickets: 57, average: 35.64, strikeRate: 94.6, high: 177 },
      t20: { matches: 64, runs: 1620, wickets: 17, average: 34.46, strikeRate: 136.2, high: 92 }
    }
  },
  {
    id: 'p-5',
    name: 'Travis Head',
    country: 'Australia',
    team: 'Australia',
    role: 'Batter',
    category: "Men's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Left hand Bat',
    bowlingStyle: 'Right arm Offbreak',
    stats: {
      test: { matches: 51, runs: 3240, wickets: 15, average: 41.53, strikeRate: 64.8, high: 175 },
      odi: { matches: 68, runs: 2540, wickets: 18, average: 44.56, strikeRate: 104.2, high: 154 },
      t20: { matches: 38, runs: 1120, wickets: 3, average: 34.9, strikeRate: 158.4, high: 91 }
    }
  },
  {
    id: 'p-smith',
    name: 'Steve Smith',
    country: 'Australia',
    team: 'Australia',
    role: 'Batter',
    category: "Men's",
    formats: ['Test', 'ODI'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Legbreak',
    stats: {
      test: { matches: 109, runs: 9685, wickets: 19, average: 56.97, strikeRate: 53.6, high: 239 },
      odi: { matches: 158, runs: 5446, wickets: 28, average: 43.91, strikeRate: 87.4, high: 164 }
    }
  },
  {
    id: 'p-starc',
    name: 'Mitchell Starc',
    country: 'Australia',
    team: 'Australia',
    role: 'Bowler',
    category: "Men's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Left hand Bat',
    bowlingStyle: 'Left arm Fast',
    stats: {
      test: { matches: 89, runs: 2096, wickets: 358, average: 27.74, strikeRate: 48.2, high: 99 },
      odi: { matches: 121, runs: 554, wickets: 236, average: 22.96, strikeRate: 26.1, high: 52 },
      t20: { matches: 65, runs: 95, wickets: 79, average: 23.81, strikeRate: 18.2, high: 14 }
    }
  },
  {
    id: 'p-maxwell',
    name: 'Glenn Maxwell',
    country: 'Australia',
    team: 'Australia',
    role: 'All-Rounder',
    category: "Men's",
    formats: ['ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Offbreak',
    stats: {
      odi: { matches: 142, runs: 3934, wickets: 70, average: 35.12, strikeRate: 126.9, high: 201 },
      t20: { matches: 110, runs: 2600, wickets: 43, average: 29.54, strikeRate: 155.6, high: 145 }
    }
  },
  {
    id: 'p-zampa',
    name: 'Adam Zampa',
    country: 'Australia',
    team: 'Australia',
    role: 'Bowler',
    category: "Men's",
    formats: ['ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Legbreak',
    stats: {
      odi: { matches: 101, runs: 215, wickets: 172, average: 28.18, strikeRate: 31.4, high: 36 },
      t20: { matches: 92, runs: 65, wickets: 111, average: 21.84, strikeRate: 18.0, high: 13 }
    }
  },
  {
    id: 'p-inglis',
    name: 'Josh Inglis',
    country: 'Australia',
    team: 'Australia',
    role: 'Wicketkeeper',
    category: "Men's",
    formats: ['T20', 'ODI'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Offbreak',
    stats: {
      odi: { matches: 26, runs: 580, wickets: 0, average: 29.0, strikeRate: 98.4, high: 65 },
      t20: { matches: 30, runs: 690, wickets: 0, average: 31.36, strikeRate: 154.2, high: 110 }
    }
  },
  {
    id: 'p-stoinis',
    name: 'Marcus Stoinis',
    country: 'Australia',
    team: 'Australia',
    role: 'All-Rounder',
    category: "Men's",
    formats: ['ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Medium-Fast',
    stats: {
      odi: { matches: 70, runs: 1440, wickets: 48, average: 27.16, strikeRate: 93.5, high: 146 },
      t20: { matches: 68, runs: 1180, wickets: 45, average: 31.05, strikeRate: 147.2, high: 78 }
    }
  },
  {
    id: 'p-hazlewood',
    name: 'Josh Hazlewood',
    country: 'Australia',
    team: 'Australia',
    role: 'Bowler',
    category: "Men's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Left hand Bat',
    bowlingStyle: 'Right arm Fast-Medium',
    stats: {
      test: { matches: 70, runs: 390, wickets: 273, average: 24.82, strikeRate: 53.4, high: 32 },
      odi: { matches: 88, runs: 85, wickets: 132, average: 26.42, strikeRate: 35.8, high: 11 },
      t20: { matches: 53, runs: 28, wickets: 67, average: 21.05, strikeRate: 17.5, high: 13 }
    }
  },
  {
    id: 'p-labuschagne',
    name: 'Marnus Labuschagne',
    country: 'Australia',
    team: 'Australia',
    role: 'Batter',
    category: "Men's",
    formats: ['Test', 'ODI'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Legbreak',
    stats: {
      test: { matches: 50, runs: 4114, wickets: 13, average: 49.56, strikeRate: 52.4, high: 215 },
      odi: { matches: 59, runs: 1780, wickets: 10, average: 37.87, strikeRate: 83.2, high: 124 }
    }
  },
  {
    id: 'p-timdavid',
    name: 'Tim David',
    country: 'Australia',
    team: 'Australia',
    role: 'Batter',
    category: "Men's",
    formats: ['T20', 'ODI'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Offbreak',
    stats: {
      odi: { matches: 4, runs: 45, wickets: 0, average: 15.0, strikeRate: 112.5, high: 35 },
      t20: { matches: 46, runs: 1120, wickets: 5, average: 34.0, strikeRate: 161.4, high: 92 }
    }
  },
  {
    id: 'p-ellis',
    name: 'Nathan Ellis',
    country: 'Australia',
    team: 'Australia',
    role: 'Bowler',
    category: "Men's",
    formats: ['T20', 'ODI'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Fast-Medium',
    stats: {
      odi: { matches: 8, runs: 32, wickets: 10, average: 34.2, strikeRate: 36.0, high: 19 },
      t20: { matches: 17, runs: 38, wickets: 28, average: 17.85, strikeRate: 13.5, high: 14 }
    }
  },

  // ================= SOUTH AFRICA MEN (12 Players) =================
  {
    id: 'p-bavuma',
    name: 'Temba Bavuma',
    country: 'South Africa',
    team: 'South Africa',
    role: 'Batter',
    category: "Men's",
    formats: ['Test', 'ODI'],
    isCaptain: true,
    captainFormat: 'Test & ODI Captain',
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Medium',
    stats: {
      test: { matches: 59, runs: 3180, wickets: 1, average: 36.55, strikeRate: 47.8, high: 172 },
      odi: { matches: 42, runs: 1620, wickets: 0, average: 46.28, strikeRate: 89.2, high: 144 }
    }
  },
  {
    id: 'p-markram',
    name: 'Aiden Markram',
    country: 'South Africa',
    team: 'South Africa',
    role: 'Batter',
    category: "Men's",
    formats: ['Test', 'ODI', 'T20'],
    isCaptain: true,
    captainFormat: 'T20I Captain',
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Offbreak',
    stats: {
      test: { matches: 40, runs: 2480, wickets: 3, average: 35.94, strikeRate: 64.2, high: 152 },
      odi: { matches: 71, runs: 2210, wickets: 20, average: 37.45, strikeRate: 98.4, high: 175 },
      t20: { matches: 53, runs: 1340, wickets: 12, average: 34.35, strikeRate: 146.5, high: 70 }
    }
  },
  {
    id: 'p-klaasen',
    name: 'Heinrich Klaasen',
    country: 'South Africa',
    team: 'South Africa',
    role: 'Wicketkeeper',
    category: "Men's",
    formats: ['ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Offbreak',
    stats: {
      odi: { matches: 56, runs: 1780, wickets: 0, average: 43.41, strikeRate: 114.8, high: 174 },
      t20: { matches: 58, runs: 1040, wickets: 0, average: 24.76, strikeRate: 145.2, high: 81 }
    }
  },
  {
    id: 'p-rabada',
    name: 'Kagiso Rabada',
    country: 'South Africa',
    team: 'South Africa',
    role: 'Bowler',
    category: "Men's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Left hand Bat',
    bowlingStyle: 'Right arm Fast',
    stats: {
      test: { matches: 64, runs: 980, wickets: 308, average: 22.05, strikeRate: 39.4, high: 47 },
      odi: { matches: 104, runs: 390, wickets: 161, average: 27.68, strikeRate: 32.5, high: 31 },
      t20: { matches: 65, runs: 150, wickets: 71, average: 27.15, strikeRate: 19.8, high: 22 }
    }
  },
  {
    id: 'p-miller',
    name: 'David Miller',
    country: 'South Africa',
    team: 'South Africa',
    role: 'Batter',
    category: "Men's",
    formats: ['ODI', 'T20'],
    battingStyle: 'Left hand Bat',
    bowlingStyle: 'Right arm Offbreak',
    stats: {
      odi: { matches: 173, runs: 4458, wickets: 0, average: 42.86, strikeRate: 103.5, high: 139 },
      t20: { matches: 125, runs: 2437, wickets: 0, average: 33.84, strikeRate: 140.7, high: 106 }
    }
  },
  {
    id: 'p-jansen',
    name: 'Marco Jansen',
    country: 'South Africa',
    team: 'South Africa',
    role: 'All-Rounder',
    category: "Men's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Left arm Fast',
    stats: {
      test: { matches: 14, runs: 420, wickets: 49, average: 22.87, strikeRate: 37.6, high: 84 },
      odi: { matches: 25, runs: 440, wickets: 37, average: 34.12, strikeRate: 138.4, high: 75 },
      t20: { matches: 18, runs: 120, wickets: 19, average: 26.42, strikeRate: 152.0, high: 28 }
    }
  },
  {
    id: 'p-qdk',
    name: 'Quinton de Kock',
    country: 'South Africa',
    team: 'South Africa',
    role: 'Wicketkeeper',
    category: "Men's",
    formats: ['ODI', 'T20'],
    battingStyle: 'Left hand Bat',
    bowlingStyle: 'Right arm Medium',
    stats: {
      odi: { matches: 155, runs: 6770, wickets: 0, average: 45.74, strikeRate: 96.6, high: 178 },
      t20: { matches: 92, runs: 2584, wickets: 0, average: 31.51, strikeRate: 138.4, high: 100 }
    }
  },
  {
    id: 'p-maharaj',
    name: 'Keshav Maharaj',
    country: 'South Africa',
    team: 'South Africa',
    role: 'Bowler',
    category: "Men's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Slow Left-Arm Orthodox',
    stats: {
      test: { matches: 54, runs: 1140, wickets: 171, average: 30.82, strikeRate: 63.4, high: 84 },
      odi: { matches: 47, runs: 240, wickets: 58, average: 31.42, strikeRate: 40.2, high: 40 },
      t20: { matches: 38, runs: 85, wickets: 42, average: 24.18, strikeRate: 20.4, high: 17 }
    }
  },
  {
    id: 'p-nortje',
    name: 'Anrich Nortje',
    country: 'South Africa',
    team: 'South Africa',
    role: 'Bowler',
    category: "Men's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Fast',
    stats: {
      test: { matches: 19, runs: 165, wickets: 70, average: 26.71, strikeRate: 40.8, high: 28 },
      odi: { matches: 22, runs: 34, wickets: 36, average: 27.27, strikeRate: 29.8, high: 10 },
      t20: { matches: 42, runs: 24, wickets: 53, average: 20.35, strikeRate: 15.6, high: 8 }
    }
  },
  {
    id: 'p-ngidi',
    name: 'Lungi Ngidi',
    country: 'South Africa',
    team: 'South Africa',
    role: 'Bowler',
    category: "Men's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Fast',
    stats: {
      test: { matches: 19, runs: 120, wickets: 55, average: 24.65, strikeRate: 41.2, high: 19 },
      odi: { matches: 56, runs: 110, wickets: 88, average: 28.52, strikeRate: 29.2, high: 19 },
      t20: { matches: 45, runs: 40, wickets: 63, average: 21.44, strikeRate: 13.8, high: 12 }
    }
  },
  {
    id: 'p-stubbs',
    name: 'Tristan Stubbs',
    country: 'South Africa',
    team: 'South Africa',
    role: 'Batter',
    category: "Men's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Offbreak',
    stats: {
      test: { matches: 5, runs: 340, wickets: 1, average: 42.5, strikeRate: 61.0, high: 122 },
      odi: { matches: 6, runs: 180, wickets: 0, average: 36.0, strikeRate: 112.5, high: 68 },
      t20: { matches: 29, runs: 580, wickets: 0, average: 32.22, strikeRate: 148.0, high: 76 }
    }
  },
  {
    id: 'p-rickelton',
    name: 'Ryan Rickelton',
    country: 'South Africa',
    team: 'South Africa',
    role: 'Wicketkeeper',
    category: "Men's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Left hand Bat',
    bowlingStyle: 'Slow Left-Arm Orthodox',
    stats: {
      test: { matches: 5, runs: 240, wickets: 0, average: 26.66, strikeRate: 54.0, high: 52 },
      odi: { matches: 6, runs: 195, wickets: 0, average: 32.5, strikeRate: 92.4, high: 91 },
      t20: { matches: 10, runs: 265, wickets: 0, average: 29.44, strikeRate: 142.5, high: 76 }
    }
  },

  // ================= ENGLAND MEN (12 Players) =================
  {
    id: 'p-stokes',
    name: 'Ben Stokes',
    country: 'England',
    team: 'England',
    role: 'All-Rounder',
    category: "Men's",
    formats: ['Test'],
    isCaptain: true,
    captainFormat: 'Test Captain',
    battingStyle: 'Left hand Bat',
    bowlingStyle: 'Right arm Fast-Medium',
    stats: {
      test: { matches: 107, runs: 6540, wickets: 203, average: 35.73, strikeRate: 59.4, high: 258 },
      odi: { matches: 114, runs: 3463, wickets: 74, average: 38.91, strikeRate: 96.3, high: 182 },
      t20: { matches: 43, runs: 585, wickets: 26, average: 21.66, strikeRate: 128.0, high: 52 }
    }
  },
  {
    id: 'p-buttler',
    name: 'Jos Buttler',
    country: 'England',
    team: 'England',
    role: 'Wicketkeeper',
    category: "Men's",
    formats: ['ODI', 'T20'],
    isCaptain: true,
    captainFormat: 'ODI & T20I Captain',
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Medium',
    stats: {
      test: { matches: 57, runs: 2907, wickets: 0, average: 31.94, strikeRate: 54.2, high: 152 },
      odi: { matches: 181, runs: 5022, wickets: 0, average: 39.54, strikeRate: 117.1, high: 162 },
      t20: { matches: 124, runs: 3264, wickets: 0, average: 35.86, strikeRate: 146.3, high: 101 }
    }
  },
  {
    id: 'p-2',
    name: 'Joe Root',
    country: 'England',
    team: 'England',
    role: 'Batter',
    category: "Men's",
    formats: ['Test', 'ODI'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Offbreak',
    stats: {
      test: { matches: 148, runs: 12716, wickets: 70, average: 51.06, strikeRate: 56.4, high: 262 },
      odi: { matches: 173, runs: 6592, wickets: 27, average: 48.47, strikeRate: 86.8, high: 133 },
      t20: { matches: 32, runs: 893, wickets: 6, average: 35.72, strikeRate: 126.3, high: 90 }
    }
  },
  {
    id: 'p-6',
    name: 'Harry Brook',
    country: 'England',
    team: 'England',
    role: 'Batter',
    category: "Men's",
    formats: ['Test', 'ODI', 'T20'],
    isViceCaptain: true,
    captainFormat: 'White-Ball Vice-Captain',
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Medium',
    stats: {
      test: { matches: 21, runs: 1878, wickets: 1, average: 56.9, strikeRate: 88.2, high: 186 },
      odi: { matches: 24, runs: 792, wickets: 0, average: 41.68, strikeRate: 102.5, high: 110 },
      t20: { matches: 39, runs: 724, wickets: 0, average: 28.96, strikeRate: 146.8, high: 81 }
    }
  },
  {
    id: 'p-archer',
    name: 'Jofra Archer',
    country: 'England',
    team: 'England',
    role: 'Bowler',
    category: "Men's",
    formats: ['ODI', 'T20', 'Test'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Fast',
    stats: {
      test: { matches: 13, runs: 180, wickets: 42, average: 31.04, strikeRate: 57.2, high: 30 },
      odi: { matches: 28, runs: 95, wickets: 51, average: 24.84, strikeRate: 28.9, high: 24 },
      t20: { matches: 30, runs: 42, wickets: 38, average: 21.15, strikeRate: 16.8, high: 16 }
    }
  },
  {
    id: 'p-salt',
    name: 'Phil Salt',
    country: 'England',
    team: 'England',
    role: 'Wicketkeeper',
    category: "Men's",
    formats: ['T20', 'ODI'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Medium',
    stats: {
      odi: { matches: 26, runs: 850, wickets: 0, average: 35.41, strikeRate: 128.4, high: 122 },
      t20: { matches: 38, runs: 1150, wickets: 0, average: 35.93, strikeRate: 165.2, high: 119 }
    }
  },
  {
    id: 'p-livingstone',
    name: 'Liam Livingstone',
    country: 'England',
    team: 'England',
    role: 'All-Rounder',
    category: "Men's",
    formats: ['ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Legbreak',
    stats: {
      odi: { matches: 31, runs: 780, wickets: 18, average: 33.91, strikeRate: 112.5, high: 124 },
      t20: { matches: 50, runs: 860, wickets: 29, average: 25.29, strikeRate: 152.4, high: 103 }
    }
  },
  {
    id: 'p-curran',
    name: 'Sam Curran',
    country: 'England',
    team: 'England',
    role: 'All-Rounder',
    category: "Men's",
    formats: ['ODI', 'T20', 'Test'],
    battingStyle: 'Left hand Bat',
    bowlingStyle: 'Left arm Fast-Medium',
    stats: {
      test: { matches: 24, runs: 815, wickets: 47, average: 35.51, strikeRate: 64.0, high: 78 },
      odi: { matches: 35, runs: 450, wickets: 34, average: 37.8, strikeRate: 36.5, high: 95 },
      t20: { matches: 53, runs: 380, wickets: 53, average: 25.47, strikeRate: 17.8, high: 50 }
    }
  },
  {
    id: 'p-rashid-ad',
    name: 'Adil Rashid',
    country: 'England',
    team: 'England',
    role: 'Bowler',
    category: "Men's",
    formats: ['ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Legbreak',
    stats: {
      odi: { matches: 140, runs: 780, wickets: 205, average: 32.18, strikeRate: 35.2, high: 69 },
      t20: { matches: 118, runs: 120, wickets: 122, average: 25.12, strikeRate: 20.8, high: 19 }
    }
  },
  {
    id: 'p-wood',
    name: 'Mark Wood',
    country: 'England',
    team: 'England',
    role: 'Bowler',
    category: "Men's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Fast',
    stats: {
      test: { matches: 37, runs: 740, wickets: 119, average: 30.12, strikeRate: 51.2, high: 52 },
      odi: { matches: 66, runs: 130, wickets: 77, average: 38.45, strikeRate: 42.0, high: 17 },
      t20: { matches: 34, runs: 30, wickets: 50, average: 19.82, strikeRate: 14.5, high: 8 }
    }
  },
  {
    id: 'p-topley',
    name: 'Reece Topley',
    country: 'England',
    team: 'England',
    role: 'Bowler',
    category: "Men's",
    formats: ['ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Left arm Fast-Medium',
    stats: {
      odi: { matches: 32, runs: 45, wickets: 48, average: 27.56, strikeRate: 31.8, high: 11 },
      t20: { matches: 35, runs: 18, wickets: 38, average: 28.42, strikeRate: 19.5, high: 9 }
    }
  },
  {
    id: 'p-jacks',
    name: 'Will Jacks',
    country: 'England',
    team: 'England',
    role: 'All-Rounder',
    category: "Men's",
    formats: ['ODI', 'T20', 'Test'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Offbreak',
    stats: {
      test: { matches: 2, runs: 89, wickets: 6, average: 38.0, strikeRate: 54.0, high: 31 },
      odi: { matches: 14, runs: 420, wickets: 5, average: 35.0, strikeRate: 98.4, high: 94 },
      t20: { matches: 20, runs: 360, wickets: 4, average: 24.0, strikeRate: 154.2, high: 40 }
    }
  },

  // ================= NEW ZEALAND MEN (12 Players) =================
  {
    id: 'p-latham',
    name: 'Tom Latham',
    country: 'New Zealand',
    team: 'New Zealand',
    role: 'Wicketkeeper',
    category: "Men's",
    formats: ['Test', 'ODI'],
    isCaptain: true,
    captainFormat: 'Test Captain',
    battingStyle: 'Left hand Bat',
    bowlingStyle: 'Right arm Medium',
    stats: {
      test: { matches: 84, runs: 5460, wickets: 0, average: 39.85, strikeRate: 47.3, high: 264 },
      odi: { matches: 144, runs: 4050, wickets: 0, average: 34.61, strikeRate: 85.8, high: 145 }
    }
  },
  {
    id: 'p-santner',
    name: 'Mitchell Santner',
    country: 'New Zealand',
    team: 'New Zealand',
    role: 'All-Rounder',
    category: "Men's",
    formats: ['ODI', 'T20'],
    isCaptain: true,
    captainFormat: 'White-Ball Captain',
    battingStyle: 'Left hand Bat',
    bowlingStyle: 'Slow Left-Arm Orthodox',
    stats: {
      test: { matches: 29, runs: 1040, wickets: 64, average: 37.15, strikeRate: 68.2, high: 126 },
      odi: { matches: 105, runs: 1380, wickets: 106, average: 36.85, strikeRate: 91.2, high: 67 },
      t20: { matches: 104, runs: 680, wickets: 115, average: 22.18, strikeRate: 17.8, high: 77 }
    }
  },
  {
    id: 'p-kane',
    name: 'Kane Williamson',
    country: 'New Zealand',
    team: 'New Zealand',
    role: 'Batter',
    category: "Men's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Offbreak',
    stats: {
      test: { matches: 102, runs: 8881, wickets: 30, average: 54.48, strikeRate: 51.4, high: 251 },
      odi: { matches: 165, runs: 6810, wickets: 37, average: 48.64, strikeRate: 81.3, high: 148 },
      t20: { matches: 93, runs: 2575, wickets: 6, average: 33.44, strikeRate: 123.0, high: 95 }
    }
  },
  {
    id: 'p-conway',
    name: 'Devon Conway',
    country: 'New Zealand',
    team: 'New Zealand',
    role: 'Wicketkeeper',
    category: "Men's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Left hand Bat',
    bowlingStyle: 'Right arm Medium',
    stats: {
      test: { matches: 23, runs: 1680, wickets: 0, average: 41.0, strikeRate: 50.8, high: 200 },
      odi: { matches: 32, runs: 1240, wickets: 0, average: 44.28, strikeRate: 88.5, high: 152 },
      t20: { matches: 50, runs: 1410, wickets: 0, average: 38.10, strikeRate: 128.4, high: 99 }
    }
  },
  {
    id: 'p-daryl',
    name: 'Daryl Mitchell',
    country: 'New Zealand',
    team: 'New Zealand',
    role: 'All-Rounder',
    category: "Men's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Medium',
    stats: {
      test: { matches: 29, runs: 1720, wickets: 5, average: 47.77, strikeRate: 56.4, high: 190 },
      odi: { matches: 44, runs: 1680, wickets: 14, average: 52.50, strikeRate: 97.8, high: 134 },
      t20: { matches: 68, runs: 1340, wickets: 9, average: 26.8, strikeRate: 138.5, high: 72 }
    }
  },
  {
    id: 'p-phillips',
    name: 'Glenn Phillips',
    country: 'New Zealand',
    team: 'New Zealand',
    role: 'All-Rounder',
    category: "Men's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Offbreak',
    stats: {
      test: { matches: 10, runs: 520, wickets: 18, average: 34.66, strikeRate: 68.2, high: 87 },
      odi: { matches: 30, runs: 680, wickets: 15, average: 34.0, strikeRate: 98.4, high: 72 },
      t20: { matches: 78, runs: 1820, wickets: 19, average: 32.5, strikeRate: 143.8, high: 108 }
    }
  },
  {
    id: 'p-rachin',
    name: 'Rachin Ravindra',
    country: 'New Zealand',
    team: 'New Zealand',
    role: 'All-Rounder',
    category: "Men's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Left hand Bat',
    bowlingStyle: 'Slow Left-Arm Orthodox',
    stats: {
      test: { matches: 12, runs: 940, wickets: 12, average: 44.76, strikeRate: 58.4, high: 240 },
      odi: { matches: 28, runs: 980, wickets: 18, average: 42.6, strikeRate: 106.8, high: 123 },
      t20: { matches: 26, runs: 280, wickets: 13, average: 18.66, strikeRate: 126.0, high: 68 }
    }
  },
  {
    id: 'p-boult',
    name: 'Trent Boult',
    country: 'New Zealand',
    team: 'New Zealand',
    role: 'Bowler',
    category: "Men's",
    formats: ['ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Left arm Fast-Medium',
    stats: {
      test: { matches: 78, runs: 759, wickets: 317, average: 27.49, strikeRate: 55.8, high: 52 },
      odi: { matches: 114, runs: 185, wickets: 211, average: 23.97, strikeRate: 29.1, high: 21 },
      t20: { matches: 61, runs: 42, wickets: 83, average: 21.43, strikeRate: 16.8, high: 16 }
    }
  },
  {
    id: 'p-southee',
    name: 'Tim Southee',
    country: 'New Zealand',
    team: 'New Zealand',
    role: 'Bowler',
    category: "Men's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Fast-Medium',
    stats: {
      test: { matches: 104, runs: 2185, wickets: 385, average: 28.99, strikeRate: 58.5, high: 77 },
      odi: { matches: 161, runs: 740, wickets: 221, average: 33.46, strikeRate: 36.8, high: 55 },
      t20: { matches: 126, runs: 310, wickets: 164, average: 22.38, strikeRate: 16.4, high: 39 }
    }
  },
  {
    id: 'p-mhenry',
    name: 'Matt Henry',
    country: 'New Zealand',
    team: 'New Zealand',
    role: 'Bowler',
    category: "Men's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Fast-Medium',
    stats: {
      test: { matches: 27, runs: 580, wickets: 105, average: 30.82, strikeRate: 54.0, high: 72 },
      odi: { matches: 82, runs: 310, wickets: 145, average: 25.86, strikeRate: 29.8, high: 48 },
      t20: { matches: 17, runs: 18, wickets: 20, average: 26.2, strikeRate: 18.0, high: 10 }
    }
  },
  {
    id: 'p-lockie',
    name: 'Lockie Ferguson',
    country: 'New Zealand',
    team: 'New Zealand',
    role: 'Bowler',
    category: "Men's",
    formats: ['ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Fast',
    stats: {
      odi: { matches: 65, runs: 120, wickets: 99, average: 31.42, strikeRate: 34.0, high: 19 },
      t20: { matches: 42, runs: 28, wickets: 61, average: 17.85, strikeRate: 14.2, high: 14 }
    }
  },
  {
    id: 'p-sodhi',
    name: 'Ish Sodhi',
    country: 'New Zealand',
    team: 'New Zealand',
    role: 'Bowler',
    category: "Men's",
    formats: ['T20', 'ODI'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Legbreak',
    stats: {
      test: { matches: 20, runs: 540, wickets: 54, average: 44.5, strikeRate: 72.0, high: 65 },
      odi: { matches: 55, runs: 240, wickets: 65, average: 38.0, strikeRate: 41.5, high: 35 },
      t20: { matches: 115, runs: 165, wickets: 136, average: 23.14, strikeRate: 17.2, high: 19 }
    }
  }
];
