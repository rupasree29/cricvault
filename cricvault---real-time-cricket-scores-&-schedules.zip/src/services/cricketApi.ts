import { CricketMatch, CricketPlayer, CricketTeam, TournamentStandings } from '../types/cricket';
import { generateMatchesForDates, getDateString, PLAYERS_DATABASE, TEAMS_DATABASE, TOURNAMENT_STANDINGS } from './cricketDatabase';

// In-memory state for live ball-by-ball simulation that persists across poll calls
let activeMatches: CricketMatch[] = generateMatchesForDates();
let lastApiUpdateTimestamp = new Date();

// Possible ball outcomes for realistic cricket live updates
const BALL_OUTCOMES = [
  { run: 1, type: 'RUN' },
  { run: 0, type: 'DOT' },
  { run: 2, type: 'RUN' },
  { run: 4, type: 'FOUR' },
  { run: 1, type: 'RUN' },
  { run: 6, type: 'SIX' },
  { run: 0, type: 'DOT' },
  { run: 0, type: 'WICKET' },
  { run: 1, type: 'RUN' }
];

export const cricketApi = {
  // Check if an external API key is configured
  hasExternalApiKey(): boolean {
    return Boolean(import.meta.env.VITE_CRICKET_API_KEY && import.meta.env.VITE_CRICKET_API_KEY !== 'your_api_key');
  },

  // Returns timestamp of latest data fetch
  getLastUpdatedTime(): string {
    return lastApiUpdateTimestamp.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  },

  // Fetch all live matches
  async getLiveMatches(): Promise<CricketMatch[]> {
    this.tickLiveMatchScore();
    return activeMatches.filter(m => m.status === 'LIVE' || m.isLive === true);
  },

  // Fetch today's matches based on user's current date
  async getTodayMatches(): Promise<CricketMatch[]> {
    const todayStr = getDateString(0);
    // Returns matches matching today's actual date
    return activeMatches.filter(m => m.dateStr === todayStr);
  },

  // Fetch tomorrow's matches
  async getTomorrowMatches(category?: "Men's" | "Women's"): Promise<CricketMatch[]> {
    const tomorrowStr = getDateString(1);
    const tmrwMatches = activeMatches.filter(m => m.dateStr === tomorrowStr);
    if (!category) return tmrwMatches;
    return tmrwMatches.filter(m => m.category === category);
  },

  // Fetch day after tomorrow matches
  async getDayAfterTomorrowMatches(category?: "Men's" | "Women's"): Promise<CricketMatch[]> {
    const dayAfterStr = getDateString(2);
    const dayAfterMatches = activeMatches.filter(m => m.dateStr === dayAfterStr);
    if (!category) return dayAfterMatches;
    return dayAfterMatches.filter(m => m.category === category);
  },

  // Fetch future / upcoming matches (beyond tomorrow)
  async getUpcomingMatches(): Promise<CricketMatch[]> {
    const todayStr = getDateString(0);
    const tomorrowStr = getDateString(1);
    return activeMatches.filter(m => m.dateStr > tomorrowStr && m.status === 'UPCOMING');
  },

  // Fetch completed recent results
  async getRecentResults(): Promise<CricketMatch[]> {
    return activeMatches.filter(m => m.status === 'COMPLETED');
  },

  // Fetch match details by ID
  async getMatchById(matchId: string): Promise<CricketMatch | null> {
    const found = activeMatches.find(m => m.id === matchId);
    return found || null;
  },

  // Fetch players with filtering
  async getPlayers(params?: {
    country?: string;
    category?: "Men's" | "Women's" | 'All';
    format?: 'Test' | 'ODI' | 'T20' | 'All';
    search?: string;
  }): Promise<CricketPlayer[]> {
    let list = [...PLAYERS_DATABASE];
    if (params?.country && params.country !== 'All') {
      const c = params.country.toLowerCase();
      list = list.filter(p => p.country.toLowerCase() === c || p.team.toLowerCase().includes(c));
    }
    if (params?.category && params.category !== 'All') {
      list = list.filter(p => p.category === params.category);
    }
    if (params?.format && params.format !== 'All') {
      list = list.filter(p => p.formats.includes(params.format as any));
    }
    if (params?.search?.trim()) {
      const q = params.search.toLowerCase();
      list = list.filter(p => 
        p.name.toLowerCase().includes(q) || 
        p.country.toLowerCase().includes(q) || 
        p.team.toLowerCase().includes(q) ||
        (p.captainFormat && p.captainFormat.toLowerCase().includes(q))
      );
    }
    return list;
  },

  // Fetch teams
  async getTeams(category?: "Men's" | "Women's" | 'All'): Promise<CricketTeam[]> {
    let teams = [...TEAMS_DATABASE];
    if (category && category !== 'All') {
      teams = teams.filter(t => t.category === category);
    }
    return teams;
  },

  // Fetch points standings
  async getStandings(): Promise<TournamentStandings[]> {
    return TOURNAMENT_STANDINGS;
  },

  // Simulate or sync one live delivery update on the primary live match
  tickLiveMatchScore(): void {
    lastApiUpdateTimestamp = new Date();
    const liveMatch = activeMatches.find(m => m.id === 'match-live-1' && m.status === 'LIVE');
    if (!liveMatch || !liveMatch.team2.runs || liveMatch.team2.overs === undefined) return;

    // Sri Lanka is chasing 286 against England
    const randomEvent = BALL_OUTCOMES[Math.floor(Math.random() * BALL_OUTCOMES.length)];

    let runs = liveMatch.team2.runs;
    let wickets = liveMatch.team2.wickets || 5;
    let overs = liveMatch.team2.overs;

    // Increment ball
    const currentBallsTotal = Math.floor(overs) * 6 + Math.round((overs % 1) * 10);
    const newBallsTotal = currentBallsTotal + 1;
    const newOvers = Math.floor(newBallsTotal / 6) + (newBallsTotal % 6) / 10;

    if (randomEvent.type === 'WICKET') {
      wickets += 1;
      // Add to recent balls
      liveMatch.recentBalls = [...(liveMatch.recentBalls || []).slice(-5), 'W'];
      if (liveMatch.currentBatsmen && liveMatch.currentBatsmen.length > 0) {
        liveMatch.currentBatsmen[0].dismissal = 'c Buttler b Archer';
        liveMatch.currentBatsmen[0] = {
          name: 'Dunith Wellalage',
          runs: 0,
          balls: 1,
          fours: 0,
          sixes: 0,
          strikeRate: 0.0,
          isOnStrike: true
        };
      }
    } else {
      runs += randomEvent.run;
      liveMatch.recentBalls = [...(liveMatch.recentBalls || []).slice(-5), String(randomEvent.run)];
      if (liveMatch.currentBatsmen && liveMatch.currentBatsmen.length > 0) {
        const striker = liveMatch.currentBatsmen[0];
        striker.runs += randomEvent.run;
        striker.balls += 1;
        if (randomEvent.run === 4) striker.fours += 1;
        if (randomEvent.run === 6) striker.sixes += 1;
        striker.strikeRate = Math.round((striker.runs / striker.balls) * 10000) / 100;
        
        // Single rotates strike
        if (randomEvent.run % 2 === 1 && liveMatch.currentBatsmen.length > 1) {
          liveMatch.currentBatsmen.reverse();
          liveMatch.currentBatsmen[0].isOnStrike = true;
          liveMatch.currentBatsmen[1].isOnStrike = false;
        }
      }
    }

    if (liveMatch.currentBowler) {
      liveMatch.currentBowler.runs += randomEvent.run;
      if (randomEvent.type === 'WICKET') liveMatch.currentBowler.wickets += 1;
      const bBalls = Math.floor(liveMatch.currentBowler.overs) * 6 + Math.round((liveMatch.currentBowler.overs % 1) * 10) + 1;
      liveMatch.currentBowler.overs = Math.floor(bBalls / 6) + (bBalls % 6) / 10;
      liveMatch.currentBowler.economy = Math.round((liveMatch.currentBowler.runs / (bBalls / 6)) * 100) / 100;
    }

    liveMatch.team2.runs = runs;
    liveMatch.team2.wickets = wickets;
    liveMatch.team2.overs = newOvers;
    liveMatch.team2.score = `${runs}/${wickets} (${newOvers.toFixed(1)})`;

    const target = liveMatch.target || 286;
    const runsReq = Math.max(0, target - runs);
    const ballsRemaining = Math.max(0, 300 - newBallsTotal);
    liveMatch.runsRequired = runsReq;
    liveMatch.ballsRemaining = ballsRemaining;
    liveMatch.currentRunRate = Math.round((runs / (newBallsTotal / 6)) * 100) / 100;
    liveMatch.requiredRunRate = ballsRemaining > 0 ? Math.round((runsReq / (ballsRemaining / 6)) * 100) / 100 : 0;

    // Check if match finished
    if (runs >= target) {
      liveMatch.status = 'COMPLETED';
      liveMatch.isLive = false;
      liveMatch.resultWinner = 'Sri Lanka';
      liveMatch.resultMargin = `${10 - wickets} wickets`;
      liveMatch.statusNote = `Sri Lanka won by ${10 - wickets} wkts`;
      liveMatch.playerOfTheMatch = 'Charith Asalanka (68* off 55)';
    } else if (wickets >= 10 || ballsRemaining <= 0) {
      liveMatch.status = 'COMPLETED';
      liveMatch.isLive = false;
      liveMatch.resultWinner = 'England';
      liveMatch.resultMargin = `${runsReq} runs`;
      liveMatch.statusNote = `England won by ${runsReq} runs`;
      liveMatch.playerOfTheMatch = 'Joe Root (78 off 84)';
    } else {
      liveMatch.statusNote = `Sri Lanka need ${runsReq} runs in ${ballsRemaining} balls`;
    }
  }
};
