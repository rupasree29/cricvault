import { CricketPlayer } from '../types/cricket';

export const WOMEN_PLAYERS: CricketPlayer[] = [
  // ================= INDIA WOMEN (11 Players) =================
  {
    id: 'pw-ind-1',
    name: 'Harmanpreet Kaur',
    country: 'India',
    team: 'India Women',
    role: 'All-Rounder',
    category: "Women's",
    formats: ['Test', 'ODI', 'T20'],
    isCaptain: true,
    captainFormat: 'India Women Captain',
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Offbreak',
    stats: {
      test: { matches: 6, runs: 356, wickets: 11, average: 39.55, strikeRate: 54.0, high: 69 },
      odi: { matches: 135, runs: 3540, wickets: 31, average: 37.65, strikeRate: 74.2, high: 171 },
      t20: { matches: 173, runs: 3415, wickets: 32, average: 27.99, strikeRate: 120.4, high: 103 }
    }
  },
  {
    id: 'pw-ind-2',
    name: 'Smriti Mandhana',
    country: 'India',
    team: 'India Women',
    role: 'Batter',
    category: "Women's",
    formats: ['Test', 'ODI', 'T20'],
    isViceCaptain: true,
    captainFormat: 'India Women Vice-Captain',
    battingStyle: 'Left hand Bat',
    bowlingStyle: 'Right arm Offbreak',
    stats: {
      test: { matches: 7, runs: 629, wickets: 0, average: 57.18, strikeRate: 58.4, high: 149 },
      odi: { matches: 87, runs: 3745, wickets: 0, average: 44.58, strikeRate: 84.6, high: 136 },
      t20: { matches: 142, runs: 3520, wickets: 0, average: 28.85, strikeRate: 122.8, high: 87 }
    }
  },
  {
    id: 'pw-ind-3',
    name: 'Shafali Verma',
    country: 'India',
    team: 'India Women',
    role: 'Batter',
    category: "Women's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Offbreak',
    stats: {
      test: { matches: 5, runs: 567, wickets: 1, average: 63.0, strikeRate: 75.4, high: 205 },
      odi: { matches: 26, runs: 589, wickets: 1, average: 23.56, strikeRate: 83.2, high: 71 },
      t20: { matches: 81, runs: 1948, wickets: 6, average: 25.63, strikeRate: 129.7, high: 81 }
    }
  },
  {
    id: 'pw-ind-4',
    name: 'Jemimah Rodrigues',
    country: 'India',
    team: 'India Women',
    role: 'Batter',
    category: "Women's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Offbreak',
    stats: {
      test: { matches: 3, runs: 235, wickets: 0, average: 58.75, strikeRate: 61.2, high: 73 },
      odi: { matches: 32, runs: 760, wickets: 5, average: 29.23, strikeRate: 75.8, high: 86 },
      t20: { matches: 100, runs: 2074, wickets: 0, average: 29.62, strikeRate: 114.2, high: 76 }
    }
  },
  {
    id: 'pw-ind-5',
    name: 'Deepti Sharma',
    country: 'India',
    team: 'India Women',
    role: 'All-Rounder',
    category: "Women's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Left hand Bat',
    bowlingStyle: 'Right arm Offbreak',
    stats: {
      test: { matches: 5, runs: 340, wickets: 20, average: 48.57, strikeRate: 49.2, high: 78 },
      odi: { matches: 90, runs: 2012, wickets: 108, average: 35.92, strikeRate: 67.8, high: 188 },
      t20: { matches: 117, runs: 1020, wickets: 131, average: 24.28, strikeRate: 106.3, high: 64 }
    }
  },
  {
    id: 'pw-ind-6',
    name: 'Richa Ghosh',
    country: 'India',
    team: 'India Women',
    role: 'Wicketkeeper',
    category: "Women's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Medium',
    stats: {
      test: { matches: 2, runs: 115, wickets: 0, average: 38.33, strikeRate: 71.0, high: 52 },
      odi: { matches: 23, runs: 442, wickets: 0, average: 26.0, strikeRate: 92.5, high: 96 },
      t20: { matches: 55, runs: 860, wickets: 0, average: 27.74, strikeRate: 140.5, high: 64 }
    }
  },
  {
    id: 'pw-ind-7',
    name: 'Pooja Vastrakar',
    country: 'India',
    team: 'India Women',
    role: 'All-Rounder',
    category: "Women's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Medium',
    stats: {
      test: { matches: 5, runs: 128, wickets: 14, average: 21.33, strikeRate: 38.4, high: 47 },
      odi: { matches: 33, runs: 520, wickets: 26, average: 23.63, strikeRate: 78.4, high: 62 },
      t20: { matches: 62, runs: 335, wickets: 44, average: 21.84, strikeRate: 122.0, high: 37 }
    }
  },
  {
    id: 'pw-ind-8',
    name: 'Renuka Singh Thakur',
    country: 'India',
    team: 'India Women',
    role: 'Bowler',
    category: "Women's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Medium-Fast',
    stats: {
      test: { matches: 2, runs: 4, wickets: 3, average: 38.0, strikeRate: 52.0, high: 4 },
      odi: { matches: 10, runs: 12, wickets: 19, average: 19.84, strikeRate: 26.5, high: 7 },
      t20: { matches: 47, runs: 15, wickets: 50, average: 23.58, strikeRate: 19.4, high: 5 }
    }
  },
  {
    id: 'pw-ind-9',
    name: 'Shreyanka Patil',
    country: 'India',
    team: 'India Women',
    role: 'Bowler',
    category: "Women's",
    formats: ['T20', 'ODI'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Offbreak',
    stats: {
      odi: { matches: 3, runs: 22, wickets: 5, average: 22.4, strikeRate: 30.0, high: 14 },
      t20: { matches: 16, runs: 34, wickets: 21, average: 18.28, strikeRate: 14.8, high: 12 }
    }
  },
  {
    id: 'pw-ind-10',
    name: 'Radha Yadav',
    country: 'India',
    team: 'India Women',
    role: 'Bowler',
    category: "Women's",
    formats: ['T20', 'ODI'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Slow Left-Arm Orthodox',
    stats: {
      odi: { matches: 7, runs: 45, wickets: 7, average: 32.14, strikeRate: 42.0, high: 18 },
      t20: { matches: 80, runs: 105, wickets: 90, average: 20.88, strikeRate: 17.5, high: 14 }
    }
  },
  {
    id: 'pw-ind-11',
    name: 'Yastika Bhatia',
    country: 'India',
    team: 'India Women',
    role: 'Wicketkeeper',
    category: "Women's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Left hand Bat',
    bowlingStyle: 'Slow Left-Arm Orthodox',
    stats: {
      test: { matches: 3, runs: 112, wickets: 0, average: 28.0, strikeRate: 50.4, high: 66 },
      odi: { matches: 28, runs: 654, wickets: 0, average: 26.16, strikeRate: 73.2, high: 64 },
      t20: { matches: 19, runs: 216, wickets: 0, average: 15.42, strikeRate: 92.3, high: 41 }
    }
  },

  // ================= AUSTRALIA WOMEN (11 Players) =================
  {
    id: 'pw-aus-1',
    name: 'Alyssa Healy',
    country: 'Australia',
    team: 'Australia Women',
    role: 'Wicketkeeper',
    category: "Women's",
    formats: ['Test', 'ODI', 'T20'],
    isCaptain: true,
    captainFormat: 'Australia Women Captain',
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Medium',
    stats: {
      test: { matches: 9, runs: 498, wickets: 0, average: 35.57, strikeRate: 60.1, high: 99 },
      odi: { matches: 110, runs: 3320, wickets: 0, average: 36.88, strikeRate: 100.8, high: 170 },
      t20: { matches: 160, runs: 3054, wickets: 0, average: 25.45, strikeRate: 130.2, high: 148 }
    }
  },
  {
    id: 'pw-aus-2',
    name: 'Ellyse Perry',
    country: 'Australia',
    team: 'Australia Women',
    role: 'All-Rounder',
    category: "Women's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Fast-Medium',
    stats: {
      test: { matches: 13, runs: 925, wickets: 39, average: 66.07, strikeRate: 46.2, high: 213 },
      odi: { matches: 148, runs: 3912, wickets: 165, average: 50.15, strikeRate: 77.8, high: 112 },
      t20: { matches: 158, runs: 1912, wickets: 126, average: 31.86, strikeRate: 116.4, high: 75 }
    }
  },
  {
    id: 'pw-aus-3',
    name: 'Beth Mooney',
    country: 'Australia',
    team: 'Australia Women',
    role: 'Batter',
    category: "Women's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Left hand Bat',
    bowlingStyle: 'Right arm Wicketkeeper',
    stats: {
      test: { matches: 7, runs: 420, wickets: 0, average: 38.18, strikeRate: 52.4, high: 125 },
      odi: { matches: 74, runs: 2380, wickets: 0, average: 51.73, strikeRate: 88.5, high: 133 },
      t20: { matches: 103, runs: 3010, wickets: 0, average: 39.60, strikeRate: 124.8, high: 117 }
    }
  },
  {
    id: 'pw-aus-4',
    name: 'Tahlia McGrath',
    country: 'Australia',
    team: 'Australia Women',
    role: 'All-Rounder',
    category: "Women's",
    formats: ['Test', 'ODI', 'T20'],
    isViceCaptain: true,
    captainFormat: 'Australia Women Vice-Captain',
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Medium',
    stats: {
      test: { matches: 5, runs: 220, wickets: 6, average: 31.42, strikeRate: 57.0, high: 73 },
      odi: { matches: 42, runs: 610, wickets: 24, average: 30.50, strikeRate: 87.2, high: 74 },
      t20: { matches: 48, runs: 960, wickets: 18, average: 40.0, strikeRate: 134.8, high: 91 }
    }
  },
  {
    id: 'pw-aus-5',
    name: 'Ashleigh Gardner',
    country: 'Australia',
    team: 'Australia Women',
    role: 'All-Rounder',
    category: "Women's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Offbreak',
    stats: {
      test: { matches: 6, runs: 260, wickets: 16, average: 28.88, strikeRate: 64.0, high: 84 },
      odi: { matches: 66, runs: 950, wickets: 82, average: 25.67, strikeRate: 110.4, high: 67 },
      t20: { matches: 92, runs: 1320, wickets: 74, average: 24.9, strikeRate: 132.5, high: 93 }
    }
  },
  {
    id: 'pw-aus-6',
    name: 'Annabel Sutherland',
    country: 'Australia',
    team: 'Australia Women',
    role: 'All-Rounder',
    category: "Women's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Fast-Medium',
    stats: {
      test: { matches: 5, runs: 490, wickets: 14, average: 70.0, strikeRate: 66.8, high: 210 },
      odi: { matches: 35, runs: 530, wickets: 34, average: 37.85, strikeRate: 98.2, high: 109 },
      t20: { matches: 34, runs: 165, wickets: 22, average: 18.33, strikeRate: 135.0, high: 22 }
    }
  },
  {
    id: 'pw-aus-7',
    name: 'Phoebe Litchfield',
    country: 'Australia',
    team: 'Australia Women',
    role: 'Batter',
    category: "Women's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Left hand Bat',
    bowlingStyle: 'Right arm Legbreak',
    stats: {
      test: { matches: 3, runs: 160, wickets: 0, average: 32.0, strikeRate: 54.0, high: 52 },
      odi: { matches: 20, runs: 780, wickets: 0, average: 52.0, strikeRate: 84.8, high: 119 },
      t20: { matches: 18, runs: 280, wickets: 0, average: 31.11, strikeRate: 148.9, high: 52 }
    }
  },
  {
    id: 'pw-aus-8',
    name: 'Georgia Wareham',
    country: 'Australia',
    team: 'Australia Women',
    role: 'All-Rounder',
    category: "Women's",
    formats: ['ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Legbreak',
    stats: {
      odi: { matches: 46, runs: 210, wickets: 48, average: 31.50, strikeRate: 34.0, high: 26 },
      t20: { matches: 57, runs: 260, wickets: 58, average: 18.96, strikeRate: 17.2, high: 32 }
    }
  },
  {
    id: 'pw-aus-9',
    name: 'Alana King',
    country: 'Australia',
    team: 'Australia Women',
    role: 'Bowler',
    category: "Women's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Legbreak',
    stats: {
      test: { matches: 3, runs: 42, wickets: 6, average: 34.0, strikeRate: 68.0, high: 18 },
      odi: { matches: 32, runs: 90, wickets: 45, average: 21.73, strikeRate: 31.0, high: 26 },
      t20: { matches: 24, runs: 30, wickets: 23, average: 18.26, strikeRate: 19.5, high: 18 }
    }
  },
  {
    id: 'pw-aus-10',
    name: 'Megan Schutt',
    country: 'Australia',
    team: 'Australia Women',
    role: 'Bowler',
    category: "Women's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Medium-Fast',
    stats: {
      test: { matches: 5, runs: 24, wickets: 10, average: 35.0, strikeRate: 64.0, high: 10 },
      odi: { matches: 90, runs: 85, wickets: 126, average: 23.94, strikeRate: 34.2, high: 12 },
      t20: { matches: 116, runs: 34, wickets: 145, average: 16.82, strikeRate: 15.6, high: 8 }
    }
  },
  {
    id: 'pw-aus-11',
    name: 'Grace Harris',
    country: 'Australia',
    team: 'Australia Women',
    role: 'All-Rounder',
    category: "Women's",
    formats: ['T20', 'ODI'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Offbreak',
    stats: {
      odi: { matches: 11, runs: 78, wickets: 5, average: 15.6, strikeRate: 102.6, high: 28 },
      t20: { matches: 45, runs: 460, wickets: 9, average: 24.21, strikeRate: 164.2, high: 64 }
    }
  },

  // ================= SOUTH AFRICA WOMEN (11 Players) =================
  {
    id: 'pw-rsa-1',
    name: 'Laura Wolvaardt',
    country: 'South Africa',
    team: 'South Africa Women',
    role: 'Batter',
    category: "Women's",
    formats: ['Test', 'ODI', 'T20'],
    isCaptain: true,
    captainFormat: 'South Africa Women Captain',
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Offbreak',
    stats: {
      test: { matches: 3, runs: 180, wickets: 0, average: 30.0, strikeRate: 46.2, high: 122 },
      odi: { matches: 98, runs: 3980, wickets: 0, average: 47.95, strikeRate: 72.8, high: 184 },
      t20: { matches: 75, runs: 1980, wickets: 0, average: 36.66, strikeRate: 116.5, high: 102 }
    }
  },
  {
    id: 'pw-rsa-2',
    name: 'Marizanne Kapp',
    country: 'South Africa',
    team: 'South Africa Women',
    role: 'All-Rounder',
    category: "Women's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Medium-Fast',
    stats: {
      test: { matches: 4, runs: 312, wickets: 9, average: 52.0, strikeRate: 58.2, high: 150 },
      odi: { matches: 142, runs: 2890, wickets: 154, average: 33.21, strikeRate: 74.5, high: 102 },
      t20: { matches: 106, runs: 1580, wickets: 85, average: 21.35, strikeRate: 115.0, high: 75 }
    }
  },
  {
    id: 'pw-rsa-3',
    name: 'Tazmin Brits',
    country: 'South Africa',
    team: 'South Africa Women',
    role: 'Batter',
    category: "Women's",
    formats: ['ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Medium',
    stats: {
      odi: { matches: 30, runs: 750, wickets: 0, average: 28.84, strikeRate: 68.4, high: 118 },
      t20: { matches: 54, runs: 1420, wickets: 0, average: 32.27, strikeRate: 112.4, high: 78 }
    }
  },
  {
    id: 'pw-rsa-4',
    name: 'Anneke Bosch',
    country: 'South Africa',
    team: 'South Africa Women',
    role: 'Batter',
    category: "Women's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Medium',
    stats: {
      test: { matches: 2, runs: 85, wickets: 3, average: 28.33, strikeRate: 48.0, high: 43 },
      odi: { matches: 24, runs: 460, wickets: 5, average: 24.21, strikeRate: 72.8, high: 65 },
      t20: { matches: 44, runs: 880, wickets: 8, average: 26.66, strikeRate: 110.2, high: 74 }
    }
  },
  {
    id: 'pw-rsa-5',
    name: 'Suné Luus',
    country: 'South Africa',
    team: 'South Africa Women',
    role: 'All-Rounder',
    category: "Women's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Legbreak',
    stats: {
      test: { matches: 3, runs: 185, wickets: 2, average: 37.0, strikeRate: 52.0, high: 109 },
      odi: { matches: 122, runs: 2150, wickets: 115, average: 24.71, strikeRate: 71.0, high: 107 },
      t20: { matches: 120, runs: 1420, wickets: 52, average: 21.51, strikeRate: 108.5, high: 71 }
    }
  },
  {
    id: 'pw-rsa-6',
    name: 'Chloe Tryon',
    country: 'South Africa',
    team: 'South Africa Women',
    role: 'All-Rounder',
    category: "Women's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Slow Left-Arm Orthodox',
    stats: {
      test: { matches: 2, runs: 84, wickets: 1, average: 28.0, strikeRate: 64.0, high: 64 },
      odi: { matches: 108, runs: 1850, wickets: 46, average: 25.69, strikeRate: 101.4, high: 92 },
      t20: { matches: 102, runs: 1220, wickets: 38, average: 18.76, strikeRate: 135.2, high: 57 }
    }
  },
  {
    id: 'pw-rsa-7',
    name: 'Nadine de Klerk',
    country: 'South Africa',
    team: 'South Africa Women',
    role: 'All-Rounder',
    category: "Women's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Medium',
    stats: {
      test: { matches: 2, runs: 42, wickets: 4, average: 21.0, strikeRate: 46.0, high: 38 },
      odi: { matches: 45, runs: 610, wickets: 42, average: 25.41, strikeRate: 78.5, high: 60 },
      t20: { matches: 58, runs: 490, wickets: 46, average: 24.5, strikeRate: 118.0, high: 37 }
    }
  },
  {
    id: 'pw-rsa-8',
    name: 'Sinalo Jafta',
    country: 'South Africa',
    team: 'South Africa Women',
    role: 'Wicketkeeper',
    category: "Women's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Medium',
    stats: {
      test: { matches: 3, runs: 38, wickets: 0, average: 9.5, strikeRate: 36.0, high: 15 },
      odi: { matches: 38, runs: 180, wickets: 0, average: 11.25, strikeRate: 62.0, high: 28 },
      t20: { matches: 48, runs: 130, wickets: 0, average: 10.83, strikeRate: 88.0, high: 16 }
    }
  },
  {
    id: 'pw-rsa-9',
    name: 'Nonkululeko Mlaba',
    country: 'South Africa',
    team: 'South Africa Women',
    role: 'Bowler',
    category: "Women's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Slow Left-Arm Orthodox',
    stats: {
      test: { matches: 3, runs: 14, wickets: 5, average: 32.0, strikeRate: 68.0, high: 8 },
      odi: { matches: 45, runs: 42, wickets: 44, average: 34.2, strikeRate: 44.0, high: 9 },
      t20: { matches: 55, runs: 28, wickets: 54, average: 21.46, strikeRate: 20.2, high: 6 }
    }
  },
  {
    id: 'pw-rsa-10',
    name: 'Ayabonga Khaka',
    country: 'South Africa',
    team: 'South Africa Women',
    role: 'Bowler',
    category: "Women's",
    formats: ['ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Medium',
    stats: {
      odi: { matches: 96, runs: 120, wickets: 124, average: 25.12, strikeRate: 36.8, high: 15 },
      t20: { matches: 62, runs: 30, wickets: 52, average: 24.38, strikeRate: 23.4, high: 8 }
    }
  },
  {
    id: 'pw-rsa-11',
    name: 'Masabata Klaas',
    country: 'South Africa',
    team: 'South Africa Women',
    role: 'Bowler',
    category: "Women's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Medium',
    stats: {
      test: { matches: 2, runs: 10, wickets: 3, average: 39.0, strikeRate: 60.0, high: 8 },
      odi: { matches: 68, runs: 110, wickets: 65, average: 35.84, strikeRate: 42.0, high: 15 },
      t20: { matches: 42, runs: 22, wickets: 35, average: 27.42, strikeRate: 21.5, high: 6 }
    }
  },

  // ================= ENGLAND WOMEN (11 Players) =================
  {
    id: 'pw-eng-1',
    name: 'Heather Knight',
    country: 'England',
    team: 'England Women',
    role: 'Batter',
    category: "Women's",
    formats: ['Test', 'ODI', 'T20'],
    isCaptain: true,
    captainFormat: 'England Women Captain',
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Offbreak',
    stats: {
      test: { matches: 12, runs: 902, wickets: 7, average: 45.1, strikeRate: 51.2, high: 168 },
      odi: { matches: 140, runs: 3820, wickets: 56, average: 36.73, strikeRate: 75.8, high: 106 },
      t20: { matches: 118, runs: 1980, wickets: 21, average: 25.38, strikeRate: 119.5, high: 108 }
    }
  },
  {
    id: 'pw-eng-2',
    name: 'Nat Sciver-Brunt',
    country: 'England',
    team: 'England Women',
    role: 'All-Rounder',
    category: "Women's",
    formats: ['Test', 'ODI', 'T20'],
    isViceCaptain: true,
    captainFormat: 'England Women Vice-Captain',
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Medium',
    stats: {
      test: { matches: 10, runs: 684, wickets: 11, average: 45.6, strikeRate: 53.4, high: 169 },
      odi: { matches: 109, runs: 3680, wickets: 76, average: 46.58, strikeRate: 94.2, high: 148 },
      t20: { matches: 124, runs: 2610, wickets: 86, average: 27.47, strikeRate: 117.8, high: 82 }
    }
  },
  {
    id: 'pw-eng-3',
    name: 'Danni Wyatt-Hodge',
    country: 'England',
    team: 'England Women',
    role: 'Batter',
    category: "Women's",
    formats: ['ODI', 'T20', 'Test'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Offbreak',
    stats: {
      test: { matches: 3, runs: 124, wickets: 0, average: 24.8, strikeRate: 62.0, high: 54 },
      odi: { matches: 112, runs: 1940, wickets: 27, average: 24.55, strikeRate: 84.6, high: 129 },
      t20: { matches: 164, runs: 2840, wickets: 46, average: 22.53, strikeRate: 128.2, high: 124 }
    }
  },
  {
    id: 'pw-eng-4',
    name: 'Amy Jones',
    country: 'England',
    team: 'England Women',
    role: 'Wicketkeeper',
    category: "Women's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Medium',
    stats: {
      test: { matches: 7, runs: 254, wickets: 0, average: 25.4, strikeRate: 52.0, high: 64 },
      odi: { matches: 92, runs: 2020, wickets: 0, average: 29.27, strikeRate: 83.4, high: 94 },
      t20: { matches: 104, runs: 1540, wickets: 0, average: 23.33, strikeRate: 122.4, high: 89 }
    }
  },
  {
    id: 'pw-eng-5',
    name: 'Sophie Ecclestone',
    country: 'England',
    team: 'England Women',
    role: 'Bowler',
    category: "Women's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Slow Left-Arm Orthodox',
    stats: {
      test: { matches: 8, runs: 215, wickets: 37, average: 32.16, strikeRate: 64.0, high: 35 },
      odi: { matches: 68, runs: 420, wickets: 108, average: 21.45, strikeRate: 32.5, high: 33 },
      t20: { matches: 88, runs: 240, wickets: 126, average: 15.22, strikeRate: 15.1, high: 33 }
    }
  },
  {
    id: 'pw-eng-6',
    name: 'Alice Capsey',
    country: 'England',
    team: 'England Women',
    role: 'All-Rounder',
    category: "Women's",
    formats: ['ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Offbreak',
    stats: {
      odi: { matches: 19, runs: 395, wickets: 5, average: 24.68, strikeRate: 91.2, high: 50 },
      t20: { matches: 40, runs: 680, wickets: 14, average: 22.66, strikeRate: 127.4, high: 67 }
    }
  },
  {
    id: 'pw-eng-7',
    name: 'Maia Bouchier',
    country: 'England',
    team: 'England Women',
    role: 'Batter',
    category: "Women's",
    formats: ['ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Medium',
    stats: {
      odi: { matches: 9, runs: 320, wickets: 0, average: 40.0, strikeRate: 88.0, high: 100 },
      t20: { matches: 38, runs: 640, wickets: 0, average: 25.6, strikeRate: 122.0, high: 91 }
    }
  },
  {
    id: 'pw-eng-8',
    name: 'Sarah Glenn',
    country: 'England',
    team: 'England Women',
    role: 'Bowler',
    category: "Women's",
    formats: ['ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Legbreak',
    stats: {
      odi: { matches: 18, runs: 85, wickets: 24, average: 26.25, strikeRate: 34.0, high: 22 },
      t20: { matches: 62, runs: 110, wickets: 78, average: 17.65, strikeRate: 16.4, high: 26 }
    }
  },
  {
    id: 'pw-eng-9',
    name: 'Charlie Dean',
    country: 'England',
    team: 'England Women',
    role: 'Bowler',
    category: "Women's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Offbreak',
    stats: {
      test: { matches: 2, runs: 48, wickets: 3, average: 42.0, strikeRate: 70.0, high: 34 },
      odi: { matches: 32, runs: 280, wickets: 58, average: 21.05, strikeRate: 26.8, high: 47 },
      t20: { matches: 30, runs: 95, wickets: 38, average: 18.21, strikeRate: 16.0, high: 20 }
    }
  },
  {
    id: 'pw-eng-10',
    name: 'Lauren Bell',
    country: 'England',
    team: 'England Women',
    role: 'Bowler',
    category: "Women's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Fast-Medium',
    stats: {
      test: { matches: 3, runs: 12, wickets: 8, average: 34.5, strikeRate: 56.0, high: 6 },
      odi: { matches: 18, runs: 16, wickets: 28, average: 24.14, strikeRate: 29.5, high: 8 },
      t20: { matches: 24, runs: 8, wickets: 32, average: 18.75, strikeRate: 15.2, high: 4 }
    }
  },
  {
    id: 'pw-eng-11',
    name: 'Lauren Filer',
    country: 'England',
    team: 'England Women',
    role: 'Bowler',
    category: "Women's",
    formats: ['Test', 'ODI', 'T20'],
    battingStyle: 'Right hand Bat',
    bowlingStyle: 'Right arm Fast',
    stats: {
      test: { matches: 3, runs: 18, wickets: 11, average: 25.18, strikeRate: 34.0, high: 11 },
      odi: { matches: 8, runs: 12, wickets: 12, average: 22.83, strikeRate: 25.0, high: 6 },
      t20: { matches: 6, runs: 4, wickets: 7, average: 20.42, strikeRate: 16.5, high: 4 }
    }
  }
];
