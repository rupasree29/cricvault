import { CricketMatch, CricketPlayer, CricketTeam, TournamentStandings } from '../types/cricket';
import { MEN_PLAYERS_PART1 } from './playerDataMen1';
import { MEN_PLAYERS_PART2 } from './playerDataMen2';
import { WOMEN_PLAYERS } from './playerDataWomen';

// Format date helper: YYYY-MM-DD
export function getDateString(offsetDays = 0): string {
  const d = new Date();
  d.setDate(d.getDate() + offsetDays);
  return d.toISOString().split('T')[0];
}

export function formatDisplayDate(dateObj: Date): string {
  return dateObj.toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    year: 'numeric'
  });
}

// Generate matches relative to current user date
export function generateMatchesForDates(): CricketMatch[] {
  const today = getDateString(0);
  const tomorrow = getDateString(1);
  const dayAfter = getDateString(2);
  const in3Days = getDateString(3);
  const in4Days = getDateString(4);
  const yesterday = getDateString(-1);
  const twoDaysAgo = getDateString(-2);

  return [
    // --- TODAY LIVE MATCH 1: England vs Sri Lanka, 2nd ODI (Headingley, Leeds) ---
    {
      id: 'match-live-1',
      series: 'Sri Lanka tour of England, 2026',
      matchTitle: '2nd ODI',
      format: 'ODI',
      category: "Men's",
      dateStr: today,
      timeStr: '5:00 PM (Today)',
      gmtTime: '11:30 AM GMT / 12:30 PM LOCAL',
      venue: 'Headingley',
      city: 'Leeds',
      country: 'England',
      status: 'LIVE',
      isLive: true,
      statusNote: 'Sri Lanka need 74 runs in 58 balls',
      tossWinner: 'Sri Lanka',
      tossDecision: 'bowl',
      tossText: 'Sri Lanka won the toss and chose to bowl first',
      currentBattingTeam: 'Sri Lanka',
      currentRunRate: 5.64,
      requiredRunRate: 7.65,
      target: 286,
      runsRequired: 74,
      ballsRemaining: 58,
      winningProbability: {
        team1: 58, // England
        team2: 42  // Sri Lanka
      },
      partnership: {
        runs: 54,
        balls: 41,
        player1Runs: 28,
        player2Runs: 24
      },
      recentBalls: ['1', '4', '0', '1', '2', 'W'],
      team1: {
        name: 'England',
        shortName: 'ENG',
        code: 'ENG',
        flagColor: '#002B49',
        score: '285/7 (50.0)',
        runs: 285,
        wickets: 7,
        overs: 50.0
      },
      team2: {
        name: 'Sri Lanka',
        shortName: 'SL',
        code: 'SL',
        flagColor: '#0C2340',
        score: '212/5 (40.2)',
        runs: 212,
        wickets: 5,
        overs: 40.2
      },
      currentBatsmen: [
        {
          name: 'Charith Asalanka',
          runs: 58,
          balls: 49,
          fours: 5,
          sixes: 2,
          strikeRate: 118.37,
          isOnStrike: true
        },
        {
          name: 'Janith Liyanage',
          runs: 26,
          balls: 21,
          fours: 3,
          sixes: 0,
          strikeRate: 123.81,
          isOnStrike: false
        }
      ],
      currentBowler: {
        name: 'Adil Rashid',
        overs: 8.2,
        maidens: 0,
        runs: 48,
        wickets: 2,
        economy: 5.76
      },
      innings: [
        {
          teamName: 'England',
          teamShort: 'ENG',
          runs: 285,
          wickets: 7,
          overs: 50.0,
          batting: [
            { name: 'Phil Salt', dismissal: 'c Mendis b Madushanka', runs: 34, balls: 29, fours: 4, sixes: 1, strikeRate: 117.24, isOnStrike: false },
            { name: 'Ben Duckett', dismissal: 'lbw b Hasaranga', runs: 62, balls: 68, fours: 7, sixes: 0, strikeRate: 91.18, isOnStrike: false },
            { name: 'Joe Root', dismissal: 'c Samarawickrama b Theekshana', runs: 78, balls: 84, fours: 6, sixes: 1, strikeRate: 92.86, isOnStrike: false },
            { name: 'Harry Brook (c)', dismissal: 'b Pathirana', runs: 45, balls: 38, fours: 3, sixes: 2, strikeRate: 118.42, isOnStrike: false },
            { name: 'Liam Livingstone', dismissal: 'c Nissanka b Hasaranga', runs: 28, balls: 22, fours: 2, sixes: 1, strikeRate: 127.27, isOnStrike: false },
            { name: 'Jos Buttler (wk)', dismissal: 'not out', runs: 24, balls: 15, fours: 2, sixes: 1, strikeRate: 160.00, isOnStrike: false },
            { name: 'Sam Curran', dismissal: 'run out (Asalanka)', runs: 8, balls: 7, fours: 1, sixes: 0, strikeRate: 114.28, isOnStrike: false },
            { name: 'Jofra Archer', dismissal: 'not out', runs: 2, balls: 3, fours: 0, sixes: 0, strikeRate: 66.67, isOnStrike: false }
          ],
          bowling: [
            { name: 'Dilshan Madushanka', overs: 10.0, maidens: 1, runs: 56, wickets: 1, economy: 5.60 },
            { name: 'Matheesha Pathirana', overs: 10.0, maidens: 0, runs: 64, wickets: 1, economy: 6.40 },
            { name: 'Maheesh Theekshana', overs: 10.0, maidens: 1, runs: 42, wickets: 1, economy: 4.20 },
            { name: 'Wanindu Hasaranga', overs: 10.0, maidens: 0, runs: 58, wickets: 2, economy: 5.80 },
            { name: 'Dunith Wellalage', overs: 8.0, maidens: 0, runs: 49, wickets: 0, economy: 6.12 },
            { name: 'Charith Asalanka', overs: 2.0, maidens: 0, runs: 12, wickets: 0, economy: 6.00 }
          ],
          extras: { total: 4, byes: 0, legByes: 2, wides: 2, noBalls: 0 },
          fallOfWickets: [
            { score: 52, wicket: 1, batsman: 'Phil Salt', over: 8.4 },
            { score: 142, wicket: 2, batsman: 'Ben Duckett', over: 26.2 },
            { score: 201, wicket: 3, batsman: 'Joe Root', over: 37.1 },
            { score: 241, wicket: 4, batsman: 'Harry Brook', over: 43.4 },
            { score: 268, wicket: 5, batsman: 'Liam Livingstone', over: 47.3 },
            { score: 281, wicket: 6, batsman: 'Sam Curran', over: 49.1 }
          ]
        },
        {
          teamName: 'Sri Lanka',
          teamShort: 'SL',
          runs: 212,
          wickets: 5,
          overs: 40.2,
          batting: [
            { name: 'Pathum Nissanka', dismissal: 'c Buttler b Archer', runs: 41, balls: 46, fours: 5, sixes: 0, strikeRate: 89.13, isOnStrike: false },
            { name: 'Avishka Fernando', dismissal: 'b Topley', runs: 18, balls: 24, fours: 2, sixes: 0, strikeRate: 75.00, isOnStrike: false },
            { name: 'Kusal Mendis (wk)', dismissal: 'c Root b Rashid', runs: 39, balls: 48, fours: 4, sixes: 0, strikeRate: 81.25, isOnStrike: false },
            { name: 'Sadeera Samarawickrama', dismissal: 'lbw b Rashid', runs: 14, balls: 19, fours: 1, sixes: 0, strikeRate: 73.68, isOnStrike: false },
            { name: 'Kamindu Mendis', dismissal: 'c Duckett b Atkinson', runs: 12, balls: 16, fours: 1, sixes: 0, strikeRate: 75.00, isOnStrike: false },
            { name: 'Charith Asalanka (c)', dismissal: 'batting', runs: 58, balls: 49, fours: 5, sixes: 2, strikeRate: 118.37, isOnStrike: true },
            { name: 'Janith Liyanage', dismissal: 'batting', runs: 26, balls: 21, fours: 3, sixes: 0, strikeRate: 123.81, isOnStrike: false }
          ],
          bowling: [
            { name: 'Jofra Archer', overs: 8.0, maidens: 1, runs: 38, wickets: 1, economy: 4.75 },
            { name: 'Reece Topley', overs: 7.0, maidens: 0, runs: 34, wickets: 1, economy: 4.85 },
            { name: 'Gus Atkinson', overs: 8.0, maidens: 0, runs: 44, wickets: 1, economy: 5.50 },
            { name: 'Sam Curran', overs: 6.0, maidens: 0, runs: 38, wickets: 0, economy: 6.33 },
            { name: 'Adil Rashid', overs: 8.2, maidens: 0, runs: 48, wickets: 2, economy: 5.76 },
            { name: 'Liam Livingstone', overs: 3.0, maidens: 0, runs: 19, wickets: 0, economy: 6.33 }
          ],
          extras: { total: 4, byes: 0, legByes: 2, wides: 2, noBalls: 0 },
          fallOfWickets: [
            { score: 32, wicket: 1, batsman: 'Avishka Fernando', over: 7.1 },
            { score: 86, wicket: 2, batsman: 'Pathum Nissanka', over: 17.3 },
            { score: 124, wicket: 3, batsman: 'Kusal Mendis', over: 25.4 },
            { score: 142, wicket: 4, batsman: 'Sadeera Samarawickrama', over: 29.2 },
            { score: 158, wicket: 5, batsman: 'Kamindu Mendis', over: 33.3 }
          ]
        }
      ]
    },

    // --- TODAY LIVE MATCH 2: Somerset vs Surrey, 70th Match, Day 1 ---
    {
      id: 'match-live-2',
      series: 'County Championship Division One 2026',
      matchTitle: 'Somerset vs Surrey, 70th Match, Day 1',
      format: 'Domestic',
      category: "Men's",
      dateStr: today,
      timeStr: '3:00 PM (Today)',
      gmtTime: '9:30 AM GMT / 10:30 AM LOCAL',
      venue: 'The Cooper Associates County Ground',
      city: 'Taunton',
      country: 'England',
      status: 'LIVE',
      isLive: true,
      statusNote: 'Somerset 1st innings - Session 3',
      tossWinner: 'Somerset',
      tossDecision: 'bat',
      tossText: 'Somerset won the toss and chose to bat first',
      currentBattingTeam: 'Somerset',
      currentRunRate: 3.42,
      partnership: {
        runs: 72,
        balls: 118,
        player1Runs: 38,
        player2Runs: 31
      },
      winningProbability: null, // "Winning probability unavailable"
      recentBalls: ['0', '1', '0', '4', '0', '0'],
      team1: {
        name: 'Somerset',
        shortName: 'SOM',
        code: 'SOM',
        flagColor: '#7A0026',
        score: '246/4 (72.0)',
        runs: 246,
        wickets: 4,
        overs: 72.0
      },
      team2: {
        name: 'Surrey',
        shortName: 'SUR',
        code: 'SUR',
        flagColor: '#60584C',
        score: 'Yet to bat'
      },
      currentBatsmen: [
        {
          name: 'Tom Banton',
          runs: 68,
          balls: 94,
          fours: 9,
          sixes: 1,
          strikeRate: 72.34,
          isOnStrike: true
        },
        {
          name: 'James Rew (wk)',
          runs: 35,
          balls: 62,
          fours: 4,
          sixes: 0,
          strikeRate: 56.45,
          isOnStrike: false
        }
      ],
      currentBowler: {
        name: 'Daniel Worrall',
        overs: 18.0,
        maidens: 4,
        runs: 52,
        wickets: 2,
        economy: 2.88
      }
    },

    // --- TODAY LIVE MATCH 3: India A vs Australia A, 1st unofficial Test, Day 3 ---
    {
      id: 'match-live-3',
      series: 'Australia A tour of India 2026',
      matchTitle: 'India A vs Australia A, 1st unofficial Test, Day 3',
      format: 'Test',
      category: "Men's",
      dateStr: today,
      timeStr: '9:30 AM (Today)',
      gmtTime: '4:00 AM GMT / 9:30 AM LOCAL',
      venue: 'Cricket Association Puducherry Siechem Ground',
      city: 'Puducherry',
      country: 'India',
      status: 'STUMPS',
      statusNote: 'Stumps Day 3 - Australia A lead by 142 runs',
      tossWinner: 'Australia A',
      tossDecision: 'bat',
      tossText: 'Australia A won toss and chose to bat',
      team1: {
        name: 'India A',
        shortName: 'INDA',
        code: 'IND',
        flagColor: '#0055A5',
        score: '312 & 168/4 (54.0)',
        runs: 168,
        wickets: 4,
        overs: 54.0
      },
      team2: {
        name: 'Australia A',
        shortName: 'AUSA',
        code: 'AUS',
        flagColor: '#006400',
        score: '422 & yet to bat',
        runs: 422,
        wickets: 10,
        overs: 122.4
      }
    },

    // --- OTHER TODAY MATCHES (Sep 24, 2026) ---
    {
      id: 'match-today-4',
      series: 'County Championship Division One 2026',
      matchTitle: 'Glamorgan vs Essex, 69th Match, Day 1',
      format: 'Domestic',
      category: "Men's",
      dateStr: today,
      timeStr: '3:00 PM (Today)',
      gmtTime: '9:30 AM GMT / 10:30 AM LOCAL',
      venue: 'Sophia Gardens',
      city: 'Cardiff',
      country: 'Wales',
      status: 'LIVE',
      isLive: true,
      statusNote: 'Essex 184/3 (58.4 ov)',
      team1: { name: 'Glamorgan', shortName: 'GLAM', code: 'GLA', flagColor: '#122340', score: 'Yet to bat' },
      team2: { name: 'Essex', shortName: 'ESS', code: 'ESS', flagColor: '#7A1C24', score: '184/3 (58.4)', runs: 184, wickets: 3, overs: 58.4 },
      currentBatsmen: [
        { name: 'Tom Westley', runs: 74, balls: 142, fours: 8, sixes: 0, strikeRate: 52.11, isOnStrike: true },
        { name: 'Paul Walter', runs: 32, balls: 56, fours: 4, sixes: 1, strikeRate: 57.14, isOnStrike: false }
      ],
      currentBowler: { name: 'Timm van der Gugten', overs: 14.4, maidens: 2, runs: 44, wickets: 1, economy: 3.00 }
    },
    {
      id: 'match-today-5',
      series: 'County Championship Division One 2026',
      matchTitle: 'Hampshire vs Sussex, 68th Match, Day 1',
      format: 'Domestic',
      category: "Men's",
      dateStr: today,
      timeStr: '3:00 PM (Today)',
      gmtTime: '9:30 AM GMT / 10:30 AM LOCAL',
      venue: 'The Rose Bowl',
      city: 'Southampton',
      country: 'England',
      status: 'LIVE',
      isLive: true,
      statusNote: 'Hampshire 215/5 (64.0 ov)',
      team1: { name: 'Hampshire', shortName: 'HAM', code: 'HAM', flagColor: '#002B49', score: '215/5 (64.0)', runs: 215, wickets: 5, overs: 64.0 },
      team2: { name: 'Sussex', shortName: 'SUS', code: 'SUS', flagColor: '#0A3B72', score: 'Yet to bat' }
    },
    {
      id: 'match-today-6',
      series: 'County Championship Division One 2026',
      matchTitle: 'Nottinghamshire vs Yorkshire, 67th Match, Day 1',
      format: 'Domestic',
      category: "Men's",
      dateStr: today,
      timeStr: '3:00 PM (Today)',
      gmtTime: '9:30 AM GMT / 10:30 AM LOCAL',
      venue: 'Trent Bridge',
      city: 'Nottingham',
      country: 'England',
      status: 'LIVE',
      isLive: true,
      statusNote: 'Yorkshire 198/4 (61.2 ov)',
      team1: { name: 'Nottinghamshire', shortName: 'NOTTS', code: 'NOT', flagColor: '#0C2340', score: 'Yet to bat' },
      team2: { name: 'Yorkshire', shortName: 'YORKS', code: 'YOR', flagColor: '#537B9C', score: '198/4 (61.2)', runs: 198, wickets: 4, overs: 61.2 }
    },
    {
      id: 'match-today-7',
      series: 'County Championship Division One 2026',
      matchTitle: 'Warwickshire vs Leicestershire, 66th Match, Day 1',
      format: 'Domestic',
      category: "Men's",
      dateStr: today,
      timeStr: '3:00 PM (Today)',
      gmtTime: '9:30 AM GMT / 10:30 AM LOCAL',
      venue: 'Edgbaston',
      city: 'Birmingham',
      country: 'England',
      status: 'LIVE',
      isLive: true,
      statusNote: 'Warwickshire 238/6 (69.0 ov)',
      team1: { name: 'Warwickshire', shortName: 'WARKS', code: 'WAR', flagColor: '#12264C', score: '238/6 (69.0)', runs: 238, wickets: 6, overs: 69.0 },
      team2: { name: 'Leicestershire', shortName: 'LEICS', code: 'LEI', flagColor: '#00543D', score: 'Yet to bat' }
    },
    {
      id: 'match-today-8',
      series: 'County Championship Division Two 2026',
      matchTitle: 'Middlesex vs Northamptonshire, 54th Match, Day 1',
      format: 'Domestic',
      category: "Men's",
      dateStr: today,
      timeStr: '3:00 PM (Today)',
      gmtTime: '9:30 AM GMT / 10:30 AM LOCAL',
      venue: "Lord's",
      city: 'London',
      country: 'England',
      status: 'LIVE',
      isLive: true,
      statusNote: 'Middlesex 205/3 (59.0 ov)',
      team1: { name: 'Middlesex', shortName: 'MIDDX', code: 'MID', flagColor: '#B01B2E', score: '205/3 (59.0)' },
      team2: { name: 'Northamptonshire', shortName: 'NORTHANTS', code: 'NOR', flagColor: '#7A1C24', score: 'Yet to bat' }
    },
    {
      id: 'match-today-9',
      series: 'North American Cup, 2026',
      matchTitle: 'Cayman Islands vs Bahamas, 3rd Match',
      format: 'T20',
      category: "Men's",
      dateStr: today,
      timeStr: '8:30 PM (Today)',
      gmtTime: '3:00 PM GMT / 10:00 AM LOCAL',
      venue: 'Jimmy Powell Oval',
      city: 'George Town',
      country: 'Cayman Islands',
      status: 'UPCOMING',
      statusNote: 'Match starts at 8:30 PM',
      team1: { name: 'Cayman Islands', shortName: 'CAY', code: 'CAY', flagColor: '#00247D' },
      team2: { name: 'Bahamas', shortName: 'BAH', code: 'BAH', flagColor: '#007788' }
    },

    // --- TOMORROW MATCHES (FRI, SEP 25 2026) ---
    {
      id: 'match-tmrw-0',
      series: 'North American Cup, 2026',
      matchTitle: 'Cayman Islands vs Bahamas, 4th Match',
      format: 'T20',
      category: "Men's",
      dateStr: tomorrow,
      timeStr: '1:00 AM (Tomorrow)',
      gmtTime: '7:30 PM GMT / 2:30 PM LOCAL',
      venue: 'Jimmy Powell Oval',
      city: 'George Town',
      country: 'Cayman Islands',
      status: 'UPCOMING',
      statusNote: 'Starts tomorrow at 1:00 AM',
      team1: { name: 'Cayman Islands', shortName: 'CAY', code: 'CAY', flagColor: '#00247D' },
      team2: { name: 'Bahamas', shortName: 'BAH', code: 'BAH', flagColor: '#007788' }
    },
    {
      id: 'match-tmrw-3',
      series: 'Asian Games 2026',
      matchTitle: 'Hong Kong, China vs Oman, 3rd Match, Group B',
      format: 'T20',
      category: "Men's",
      dateStr: tomorrow,
      timeStr: '5:30 AM (Tomorrow)',
      gmtTime: '12:00 AM GMT / 9:00 AM LOCAL',
      venue: 'Korogi Sports Park',
      city: 'Nisshin',
      country: 'Japan',
      status: 'UPCOMING',
      statusNote: 'Starts tomorrow at 5:30 AM',
      team1: { name: 'Hong Kong, China', shortName: 'HKC', code: 'HKG', flagColor: '#DE2910' },
      team2: { name: 'Oman', shortName: 'OMAN', code: 'OMA', flagColor: '#C8102E' }
    },
    {
      id: 'match-tmrw-4',
      series: 'Asian Games 2026',
      matchTitle: 'Afghanistan vs Nepal, 4th Match, Group A',
      format: 'T20',
      category: "Men's",
      dateStr: tomorrow,
      timeStr: '10:30 AM (Tomorrow)',
      gmtTime: '5:00 AM GMT / 2:00 PM LOCAL',
      venue: 'Korogi Sports Park',
      city: 'Nisshin',
      country: 'Japan',
      status: 'UPCOMING',
      statusNote: 'Starts tomorrow at 10:30 AM',
      team1: { name: 'Afghanistan', shortName: 'AFG', code: 'AFG', flagColor: '#007A3D' },
      team2: { name: 'Nepal', shortName: 'NEP', code: 'NEP', flagColor: '#DC143C' }
    },
    {
      id: 'match-tmrw-5',
      series: 'Australia Domestic One-Day Cup 2026-27',
      matchTitle: 'Victoria vs New South Wales, 6th Match',
      format: 'Domestic',
      category: "Men's",
      dateStr: tomorrow,
      timeStr: '9:30 AM (Tomorrow)',
      gmtTime: '4:00 AM GMT / 3:00 PM LOCAL',
      venue: 'Junction Oval',
      city: 'Melbourne',
      country: 'Australia',
      status: 'UPCOMING',
      statusNote: 'Starts tomorrow at 9:30 AM',
      team1: { name: 'Victoria', shortName: 'VIC', code: 'VIC', flagColor: '#002B49' },
      team2: { name: 'New South Wales', shortName: 'NSW', code: 'NSW', flagColor: '#7BAFD4' }
    },
    {
      id: 'match-tmrw-austest',
      series: 'Australia A tour of India 2026',
      matchTitle: 'India A vs Australia A, 1st unofficial Test, Day 4',
      format: 'Test',
      category: "Men's",
      dateStr: tomorrow,
      timeStr: '9:30 AM (Tomorrow)',
      gmtTime: '4:00 AM GMT / 9:30 AM LOCAL',
      venue: 'Cricket Association Puducherry Siechem Ground',
      city: 'Puducherry',
      country: 'India',
      status: 'UPCOMING',
      statusNote: 'Starts tomorrow at 9:30 AM - Day 4 Action',
      team1: { name: 'India A', shortName: 'INDA', code: 'IND', flagColor: '#0055A5' },
      team2: { name: 'Australia A', shortName: 'AUSA', code: 'AUS', flagColor: '#006400' }
    },
    {
      id: 'match-tmrw-1',
      series: 'Australia A Women tour of India 2026',
      matchTitle: 'India A Women vs Australia A Women, 3rd unofficial ODI',
      format: 'ODI',
      category: "Women's",
      dateStr: tomorrow,
      timeStr: '2:00 PM (Tomorrow)',
      gmtTime: '8:30 AM GMT / 2:00 PM LOCAL',
      venue: 'Punjab Cricket Association IS Bindra Stadium',
      city: 'Mohali',
      country: 'India',
      status: 'UPCOMING',
      statusNote: 'Starts tomorrow at 2:00 PM',
      team1: { name: 'India A Women', shortName: 'IND-W', code: 'IND-W', flagColor: '#0055A5' },
      team2: { name: 'Australia A Women', shortName: 'AUS-W', code: 'AUS-W', flagColor: '#006400' }
    },
    {
      id: 'match-tmrw-8',
      series: 'Quadrangular T20I Series in Nigeria, 2026',
      matchTitle: 'Ghana vs Sierra Leone, 4th Match',
      format: 'T20',
      category: "Men's",
      dateStr: tomorrow,
      timeStr: '2:30 PM (Tomorrow)',
      gmtTime: '9:00 AM GMT / 10:00 AM LOCAL',
      venue: 'Tafawa Balewa Square Cricket Oval',
      city: 'Lagos',
      country: 'Nigeria',
      status: 'UPCOMING',
      statusNote: 'Starts tomorrow at 2:30 PM',
      team1: { name: 'Ghana', shortName: 'GHA', code: 'GHA', flagColor: '#FCD116' },
      team2: { name: 'Sierra Leone', shortName: 'SLE', code: 'SLE', flagColor: '#1EB53A' }
    },
    {
      id: 'match-tmrw-county-1',
      series: 'County Championship Division One 2026',
      matchTitle: 'Nottinghamshire vs Yorkshire, 67th Match, Day 2',
      format: 'Domestic',
      category: "Men's",
      dateStr: tomorrow,
      timeStr: '3:00 PM (Tomorrow)',
      gmtTime: '9:30 AM GMT / 10:30 AM LOCAL',
      venue: 'Trent Bridge',
      city: 'Nottingham',
      country: 'England',
      status: 'UPCOMING',
      statusNote: 'Starts tomorrow at 3:00 PM - Day 2',
      team1: { name: 'Nottinghamshire', shortName: 'NOTTS', code: 'NOT', flagColor: '#0C2340' },
      team2: { name: 'Yorkshire', shortName: 'YORKS', code: 'YOR', flagColor: '#537B9C' }
    },
    {
      id: 'match-tmrw-county-2',
      series: 'County Championship Division One 2026',
      matchTitle: 'Hampshire vs Sussex, 68th Match, Day 2',
      format: 'Domestic',
      category: "Men's",
      dateStr: tomorrow,
      timeStr: '3:00 PM (Tomorrow)',
      gmtTime: '9:30 AM GMT / 10:30 AM LOCAL',
      venue: 'The Rose Bowl',
      city: 'Southampton',
      country: 'England',
      status: 'UPCOMING',
      statusNote: 'Starts tomorrow at 3:00 PM - Day 2',
      team1: { name: 'Hampshire', shortName: 'HAM', code: 'HAM', flagColor: '#002B49' },
      team2: { name: 'Sussex', shortName: 'SUS', code: 'SUS', flagColor: '#0A3B72' }
    },
    {
      id: 'match-tmrw-county-3',
      series: 'County Championship Division One 2026',
      matchTitle: 'Glamorgan vs Essex, 69th Match, Day 2',
      format: 'Domestic',
      category: "Men's",
      dateStr: tomorrow,
      timeStr: '3:00 PM (Tomorrow)',
      gmtTime: '9:30 AM GMT / 10:30 AM LOCAL',
      venue: 'Sophia Gardens',
      city: 'Cardiff',
      country: 'Wales',
      status: 'UPCOMING',
      statusNote: 'Starts tomorrow at 3:00 PM - Day 2',
      team1: { name: 'Glamorgan', shortName: 'GLAM', code: 'GLA', flagColor: '#122340' },
      team2: { name: 'Essex', shortName: 'ESS', code: 'ESS', flagColor: '#7A1C24' }
    },
    {
      id: 'match-tmrw-county-4',
      series: 'County Championship Division One 2026',
      matchTitle: 'Somerset vs Surrey, 70th Match, Day 2',
      format: 'Domestic',
      category: "Men's",
      dateStr: tomorrow,
      timeStr: '3:00 PM (Tomorrow)',
      gmtTime: '9:30 AM GMT / 10:30 AM LOCAL',
      venue: 'The Cooper Associates County Ground',
      city: 'Taunton',
      country: 'England',
      status: 'UPCOMING',
      statusNote: 'Starts tomorrow at 3:00 PM - Day 2',
      team1: { name: 'Somerset', shortName: 'SOM', code: 'SOM', flagColor: '#7A0026' },
      team2: { name: 'Surrey', shortName: 'SUR', code: 'SUR', flagColor: '#60584C' }
    },
    {
      id: 'match-tmrw-county-5',
      series: 'County Championship Division One 2026',
      matchTitle: 'Warwickshire vs Leicestershire, 66th Match, Day 2',
      format: 'Domestic',
      category: "Men's",
      dateStr: tomorrow,
      timeStr: '3:00 PM (Tomorrow)',
      gmtTime: '9:30 AM GMT / 10:30 AM LOCAL',
      venue: 'Edgbaston',
      city: 'Birmingham',
      country: 'England',
      status: 'UPCOMING',
      statusNote: 'Starts tomorrow at 3:00 PM - Day 2',
      team1: { name: 'Warwickshire', shortName: 'WARKS', code: 'WAR', flagColor: '#12264C' },
      team2: { name: 'Leicestershire', shortName: 'LEICS', code: 'LEI', flagColor: '#00543D' }
    },
    {
      id: 'match-tmrw-county-6',
      series: 'County Championship Division Two 2026',
      matchTitle: 'Kent vs Gloucestershire, 53rd Match, Day 2',
      format: 'Domestic',
      category: "Men's",
      dateStr: tomorrow,
      timeStr: '3:00 PM (Tomorrow)',
      gmtTime: '9:30 AM GMT / 10:30 AM LOCAL',
      venue: 'St Lawrence Ground',
      city: 'Canterbury',
      country: 'England',
      status: 'UPCOMING',
      statusNote: 'Starts tomorrow at 3:00 PM - Day 2',
      team1: { name: 'Kent', shortName: 'KENT', code: 'KEN', flagColor: '#C8102E' },
      team2: { name: 'Gloucestershire', shortName: 'GLOUCS', code: 'GLO', flagColor: '#002B49' }
    },
    {
      id: 'match-tmrw-county-7',
      series: 'County Championship Division Two 2026',
      matchTitle: 'Lancashire vs Durham, 56th Match, Day 2',
      format: 'Domestic',
      category: "Men's",
      dateStr: tomorrow,
      timeStr: '3:00 PM (Tomorrow)',
      gmtTime: '9:30 AM GMT / 10:30 AM LOCAL',
      venue: 'Emirates Old Trafford',
      city: 'Manchester',
      country: 'England',
      status: 'UPCOMING',
      statusNote: 'Starts tomorrow at 3:00 PM - Day 2',
      team1: { name: 'Lancashire', shortName: 'LANCS', code: 'LAN', flagColor: '#990000' },
      team2: { name: 'Durham', shortName: 'DUR', code: 'DUR', flagColor: '#002B49' }
    },
    {
      id: 'match-tmrw-county-8',
      series: 'County Championship Division Two 2026',
      matchTitle: 'Middlesex vs Northamptonshire, 54th Match, Day 2',
      format: 'Domestic',
      category: "Men's",
      dateStr: tomorrow,
      timeStr: '3:00 PM (Tomorrow)',
      gmtTime: '9:30 AM GMT / 10:30 AM LOCAL',
      venue: "Lord's",
      city: 'London',
      country: 'England',
      status: 'UPCOMING',
      statusNote: 'Starts tomorrow at 3:00 PM - Day 2',
      team1: { name: 'Middlesex', shortName: 'MIDDX', code: 'MID', flagColor: '#B01B2E' },
      team2: { name: 'Northamptonshire', shortName: 'NORTHANTS', code: 'NOR', flagColor: '#7A1C24' }
    },
    {
      id: 'match-tmrw-county-9',
      series: 'County Championship Division Two 2026',
      matchTitle: 'Worcestershire vs Derbyshire, 55th Match, Day 2',
      format: 'Domestic',
      category: "Men's",
      dateStr: tomorrow,
      timeStr: '3:00 PM (Tomorrow)',
      gmtTime: '9:30 AM GMT / 10:30 AM LOCAL',
      venue: 'New Road',
      city: 'Worcester',
      country: 'England',
      status: 'UPCOMING',
      statusNote: 'Starts tomorrow at 3:00 PM - Day 2',
      team1: { name: 'Worcestershire', shortName: 'WORCS', code: 'WOR', flagColor: '#12264C' },
      team2: { name: 'Derbyshire', shortName: 'DERBY', code: 'DER', flagColor: '#7A0026' }
    },
    {
      id: 'match-tmrw-2',
      series: "South American Women's Championship T20I, 2026",
      matchTitle: 'Costa Rica Women vs Chile Women, 2nd Match',
      format: 'T20',
      category: "Women's",
      dateStr: tomorrow,
      timeStr: '5:30 PM (Tomorrow)',
      gmtTime: '12:00 PM GMT / 9:00 AM LOCAL',
      venue: 'Pocos Oval',
      city: 'Pocos de Caldas',
      country: 'Brazil',
      status: 'UPCOMING',
      statusNote: 'Starts tomorrow at 5:30 PM',
      team1: { name: 'Costa Rica Women', shortName: 'CRC-W', code: 'CRC', flagColor: '#002B7F' },
      team2: { name: 'Chile Women', shortName: 'CHI-W', code: 'CHI', flagColor: '#D52B1E' }
    },
    {
      id: 'match-tmrw-6',
      series: 'CSA T20 Challenge 2026',
      matchTitle: 'Warriors vs North West - Eastvaal Renault Dragons, Pool A',
      format: 'T20 League',
      category: "Men's",
      dateStr: tomorrow,
      timeStr: '5:30 PM (Tomorrow)',
      gmtTime: '12:00 PM GMT / 2:00 PM LOCAL',
      venue: 'SuperSport Park',
      city: 'Centurion',
      country: 'South Africa',
      status: 'UPCOMING',
      statusNote: 'Starts tomorrow at 5:30 PM',
      team1: { name: 'Warriors', shortName: 'WAR', code: 'WAR', flagColor: '#12264C' },
      team2: { name: 'North West Dragons', shortName: 'NWD', code: 'NWD', flagColor: '#C41230' }
    },
    {
      id: 'match-tmrw-bahamas',
      series: 'North American Cup, 2026',
      matchTitle: 'Bahamas vs Bermuda, 5th Match',
      format: 'T20',
      category: "Men's",
      dateStr: tomorrow,
      timeStr: '8:30 PM (Tomorrow)',
      gmtTime: '3:00 PM GMT / 10:00 AM LOCAL',
      venue: 'Jimmy Powell Oval',
      city: 'George Town',
      country: 'Cayman Islands',
      status: 'UPCOMING',
      statusNote: 'Starts tomorrow at 8:30 PM',
      team1: { name: 'Bahamas', shortName: 'BAH', code: 'BAH', flagColor: '#007788' },
      team2: { name: 'Bermuda', shortName: 'BER', code: 'BER', flagColor: '#00247D' }
    },
    {
      id: 'match-tmrw-7',
      series: 'CSA T20 Challenge 2026',
      matchTitle: 'Titans vs Western Province, Pool B',
      format: 'T20 League',
      category: "Men's",
      dateStr: tomorrow,
      timeStr: '9:30 PM (Tomorrow)',
      gmtTime: '4:00 PM GMT / 6:00 PM LOCAL',
      venue: 'SuperSport Park',
      city: 'Centurion',
      country: 'South Africa',
      status: 'UPCOMING',
      statusNote: 'Starts tomorrow at 9:30 PM',
      team1: { name: 'Titans', shortName: 'TIT', code: 'TIT', flagColor: '#0077C8' },
      team2: { name: 'Western Province', shortName: 'WP', code: 'WP', flagColor: '#00205B' }
    },

    // --- DAY AFTER TOMORROW MATCHES (SAT, SEP 26 2026) ---
    {
      id: 'match-dayafter-1',
      series: 'Asian Games 2026',
      matchTitle: 'Japan vs Nepal, 5th Match, Group A',
      format: 'T20',
      category: "Men's",
      dateStr: dayAfter,
      timeStr: '5:30 AM (Saturday)',
      gmtTime: '12:00 AM GMT / 9:00 AM LOCAL',
      venue: 'Korogi Sports Park',
      city: 'Nisshin',
      country: 'Japan',
      status: 'UPCOMING',
      statusNote: 'Starts Saturday (Day After Tomorrow) at 5:30 AM',
      team1: { name: 'Japan', shortName: 'JPN', code: 'JPN', flagColor: '#BC002D' },
      team2: { name: 'Nepal', shortName: 'NEP', code: 'NEP', flagColor: '#DC143C' }
    },
    {
      id: 'match-dayafter-2',
      series: 'Asian Games 2026',
      matchTitle: 'Malaysia vs Oman, 6th Match, Group B',
      format: 'T20',
      category: "Men's",
      dateStr: dayAfter,
      timeStr: '10:30 AM (Saturday)',
      gmtTime: '5:00 AM GMT / 2:00 PM LOCAL',
      venue: 'Korogi Sports Park',
      city: 'Nisshin',
      country: 'Japan',
      status: 'UPCOMING',
      statusNote: 'Starts Saturday (Day After Tomorrow) at 10:30 AM',
      team1: { name: 'Malaysia', shortName: 'MAS', code: 'MAS', flagColor: '#010066' },
      team2: { name: 'Oman', shortName: 'OMAN', code: 'OMA', flagColor: '#C8102E' }
    },
    {
      id: 'match-dayafter-3',
      series: 'County Championship Division One 2026',
      matchTitle: 'Warwickshire vs Leicestershire, 66th Match, Day 3',
      format: 'Domestic',
      category: "Men's",
      dateStr: dayAfter,
      timeStr: '3:00 PM (Saturday)',
      gmtTime: '9:30 AM GMT / 10:30 AM LOCAL',
      venue: 'Edgbaston',
      city: 'Birmingham',
      country: 'England',
      status: 'UPCOMING',
      statusNote: 'Starts Saturday - Day 3 Action',
      team1: { name: 'Warwickshire', shortName: 'WARKS', code: 'WAR', flagColor: '#12264C' },
      team2: { name: 'Leicestershire', shortName: 'LEICS', code: 'LEI', flagColor: '#00543D' }
    },
    {
      id: 'match-dayafter-4',
      series: 'County Championship Division One 2026',
      matchTitle: 'Nottinghamshire vs Yorkshire, 67th Match, Day 3',
      format: 'Domestic',
      category: "Men's",
      dateStr: dayAfter,
      timeStr: '3:00 PM (Saturday)',
      gmtTime: '9:30 AM GMT / 10:30 AM LOCAL',
      venue: 'Trent Bridge',
      city: 'Nottingham',
      country: 'England',
      status: 'UPCOMING',
      statusNote: 'Starts Saturday - Day 3 Action',
      team1: { name: 'Nottinghamshire', shortName: 'NOTTS', code: 'NOT', flagColor: '#0C2340' },
      team2: { name: 'Yorkshire', shortName: 'YORKS', code: 'YOR', flagColor: '#537B9C' }
    },
    {
      id: 'match-dayafter-5',
      series: 'County Championship Division One 2026',
      matchTitle: 'Hampshire vs Sussex, 68th Match, Day 3',
      format: 'Domestic',
      category: "Men's",
      dateStr: dayAfter,
      timeStr: '3:00 PM (Saturday)',
      gmtTime: '9:30 AM GMT / 10:30 AM LOCAL',
      venue: 'The Rose Bowl',
      city: 'Southampton',
      country: 'England',
      status: 'UPCOMING',
      statusNote: 'Starts Saturday - Day 3 Action',
      team1: { name: 'Hampshire', shortName: 'HAM', code: 'HAM', flagColor: '#002B49' },
      team2: { name: 'Sussex', shortName: 'SUS', code: 'SUS', flagColor: '#0A3B72' }
    },
    {
      id: 'match-dayafter-6',
      series: 'County Championship Division One 2026',
      matchTitle: 'Glamorgan vs Essex, 69th Match, Day 3',
      format: 'Domestic',
      category: "Men's",
      dateStr: dayAfter,
      timeStr: '3:00 PM (Saturday)',
      gmtTime: '9:30 AM GMT / 10:30 AM LOCAL',
      venue: 'Sophia Gardens',
      city: 'Cardiff',
      country: 'Wales',
      status: 'UPCOMING',
      statusNote: 'Starts Saturday - Day 3 Action',
      team1: { name: 'Glamorgan', shortName: 'GLAM', code: 'GLA', flagColor: '#122340' },
      team2: { name: 'Essex', shortName: 'ESS', code: 'ESS', flagColor: '#7A1C24' }
    },
    {
      id: 'match-dayafter-7',
      series: 'County Championship Division One 2026',
      matchTitle: 'Somerset vs Surrey, 70th Match, Day 3',
      format: 'Domestic',
      category: "Men's",
      dateStr: dayAfter,
      timeStr: '3:00 PM (Saturday)',
      gmtTime: '9:30 AM GMT / 10:30 AM LOCAL',
      venue: 'The Cooper Associates County Ground',
      city: 'Taunton',
      country: 'England',
      status: 'UPCOMING',
      statusNote: 'Starts Saturday - Day 3 Action',
      team1: { name: 'Somerset', shortName: 'SOM', code: 'SOM', flagColor: '#7A0026' },
      team2: { name: 'Surrey', shortName: 'SUR', code: 'SUR', flagColor: '#60584C' }
    },
    {
      id: 'match-dayafter-8',
      series: 'CSA T20 Challenge 2026',
      matchTitle: 'Northern Cape vs Border, Pool A',
      format: 'T20 League',
      category: "Men's",
      dateStr: dayAfter,
      timeStr: '4:30 PM (Saturday)',
      gmtTime: '11:00 AM GMT / 1:00 PM LOCAL',
      venue: 'Diamond Oval',
      city: 'Kimberley',
      country: 'South Africa',
      status: 'UPCOMING',
      statusNote: 'Starts Saturday at 4:30 PM',
      team1: { name: 'Northern Cape', shortName: 'NC', code: 'NC', flagColor: '#12264C' },
      team2: { name: 'Border', shortName: 'BOR', code: 'BOR', flagColor: '#006633' }
    },
    {
      id: 'match-dayafter-9',
      series: 'Quadrangular T20I Series in Nigeria, 2026',
      matchTitle: 'Nigeria vs Ghana, 5th Match',
      format: 'T20',
      category: "Men's",
      dateStr: dayAfter,
      timeStr: '6:30 PM (Saturday)',
      gmtTime: '1:00 PM GMT / 2:00 PM LOCAL',
      venue: 'Tafawa Balewa Square Cricket Oval',
      city: 'Lagos',
      country: 'Nigeria',
      status: 'UPCOMING',
      statusNote: 'Starts Saturday at 6:30 PM',
      team1: { name: 'Nigeria', shortName: 'NIG', code: 'NGR', flagColor: '#008751' },
      team2: { name: 'Ghana', shortName: 'GHA', code: 'GHA', flagColor: '#FCD116' }
    },

    // --- UPCOMING MATCHES (Sep 26 & Sep 27, 2026) ---
    {
      id: 'match-future-1',
      series: 'Australia tour of South Africa, 2026',
      matchTitle: 'South Africa vs Australia, 2nd ODI',
      format: 'ODI',
      category: "Men's",
      dateStr: in3Days,
      timeStr: '1:30 PM (Sunday)',
      gmtTime: '8:00 AM GMT / 10:00 AM LOCAL',
      venue: 'The Wanderers Stadium',
      city: 'Johannesburg',
      country: 'South Africa',
      status: 'UPCOMING',
      statusNote: 'Upcoming - Series 1-0 to South Africa',
      team1: { name: 'South Africa', shortName: 'RSA', code: 'RSA', flagColor: '#006633' },
      team2: { name: 'Australia', shortName: 'AUS', code: 'AUS', flagColor: '#006400' }
    },
    {
      id: 'match-future-2',
      series: 'West Indies tour of India, 2026',
      matchTitle: 'India vs West Indies, 1st ODI',
      format: 'ODI',
      category: "Men's",
      dateStr: in3Days,
      timeStr: '2:00 PM (Sunday)',
      gmtTime: '8:30 AM GMT / 2:00 PM LOCAL',
      venue: 'Greenfield International Stadium',
      city: 'Thiruvananthapuram',
      country: 'India',
      status: 'UPCOMING',
      statusNote: 'Upcoming - 1st ODI of 3-match series',
      team1: { name: 'India', shortName: 'IND', code: 'IND', flagColor: '#0055A5' },
      team2: { name: 'West Indies', shortName: 'WI', code: 'WI', flagColor: '#7B003A' }
    },
    {
      id: 'match-future-3',
      series: 'West Indies Women tour of Zimbabwe, 2026',
      matchTitle: 'Zimbabwe Women vs West Indies Women, 2nd ODI',
      format: 'ODI',
      category: "Women's",
      dateStr: in3Days,
      timeStr: '1:00 PM (Sunday)',
      gmtTime: '7:30 AM GMT / 9:30 AM LOCAL',
      venue: 'Harare Sports Club',
      city: 'Harare',
      country: 'Zimbabwe',
      status: 'UPCOMING',
      statusNote: 'Upcoming - 2nd ODI',
      team1: { name: 'Zimbabwe Women', shortName: 'ZIM-W', code: 'ZIM-W', flagColor: '#C41230' },
      team2: { name: 'West Indies Women', shortName: 'WI-W', code: 'WI-W', flagColor: '#7B003A' }
    },
    {
      id: 'match-future-4',
      series: 'Asian Games 2026',
      matchTitle: 'India vs A2, 2nd Quarter-Final',
      format: 'T20',
      category: "Men's",
      dateStr: in4Days,
      timeStr: '10:00 AM (Monday)',
      gmtTime: '4:30 AM GMT / 1:30 PM LOCAL',
      venue: 'Korogi Sports Park',
      city: 'Nisshin',
      country: 'Japan',
      status: 'UPCOMING',
      statusNote: 'Upcoming - Knockout stage',
      team1: { name: 'India', shortName: 'IND', code: 'IND', flagColor: '#0055A5' },
      team2: { name: 'Quarter-Finalist 2', shortName: 'TBC', code: 'TBC', flagColor: '#6B7280' }
    },

    // --- RECENT RESULTS (Yesterday / Past Days) ---
    {
      id: 'match-recent-1',
      series: 'Australia tour of South Africa, 2026',
      matchTitle: 'South Africa vs Australia, 1st ODI',
      format: 'ODI',
      category: "Men's",
      dateStr: yesterday,
      timeStr: '1:30 PM',
      gmtTime: '8:00 AM GMT',
      venue: 'SuperSport Park',
      city: 'Centurion',
      country: 'South Africa',
      status: 'COMPLETED',
      statusNote: 'South Africa won by 4 wkts',
      resultWinner: 'South Africa',
      resultMargin: '4 wickets',
      playerOfTheMatch: 'Heinrich Klaasen (78 off 52)',
      tossWinner: 'South Africa',
      tossDecision: 'bowl',
      tossText: 'South Africa won toss and chose to bowl',
      team1: {
        name: 'Australia',
        shortName: 'AUS',
        code: 'AUS',
        flagColor: '#006400',
        score: '269/9 (50.0)',
        runs: 269,
        wickets: 9,
        overs: 50.0
      },
      team2: {
        name: 'South Africa',
        shortName: 'RSA',
        code: 'RSA',
        flagColor: '#006633',
        score: '272/6 (47.2)',
        runs: 272,
        wickets: 6,
        overs: 47.2
      },
      innings: [
        {
          teamName: 'Australia',
          teamShort: 'AUS',
          runs: 269,
          wickets: 9,
          overs: 50.0,
          batting: [
            { name: 'Travis Head', dismissal: 'c de Kock b Rabada', runs: 54, balls: 45, fours: 7, sixes: 2, strikeRate: 120.0, isOnStrike: false },
            { name: 'Marnus Labuschagne', dismissal: 'c Bavuma b Maharaj', runs: 62, balls: 82, fours: 5, sixes: 0, strikeRate: 75.61, isOnStrike: false },
            { name: 'Steve Smith', dismissal: 'lbw b Jansen', runs: 38, balls: 51, fours: 3, sixes: 0, strikeRate: 74.51, isOnStrike: false },
            { name: 'Glenn Maxwell', dismissal: 'c Jansen b Shamsi', runs: 28, balls: 20, fours: 3, sixes: 1, strikeRate: 140.0, isOnStrike: false },
            { name: 'Alex Carey (wk)', dismissal: 'run out (Miller)', runs: 42, balls: 48, fours: 4, sixes: 0, strikeRate: 87.5, isOnStrike: false }
          ],
          bowling: [
            { name: 'Kagiso Rabada', overs: 10.0, maidens: 1, runs: 48, wickets: 3, economy: 4.80 },
            { name: 'Marco Jansen', overs: 10.0, maidens: 0, runs: 55, wickets: 2, economy: 5.50 },
            { name: 'Keshav Maharaj', overs: 10.0, maidens: 1, runs: 41, wickets: 2, economy: 4.10 },
            { name: 'Tabraiz Shamsi', overs: 10.0, maidens: 0, runs: 62, wickets: 1, economy: 6.20 }
          ],
          extras: { total: 8, byes: 1, legByes: 3, wides: 4, noBalls: 0 },
          fallOfWickets: [
            { score: 68, wicket: 1, batsman: 'Travis Head', over: 10.2 },
            { score: 135, wicket: 2, batsman: 'Steve Smith', over: 24.5 },
            { score: 172, wicket: 3, batsman: 'Marnus Labuschagne', over: 32.1 }
          ]
        },
        {
          teamName: 'South Africa',
          teamShort: 'RSA',
          runs: 272,
          wickets: 6,
          overs: 47.2,
          batting: [
            { name: 'Temba Bavuma (c)', dismissal: 'c Carey b Starc', runs: 32, balls: 41, fours: 3, sixes: 0, strikeRate: 78.05, isOnStrike: false },
            { name: 'Quinton de Kock (wk)', dismissal: 'c Maxwell b Hazlewood', runs: 45, balls: 39, fours: 6, sixes: 1, strikeRate: 115.38, isOnStrike: false },
            { name: 'Aiden Markram', dismissal: 'b Cummins', runs: 28, balls: 35, fours: 3, sixes: 0, strikeRate: 80.0, isOnStrike: false },
            { name: 'Heinrich Klaasen', dismissal: 'c Head b Zampa', runs: 78, balls: 52, fours: 8, sixes: 4, strikeRate: 150.0, isOnStrike: false },
            { name: 'David Miller', dismissal: 'not out', runs: 51, balls: 46, fours: 4, sixes: 1, strikeRate: 110.87, isOnStrike: false }
          ],
          bowling: [
            { name: 'Mitchell Starc', overs: 9.2, maidens: 0, runs: 58, wickets: 2, economy: 6.21 },
            { name: 'Josh Hazlewood', overs: 10.0, maidens: 1, runs: 45, wickets: 1, economy: 4.50 },
            { name: 'Pat Cummins', overs: 10.0, maidens: 0, runs: 54, wickets: 1, economy: 5.40 },
            { name: 'Adam Zampa', overs: 10.0, maidens: 0, runs: 65, wickets: 2, economy: 6.50 }
          ],
          extras: { total: 6, byes: 0, legByes: 2, wides: 4, noBalls: 0 },
          fallOfWickets: [
            { score: 62, wicket: 1, batsman: 'Quinton de Kock', over: 9.4 },
            { score: 88, wicket: 2, batsman: 'Temba Bavuma', over: 15.1 },
            { score: 138, wicket: 3, batsman: 'Aiden Markram', over: 24.3 },
            { score: 232, wicket: 4, batsman: 'Heinrich Klaasen', over: 39.5 }
          ]
        }
      ]
    },
    {
      id: 'match-recent-2',
      series: 'Sri Lanka tour of England, 2026',
      matchTitle: 'England vs Sri Lanka, 1st ODI',
      format: 'ODI',
      category: "Men's",
      dateStr: twoDaysAgo,
      timeStr: '5:00 PM',
      gmtTime: '11:30 AM GMT',
      venue: 'Riverside Ground',
      city: 'Chester-le-Street',
      country: 'England',
      status: 'COMPLETED',
      statusNote: 'England won by 5 wkts',
      resultWinner: 'England',
      resultMargin: '5 wickets',
      playerOfTheMatch: 'Harry Brook (84* off 66)',
      team1: { name: 'Sri Lanka', shortName: 'SL', code: 'SL', flagColor: '#0C2340', score: '241 all out (48.4)' },
      team2: { name: 'England', shortName: 'ENG', code: 'ENG', flagColor: '#002B49', score: '245/5 (42.3)' }
    },
    {
      id: 'match-recent-3',
      series: 'Australia A Women tour of India 2026',
      matchTitle: 'India A Women vs Australia A Women, 2nd unofficial ODI',
      format: 'ODI',
      category: "Women's",
      dateStr: twoDaysAgo,
      timeStr: '2:00 PM',
      gmtTime: '8:30 AM GMT',
      venue: 'Punjab Cricket Association IS Bindra Stadium',
      city: 'Mohali',
      country: 'India',
      status: 'COMPLETED',
      statusNote: 'India A Women won by 4 wkts',
      resultWinner: 'India A Women',
      resultMargin: '4 wickets',
      playerOfTheMatch: 'Shweta Sehrawat (71 off 68)',
      team1: { name: 'Australia A Women', shortName: 'AUS-W', code: 'AUS-W', flagColor: '#006400', score: '218/8 (50.0)' },
      team2: { name: 'India A Women', shortName: 'IND-W', code: 'IND-W', flagColor: '#0055A5', score: '221/6 (46.4)' }
    }
  ];
}

// Current authentic cricket players
export const PLAYERS_DATABASE: CricketPlayer[] = [
  ...MEN_PLAYERS_PART1,
  ...MEN_PLAYERS_PART2,
  ...WOMEN_PLAYERS
];

// Teams database
export const TEAMS_DATABASE: CricketTeam[] = [
  {
    id: 'team-ind',
    name: 'India',
    shortName: 'IND',
    code: 'IND',
    flagColor: '#0055A5',
    category: "Men's",
    ranking: { test: 1, odi: 1, t20: 1 },
    stats: { played: 1042, won: 588, lost: 398, draw: 56, winPercentage: 56.4 },
    keyPlayers: ['Shubman Gill (ODI Capt)', 'Rohit Sharma (Test Capt)', 'Nitish Kumar Reddy', 'Jasprit Bumrah', 'Virat Kohli']
  },
  {
    id: 'team-aus',
    name: 'Australia',
    shortName: 'AUS',
    code: 'AUS',
    flagColor: '#006400',
    category: "Men's",
    ranking: { test: 2, odi: 2, t20: 2 },
    stats: { played: 982, won: 592, lost: 334, draw: 56, winPercentage: 60.3 },
    keyPlayers: ['Pat Cummins (Capt)', 'Mitchell Marsh', 'Travis Head', 'Steve Smith', 'Mitchell Starc']
  },
  {
    id: 'team-rsa',
    name: 'South Africa',
    shortName: 'RSA',
    code: 'RSA',
    flagColor: '#006633',
    category: "Men's",
    ranking: { test: 3, odi: 3, t20: 4 },
    stats: { played: 672, won: 398, lost: 242, draw: 32, winPercentage: 59.2 },
    keyPlayers: ['Temba Bavuma (Capt)', 'Aiden Markram', 'Heinrich Klaasen', 'Kagiso Rabada', 'David Miller']
  },
  {
    id: 'team-eng',
    name: 'England',
    shortName: 'ENG',
    code: 'ENG',
    flagColor: '#002B49',
    category: "Men's",
    ranking: { test: 4, odi: 5, t20: 3 },
    stats: { played: 1072, won: 540, lost: 442, draw: 90, winPercentage: 50.4 },
    keyPlayers: ['Ben Stokes (Test Capt)', 'Jos Buttler (ODI/T20 Capt)', 'Joe Root', 'Harry Brook', 'Jofra Archer']
  },
  {
    id: 'team-nz',
    name: 'New Zealand',
    shortName: 'NZ',
    code: 'NZ',
    flagColor: '#111111',
    category: "Men's",
    ranking: { test: 5, odi: 4, t20: 5 },
    stats: { played: 820, won: 395, lost: 375, draw: 50, winPercentage: 48.2 },
    keyPlayers: ['Tom Latham (Test Capt)', 'Mitchell Santner (White-Ball Capt)', 'Kane Williamson', 'Trent Boult']
  },
  {
    id: 'team-pak',
    name: 'Pakistan',
    shortName: 'PAK',
    code: 'PAK',
    flagColor: '#01411C',
    category: "Men's",
    ranking: { test: 7, odi: 6, t20: 6 },
    stats: { played: 950, won: 505, lost: 405, draw: 40, winPercentage: 53.2 },
    keyPlayers: ['Mohammad Rizwan (ODI/T20 Capt)', 'Shan Masood (Test Capt)', 'Babar Azam', 'Shaheen Afridi']
  },
  {
    id: 'team-wi',
    name: 'West Indies',
    shortName: 'WI',
    code: 'WI',
    flagColor: '#7B003A',
    category: "Men's",
    ranking: { test: 8, odi: 9, t20: 8 },
    stats: { played: 890, won: 420, lost: 430, draw: 40, winPercentage: 47.2 },
    keyPlayers: ['Shai Hope (ODI Capt)', 'Rovman Powell (T20 Capt)', 'Nicholas Pooran', 'Alzarri Joseph']
  },
  {
    id: 'team-sl',
    name: 'Sri Lanka',
    shortName: 'SL',
    code: 'SL',
    flagColor: '#0C2340',
    category: "Men's",
    ranking: { test: 6, odi: 7, t20: 7 },
    stats: { played: 890, won: 420, lost: 430, draw: 40, winPercentage: 47.2 },
    keyPlayers: ['Charith Asalanka (Capt)', 'Wanindu Hasaranga', 'Pathum Nissanka', 'Kusal Mendis']
  },
  {
    id: 'team-afg',
    name: 'Afghanistan',
    shortName: 'AFG',
    code: 'AFG',
    flagColor: '#007A3D',
    category: "Men's",
    ranking: { test: 9, odi: 8, t20: 9 },
    stats: { played: 280, won: 152, lost: 122, draw: 6, winPercentage: 54.3 },
    keyPlayers: ['Rashid Khan (T20 Capt)', 'Hashmatullah Shahidi (ODI Capt)', 'Rahmanullah Gurbaz', 'Mohammad Nabi']
  },
  {
    id: 'team-ban',
    name: 'Bangladesh',
    shortName: 'BAN',
    code: 'BAN',
    flagColor: '#006A4E',
    category: "Men's",
    ranking: { test: 10, odi: 10, t20: 10 },
    stats: { played: 420, won: 165, lost: 245, draw: 10, winPercentage: 39.3 },
    keyPlayers: ['Najmul Hossain Shanto (Capt)', 'Litton Das', 'Mehidy Hasan Miraz', 'Taskin Ahmed']
  },
  {
    id: 'team-ind-w',
    name: 'India Women',
    shortName: 'IND-W',
    code: 'IND-W',
    flagColor: '#0055A5',
    category: "Women's",
    ranking: { test: 2, odi: 3, t20: 3 },
    stats: { played: 340, won: 204, lost: 130, draw: 6, winPercentage: 60.0 },
    keyPlayers: ['Harmanpreet Kaur (Capt)', 'Smriti Mandhana (VC)', 'Deepti Sharma', 'Jemimah Rodrigues']
  },
  {
    id: 'team-aus-w',
    name: 'Australia Women',
    shortName: 'AUS-W',
    code: 'AUS-W',
    flagColor: '#006400',
    category: "Women's",
    ranking: { test: 1, odi: 1, t20: 1 },
    stats: { played: 380, won: 290, lost: 84, draw: 6, winPercentage: 76.3 },
    keyPlayers: ['Alyssa Healy (Capt)', 'Ellyse Perry', 'Beth Mooney', 'Ashleigh Gardner']
  },
  {
    id: 'team-som',
    name: 'Somerset',
    shortName: 'SOM',
    code: 'SOM',
    flagColor: '#7A0026',
    category: "Men's",
    ranking: {},
    stats: { played: 140, won: 78, lost: 42, draw: 20, winPercentage: 55.7 },
    keyPlayers: ['Tom Banton', 'James Rew', 'Craig Overton', 'Lewis Gregory']
  },
  {
    id: 'team-sur',
    name: 'Surrey',
    shortName: 'SUR',
    code: 'SUR',
    flagColor: '#60584C',
    category: "Men's",
    ranking: {},
    stats: { played: 140, won: 86, lost: 34, draw: 20, winPercentage: 61.4 },
    keyPlayers: ['Rory Burns', 'Ollie Pope', 'Daniel Worrall', 'Sam Curran']
  }
];

// Standings / Points Tables
export const TOURNAMENT_STANDINGS: TournamentStandings[] = [
  {
    tournamentName: 'County Championship Division One 2026',
    format: 'First-Class',
    season: '2026',
    table: [
      { position: 1, team: 'Surrey', teamCode: 'SUR', played: 13, won: 8, lost: 1, tied: 0, noResult: 4, points: 198, nrr: '+0.420' },
      { position: 2, team: 'Somerset', teamCode: 'SOM', played: 13, won: 7, lost: 2, tied: 0, noResult: 4, points: 184, nrr: '+0.312' },
      { position: 3, team: 'Essex', teamCode: 'ESS', played: 13, won: 6, lost: 3, tied: 0, noResult: 4, points: 168, nrr: '+0.198' },
      { position: 4, team: 'Warwickshire', teamCode: 'WAR', played: 13, won: 5, lost: 4, tied: 0, noResult: 4, points: 154, nrr: '+0.082' },
      { position: 5, team: 'Hampshire', teamCode: 'HAM', played: 13, won: 4, lost: 4, tied: 0, noResult: 5, points: 142, nrr: '-0.015' },
      { position: 6, team: 'Nottinghamshire', teamCode: 'NOT', played: 13, won: 3, lost: 5, tied: 0, noResult: 5, points: 122, nrr: '-0.140' },
      { position: 7, team: 'Yorkshire', teamCode: 'YOR', played: 13, won: 3, lost: 6, tied: 0, noResult: 4, points: 114, nrr: '-0.210' },
      { position: 8, team: 'Sussex', teamCode: 'SUS', played: 13, won: 2, lost: 7, tied: 0, noResult: 4, points: 98, nrr: '-0.380' }
    ]
  },
  {
    tournamentName: 'CSA T20 Challenge 2026 (Pool A)',
    format: 'T20',
    season: '2026',
    table: [
      { position: 1, team: 'Lions', teamCode: 'LIO', played: 6, won: 5, lost: 1, tied: 0, noResult: 0, points: 20, nrr: '+1.240' },
      { position: 2, team: 'Warriors', teamCode: 'WAR', played: 6, won: 4, lost: 2, tied: 0, noResult: 0, points: 16, nrr: '+0.612' },
      { position: 3, team: 'Dolphins', teamCode: 'DOL', played: 6, won: 3, lost: 3, tied: 0, noResult: 0, points: 12, nrr: '-0.104' },
      { position: 4, team: 'North West Dragons', teamCode: 'NWD', played: 6, won: 2, lost: 4, tied: 0, noResult: 0, points: 8, nrr: '-0.520' },
      { position: 5, team: 'Border', teamCode: 'BOR', played: 6, won: 1, lost: 5, tied: 0, noResult: 0, points: 4, nrr: '-1.180' }
    ]
  },
  {
    tournamentName: 'ICC World Test Championship (2025-2027 Cycle)',
    format: 'Test',
    season: '2025-27',
    table: [
      { position: 1, team: 'India', teamCode: 'IND', played: 11, won: 8, lost: 2, tied: 0, noResult: 1, points: 98, nrr: '68.5% PCT' },
      { position: 2, team: 'Australia', teamCode: 'AUS', played: 12, won: 8, lost: 3, tied: 0, noResult: 1, points: 100, nrr: '62.5% PCT' },
      { position: 3, team: 'South Africa', teamCode: 'RSA', played: 8, won: 5, lost: 3, tied: 0, noResult: 0, points: 60, nrr: '62.5% PCT' },
      { position: 4, team: 'New Zealand', teamCode: 'NZ', played: 9, won: 5, lost: 4, tied: 0, noResult: 0, points: 60, nrr: '55.5% PCT' },
      { position: 5, team: 'England', teamCode: 'ENG', played: 16, won: 8, lost: 7, tied: 0, noResult: 1, points: 93, nrr: '45.1% PCT' },
      { position: 6, team: 'Sri Lanka', teamCode: 'SL', played: 9, won: 4, lost: 5, tied: 0, noResult: 0, points: 48, nrr: '44.4% PCT' }
    ]
  }
];
