import React from 'react';
import { CricketMatch } from '../types/cricket';
import { Calendar, MapPin, Clock, ChevronRight } from 'lucide-react';

interface UpcomingMatchesProps {
  matches: CricketMatch[];
  onViewScorecard: (match: CricketMatch) => void;
}

export const UpcomingMatches: React.FC<UpcomingMatchesProps> = ({
  matches,
  onViewScorecard
}) => {
  return (
    <section className="mb-10">
      <div className="flex items-center gap-2 mb-4">
        <Calendar className="w-5 h-5 text-emerald-400" />
        <h2 className="text-xl font-bold tracking-tight text-white font-['Cabinet_Grotesk']">
          Upcoming Matches
        </h2>
      </div>

      {matches.length === 0 ? (
        <div className="bg-slate-900/40 border border-slate-800 rounded-lg p-6 text-center text-slate-400 text-xs">
          No upcoming fixtures currently scheduled.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {matches.map(match => (
            <div
              key={match.id}
              className="bg-slate-900/60 border border-slate-800 rounded-lg p-4 hover:border-slate-700 transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div>
                    <span className="text-[11px] font-semibold text-emerald-400 uppercase tracking-wider block">
                      {match.series}
                    </span>
                    <span className="text-xs text-slate-300 font-medium">
                      {match.matchTitle}
                    </span>
                  </div>
                  <div className="flex items-center gap-1">
                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-800 text-slate-300">
                      {match.format}
                    </span>
                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-800/80 text-slate-400">
                      {match.category}
                    </span>
                  </div>
                </div>

                {/* Teams */}
                <div className="flex items-center justify-between py-2 border-y border-slate-800/60 my-2">
                  <div className="flex items-center gap-2">
                    <div
                      className="w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold text-white"
                      style={{ backgroundColor: match.team1.flagColor || '#334155' }}
                    >
                      {match.team1.code.slice(0, 3)}
                    </div>
                    <span className="font-semibold text-slate-200 text-sm">{match.team1.name}</span>
                  </div>

                  <span className="text-xs text-slate-500 font-bold">VS</span>

                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-slate-200 text-sm">{match.team2.name}</span>
                    <div
                      className="w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold text-white"
                      style={{ backgroundColor: match.team2.flagColor || '#334155' }}
                    >
                      {match.team2.code.slice(0, 3)}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 text-xs text-amber-300/80 mb-2">
                  <Clock className="w-3.5 h-3.5" />
                  <span>{match.timeStr}</span>
                  <span className="text-slate-500">·</span>
                  <span className="text-slate-400">{match.gmtTime}</span>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-800/60 flex items-center justify-between text-[11px] text-slate-400">
                <div className="flex items-center gap-1.5 truncate max-w-[70%]">
                  <MapPin className="w-3 h-3 text-slate-500 shrink-0" />
                  <span className="truncate">{match.venue}, {match.city}</span>
                </div>
                <button
                  onClick={() => onViewScorecard(match)}
                  className="text-emerald-400 hover:text-emerald-300 font-medium flex items-center gap-0.5 cursor-pointer"
                >
                  <span>Preview</span>
                  <ChevronRight className="w-3 h-3" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </section>
  );
};
