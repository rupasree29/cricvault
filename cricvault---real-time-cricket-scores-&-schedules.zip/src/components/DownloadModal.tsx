import React from 'react';
import { Download, X, Terminal, CheckCircle2, FolderArchive, ArrowRight } from 'lucide-react';

interface DownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DownloadModal: React.FC<DownloadModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const handleDownload = () => {
    const link = document.createElement('a');
    link.href = '/cricvault-cricket-app.zip';
    link.download = 'cricvault-cricket-app.zip';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fadeIn">
      <div 
        className="bg-slate-900 border border-slate-700/80 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden text-slate-100"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-6 py-5 bg-gradient-to-r from-emerald-950/60 to-slate-900 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <FolderArchive className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-lg text-white font-['Cabinet_Grotesk']">
                Download Project ZIP
              </h3>
              <p className="text-xs text-slate-400">
                Ready to unzip and run directly on your desktop
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5">
          {/* File summary card */}
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800/80 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                <Download className="w-5 h-5" />
              </div>
              <div>
                <div className="text-sm font-semibold text-white font-mono">
                  cricvault-cricket-app.zip
                </div>
                <div className="text-xs text-slate-400">
                  Full codebase • Men & Women Squads • Clean configuration
                </div>
              </div>
            </div>
            <a
              href="/cricvault-cricket-app.zip"
              download="cricvault-cricket-app.zip"
              onClick={handleDownload}
              className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs rounded-lg transition-colors flex items-center gap-1.5 shadow-sm shadow-emerald-500/20"
            >
              <Download className="w-4 h-4" />
              <span>Download</span>
            </a>
          </div>

          {/* Quick instructions on how to run on Desktop */}
          <div className="space-y-3">
            <h4 className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-2">
              <Terminal className="w-4 h-4 text-emerald-400" />
              <span>How to run on your desktop</span>
            </h4>

            <ol className="space-y-2.5 text-xs text-slate-300">
              <li className="flex items-start gap-2.5 p-2 rounded-lg bg-slate-800/40 border border-slate-800">
                <span className="w-5 h-5 rounded-full bg-slate-700 text-emerald-400 font-bold flex items-center justify-center shrink-0 text-[10px]">
                  1
                </span>
                <div>
                  <span className="font-semibold text-white">Extract the ZIP:</span> Save and unzip <code className="px-1.5 py-0.5 rounded bg-slate-950 text-emerald-300 font-mono text-[11px]">cricvault-cricket-app.zip</code> to your Desktop.
                </div>
              </li>
              <li className="flex items-start gap-2.5 p-2 rounded-lg bg-slate-800/40 border border-slate-800">
                <span className="w-5 h-5 rounded-full bg-slate-700 text-emerald-400 font-bold flex items-center justify-center shrink-0 text-[10px]">
                  2
                </span>
                <div>
                  <span className="font-semibold text-white">Open Terminal:</span> Open PowerShell, Command Prompt, or Terminal in that folder.
                </div>
              </li>
              <li className="flex items-start gap-2.5 p-2 rounded-lg bg-slate-800/40 border border-slate-800">
                <span className="w-5 h-5 rounded-full bg-slate-700 text-emerald-400 font-bold flex items-center justify-center shrink-0 text-[10px]">
                  3
                </span>
                <div className="w-full">
                  <span className="font-semibold text-white">Install and Start:</span>
                  <div className="mt-1 p-2 rounded bg-slate-950 font-mono text-[11px] text-emerald-300 border border-slate-800/80">
                    npm install && npm run dev
                  </div>
                </div>
              </li>
              <li className="flex items-start gap-2.5 p-2 rounded-lg bg-slate-800/40 border border-slate-800">
                <span className="w-5 h-5 rounded-full bg-slate-700 text-emerald-400 font-bold flex items-center justify-center shrink-0 text-[10px]">
                  4
                </span>
                <div>
                  <span className="font-semibold text-white">View in Browser:</span> Open <code className="px-1.5 py-0.5 rounded bg-slate-950 text-emerald-300 font-mono text-[11px]">http://localhost:3000</code>.
                </div>
              </li>
            </ol>
          </div>

          <div className="p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-xs text-emerald-300 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Includes all authentic player rosters, match schedules, live updates & design tokens.</span>
          </div>
        </div>

        {/* Footer actions */}
        <div className="px-6 py-4 bg-slate-950 border-t border-slate-800 flex items-center justify-between">
          <span className="text-[11px] text-slate-500">
            ZIP size ~1.9 MB • No node_modules bloat
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-3.5 py-1.5 text-xs text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
            >
              Close
            </button>
            <a
              href="/cricvault-cricket-app.zip"
              download="cricvault-cricket-app.zip"
              onClick={handleDownload}
              className="px-4 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs rounded-lg transition-colors flex items-center gap-1.5"
            >
              <Download className="w-4 h-4" />
              <span>Download ZIP Now</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
