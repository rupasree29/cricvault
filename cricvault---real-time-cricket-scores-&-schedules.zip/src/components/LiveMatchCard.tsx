import React from 'react';
import { CricketMatch } from '../types/cricket';
import { MapPin, Trophy, Shield, ChevronRight } from 'lucide-react';

interface LiveMatchCardProps {
  match: CricketMatch;
  onViewScorecard: (match: CricketMatch) => void;
}

export const LiveMatchCard: React.FC<LiveMatchCardProps> = ({
  match,
  onViewScorecard
}) => {
  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 hover:border-slate-700 transition-all shadow-lg relative overflow-hidden group">
      
      {/* Top Banner / Series Info & LIVE indicator */}
      <div className="flex items-start justify-between gap-2 mb-3">
        <div>
          <span className="text-xs font-semibold text-emerald-400 tracking-wide uppercase">
            {match.series}
          </span>
          <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5">
            <span>{match.matchTitle}</span>
            <span aria-hidden="true">·</span>
            <span>{match.format}</span>
            <span aria-hidden="true">·</span>
            <span>{match.category}</span>
          </div>
        </div>

        {/* 🔴 LIVE indicator */}
        <div className="flex items-center gap-1.5 px-2.5 py-1 bg-red-500/10 border border-red-500/30 rounded-full text-red-400 text-xs font-bold tracking-wide animate-pulse">
          <span className="w-2 h-2 rounded-full bg-red-500 animate-ping"></span>
          <span>🔴 LIVE</span>
        </div>
      </div>

      {/* Main Score Area */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 my-3 bg-slate-950/70 p-3.5 rounded-lg border border-slate-800/80">
        
        {/* Team 1 */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div
              className="w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs text-white shadow-inner"
              style={{ backgroundColor: match.team1.flagColor || '#334155' }}
            >
              {match.team1.code}
            </div>
            <div>
              <div className="font-semibold text-slate-100 text-sm md:text-base">
                {match.team1.name}
              </div>
              <div className="text-[11px] text-slate-400">{match.team1.shortName}</div>
            </div>
          </div>
          <div className="text-right">
            <div className="font-mono text-base md:text-lg font-bold text-slate-200 tabular-nums">
              {match.team1.score || 'Yet to bat'}
            </div>
          </div>
        </div>

        {/* Team 2 */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div
              className="w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs text-white shadow-inner"
              style={{ backgroundColor: match.team2.flagColor || '#334155' }}
            >
              {match.team2.code}
            </div>
            <div>
              <div className="font-semibold text-slate-100 text-sm md:text-base flex items-center gap-1.5">
                <span>{match.team2.name}</span>
                {match.currentBattingTeam === match.team2.name && (
                  <span className="inline-block w-2 h-2 rounded-full bg-emerald-400" title="Currently Batting"></span>
                )}
              </div>
              <div className="text-[11px] text-slate-400">{match.team2.shortName}</div>
            </div>
          </div>
          <div className="text-right">
            <div className="font-mono text-base md:text-lg font-bold text-emerald-400 tabular-nums">
              {match.team2.score || 'Yet to bat'}
            </div>
          </div>
        </div>

      </div>

      {/* Live Match Situation Note */}
      <div className="text-sm font-medium text-amber-300/90 mb-3 bg-amber-500/5 px-3 py-1.5 rounded border border-amber-500/10">
        {match.statusNote}
      </div>

      {/* Target & Run Rates bar */}
      {(match.currentRunRate !== undefined || match.target !== undefined) && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs py-2 px-3 bg-slate-950/40 rounded border border-slate-800/60 mb-3">
          {match.currentRunRate !== undefined && (
            <div>
              <span className="text-slate-400 block text-[11px]">Current RR:</span>
              <span className="font-mono font-semibold text-slate-200 tabular-nums">
                {match.currentRunRate.toFixed(2)}
              </span>
            </div>
          )}
          {match.requiredRunRate !== undefined && (
            <div>
              <span className="text-slate-400 block text-[11px]">Required RR:</span>
              <span className="font-mono font-semibold text-amber-400 tabular-nums">
                {match.requiredRunRate.toFixed(2)}
              </span>
            </div>
          )}
          {match.target !== undefined && (
            <div>
              <span className="text-slate-400 block text-[11px]">Target:</span>
              <span className="font-mono font-semibold text-slate-200 tabular-nums">
                {match.target}
              </span>
            </div>
          )}
          {match.ballsRemaining !== undefined && (
            <div>
              <span className="text-slate-400 block text-[11px]">Remaining:</span>
              <span className="font-mono font-semibold text-slate-200 tabular-nums">
                {match.runsRequired} runs / {match.ballsRemaining} balls
              </span>
            </div>
          )}
        </div>
      )}

      {/* Live Batsmen & Bowler Information */}
      {match.currentBatsmen && match.currentBatsmen.length > 0 && (
        <div className="border-t border-slate-800 pt-3 mb-3">
          <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1.5 flex items-center justify-between">
            <span>Batsmen on Crease</span>
            {match.partnership && (
              <span className="text-slate-400 font-mono text-[10px]">
                Partnership: {match.partnership.runs} ({match.partnership.balls})
              </span>
            )}
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="text-slate-500 border-b border-slate-800/60 text-left">
                  <th className="py-1">Batter</th>
                  <th className="py-1 text-right">R</th>
                  <th className="py-1 text-right">B</th>
                  <th className="py-1 text-right">4s</th>
                  <th className="py-1 text-right">6s</th>
                  <th className="py-1 text-right">SR</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/40">
                {match.currentBatsmen.map((b, idx) => (
                  <tr key={idx} className="font-mono text-slate-300">
                    <td className="py-1 text-left font-sans text-slate-200 flex items-center gap-1 font-medium">
                      <span>{b.name}</span>
                      {b.isOnStrike && <span className="text-emerald-400 font-bold">*</span>}
                    </td>
                    <td className="py-1 text-right font-bold text-white tabular-nums">{b.runs}</td>
                    <td className="py-1 text-right tabular-nums text-slate-400">{b.balls}</td>
                    <td className="py-1 text-right tabular-nums">{b.fours}</td>
                    <td className="py-1 text-right tabular-nums">{b.sixes}</td>
                    <td className="py-1 text-right tabular-nums text-slate-400">{b.strikeRate.toFixed(1)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Current Bowler */}
      {match.currentBowler && (
        <div className="border-t border-slate-800 pt-2 mb-3">
          <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1 flex items-center justify-between">
            <span>Bowler</span>
            {match.recentBalls && match.recentBalls.length > 0 && (
              <div className="flex items-center gap-1 text-[11px] font-mono">
                <span className="text-slate-400 text-[10px] mr-1 font-sans">This Over:</span>
                {match.recentBalls.map((ball, i) => (
                  <span
                    key={i}
                    className={`w-4 h-4 rounded-full flex items-center justify-center text-[10px] font-bold ${
                      ball === 'W'
                        ? 'bg-red-500 text-white'
                        : ball === '4' || ball === '6'
                        ? 'bg-amber-500 text-slate-950'
                        : 'bg-slate-800 text-slate-300'
                    }`}
                  >
                    {ball}
                  </span>
                ))}
              </div>
            )}
          </div>
          <div className="flex items-center justify-between text-xs font-mono text-slate-300">
            <span className="font-sans font-medium text-slate-200">{match.currentBowler.name}</span>
            <div className="flex items-center gap-3 tabular-nums">
              <span>{match.currentBowler.overs} ov</span>
              <span>{match.currentBowler.maidens} m</span>
              <span>{match.currentBowler.runs} r</span>
              <span className="font-bold text-emerald-400">{match.currentBowler.wickets} w</span>
              <span className="text-slate-400">Econ {match.currentBowler.economy.toFixed(2)}</span>
            </div>
          </div>
        </div>
      )}

      {/* Winning Probability */}
      <div className="border-t border-slate-800/80 pt-2.5 mb-3 text-xs">
        <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1">
          <span>Win Probability</span>
          {match.winningProbability ? (
            <span className="font-mono text-slate-300">
              {match.team1.shortName} {match.winningProbability.team1}% · {match.team2.shortName} {match.winningProbability.team2}%
            </span>
          ) : (
            <span className="italic text-slate-500">Winning probability unavailable</span>
          )}
        </div>
        {match.winningProbability && (
          <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden flex">
            <div
              className="bg-emerald-500 h-full transition-all duration-500"
              style={{ width: `${match.winningProbability.team1}%` }}
              title={`${match.team1.name}: ${match.winningProbability.team1}%`}
            />
            <div
              className="bg-teal-400 h-full transition-all duration-500"
              style={{ width: `${match.winningProbability.team2}%` }}
              title={`${match.team2.name}: ${match.winningProbability.team2}%`}
            />
          </div>
        )}
      </div>

      {/* Footer: Venue, Toss & Scorecard Button */}
      <div className="border-t border-slate-800/80 pt-3 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400">
        <div className="flex items-center gap-1.5 truncate max-w-[70%]">
          <MapPin className="w-3.5 h-3.5 text-slate-500 shrink-0" />
          <span className="truncate">{match.venue}, {match.city}</span>
        </div>

        <button
          onClick={() => onViewScorecard(match)}
          className="flex items-center gap-1 text-emerald-400 hover:text-emerald-300 font-medium cursor-pointer ml-auto group-hover:translate-x-0.5 transition-transform"
        >
          <span>Scorecard</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

    </div>
  );
};
