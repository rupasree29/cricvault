import React from 'react';
import { CricketMatch } from '../types/cricket';
import { Calendar, MapPin, Clock, ChevronRight } from 'lucide-react';
import { formatDisplayDate } from '../services/cricketDatabase';

interface TomorrowMatchesProps {
  matches: CricketMatch[];
  onViewScorecard: (match: CricketMatch) => void;
}

export const TomorrowMatches: React.FC<TomorrowMatchesProps> = ({
  matches,
  onViewScorecard
}) => {
  const tomorrowDate = new Date();
  tomorrowDate.setDate(tomorrowDate.getDate() + 1);
  const tomorrowFormatted = formatDisplayDate(tomorrowDate);

  const mensMatches = matches.filter(m => m.category === "Men's");
  const womensMatches = matches.filter(m => m.category === "Women's");

  const renderMatchCard = (match: CricketMatch) => (
    <div
      key={match.id}
      className="bg-slate-900/60 border border-slate-800 rounded-lg p-4 hover:border-slate-700 transition-all flex flex-col justify-between"
    >
      <div>
        <div className="flex items-start justify-between gap-2 mb-2">
          <div className="truncate">
            <span className="text-[11px] font-semibold text-emerald-400 uppercase tracking-wider block truncate">
              {match.series}
            </span>
            <span className="text-xs text-slate-300 font-medium">
              {match.matchTitle}
            </span>
          </div>
          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-400 shrink-0">
            {match.format}
          </span>
        </div>

        {/* Teams */}
        <div className="space-y-1.5 py-2.5 my-1.5 border-y border-slate-800/60">
          <div className="flex items-center justify-between text-sm font-semibold text-slate-200">
            <div className="flex items-center gap-2">
              <div
                className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold text-white"
                style={{ backgroundColor: match.team1.flagColor || '#334155' }}
              >
                {match.team1.code.slice(0, 3)}
              </div>
              <span>{match.team1.name}</span>
            </div>
            <span className="text-xs text-slate-400">{match.team1.shortName}</span>
          </div>

          <div className="flex items-center justify-between text-sm font-semibold text-slate-200">
            <div className="flex items-center gap-2">
              <div
                className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold text-white"
                style={{ backgroundColor: match.team2.flagColor || '#334155' }}
              >
                {match.team2.code.slice(0, 3)}
              </div>
              <span>{match.team2.name}</span>
            </div>
            <span className="text-xs text-slate-400">{match.team2.shortName}</span>
          </div>
        </div>

        <div className="flex items-center gap-1.5 text-xs text-amber-300/80 mb-3">
          <Clock className="w-3.5 h-3.5" />
          <span>{match.timeStr}</span>
          <span className="text-slate-500">·</span>
          <span className="text-slate-400 text-[11px]">{match.gmtTime}</span>
        </div>
      </div>

      <div className="pt-2 border-t border-slate-800/60 flex items-center justify-between text-[11px] text-slate-400">
        <div className="flex items-center gap-1.5 truncate max-w-[70%]">
          <MapPin className="w-3 h-3 text-slate-500 shrink-0" />
          <span className="truncate">{match.venue}, {match.city}</span>
        </div>
        <button
          onClick={() => onViewScorecard(match)}
          className="text-emerald-400 hover:text-emerald-300 font-medium flex items-center gap-0.5 cursor-pointer"
        >
          <span>Preview</span>
          <ChevronRight className="w-3 h-3" />
        </button>
      </div>
    </div>
  );

  return (
    <section className="mb-10">
      
      <div className="flex items-center gap-2 mb-4">
        <Calendar className="w-5 h-5 text-emerald-400" />
        <h2 className="text-xl font-bold tracking-tight text-white font-['Cabinet_Grotesk']">
          Tomorrow's Matches
        </h2>
        <span className="text-xs text-slate-400 ml-1">
          ({tomorrowFormatted})
        </span>
      </div>

      {/* Men's Tomorrow Matches */}
      <div className="mb-8">
        <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-300 mb-3 flex items-center gap-2">
          <span>Men's Tomorrow Matches</span>
          <span className="text-xs font-mono text-slate-500 font-normal">({mensMatches.length})</span>
        </h3>

        {mensMatches.length === 0 ? (
          <div className="bg-slate-900/40 border border-slate-800/60 rounded-lg p-6 text-center text-slate-400 text-xs">
            No men's matches scheduled for tomorrow.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {mensMatches.map(renderMatchCard)}
          </div>
        )}
      </div>

      {/* Women's Tomorrow Matches */}
      <div>
        <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-300 mb-3 flex items-center gap-2">
          <span>Women's Tomorrow Matches</span>
          <span className="text-xs font-mono text-slate-500 font-normal">({womensMatches.length})</span>
        </h3>

        {womensMatches.length === 0 ? (
          <div className="bg-slate-900/40 border border-slate-800/60 rounded-lg p-6 text-center text-slate-400 text-xs">
            No women's matches scheduled for tomorrow.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {womensMatches.map(renderMatchCard)}
          </div>
        )}
      </div>

    </section>
  );
};
