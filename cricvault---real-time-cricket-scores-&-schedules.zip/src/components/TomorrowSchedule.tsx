import React, { useState } from 'react';
import { CricketMatch } from '../types/cricket';
import { CalendarDays, MapPin, Clock, ChevronRight, Shield, Sparkles } from 'lucide-react';
import { formatDisplayDate } from '../services/cricketDatabase';

interface TomorrowScheduleProps {
  tomorrowMatches: CricketMatch[];
  dayAfterMatches: CricketMatch[];
  onViewScorecard: (match: CricketMatch) => void;
}

export const TomorrowSchedule: React.FC<TomorrowScheduleProps> = ({
  tomorrowMatches,
  dayAfterMatches,
  onViewScorecard
}) => {
  const [dayFilter, setDayFilter] = useState<'ALL' | 'TOMORROW' | 'DAY_AFTER'>('ALL');
  const [formatFilter, setFormatFilter] = useState<string>('ALL');

  const tomorrowDate = new Date();
  tomorrowDate.setDate(tomorrowDate.getDate() + 1);
  const tomorrowFormatted = formatDisplayDate(tomorrowDate);

  const dayAfterDate = new Date();
  dayAfterDate.setDate(dayAfterDate.getDate() + 2);
  const dayAfterFormatted = formatDisplayDate(dayAfterDate);

  const filterMatchList = (list: CricketMatch[]) => {
    return list.filter(m => {
      if (formatFilter === 'ALL') return true;
      if (formatFilter === "Women's") return m.category === "Women's";
      if (formatFilter === "Men's") return m.category === "Men's";
      if (formatFilter === 'T20') return m.format === 'T20' || m.format === 'T20 League';
      if (formatFilter === 'Domestic') return m.format === 'Domestic' || m.series.includes('County');
      if (formatFilter === 'ODI') return m.format === 'ODI';
      if (formatFilter === 'Test') return m.format === 'Test';
      return true;
    });
  };

  const filteredTomorrow = filterMatchList(tomorrowMatches);
  const filteredDayAfter = filterMatchList(dayAfterMatches);

  const renderMatchCard = (match: CricketMatch, dayLabel: string) => (
    <div
      key={match.id}
      className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 sm:p-5 hover:border-emerald-500/50 hover:bg-slate-900/95 transition-all shadow-md flex flex-col justify-between group"
    >
      <div>
        {/* Top Header: Series, Format badge & Day tag */}
        <div className="flex items-start justify-between gap-2 mb-2.5">
          <div className="min-w-0">
            <span className="text-xs font-semibold text-emerald-400 uppercase tracking-wider block truncate">
              {match.series}
            </span>
            <span className="text-xs text-slate-300 font-medium line-clamp-1">
              {match.matchTitle}
            </span>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700/60">
              {match.format}
            </span>
            <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-emerald-950/60 border border-emerald-800/80 text-emerald-300">
              {dayLabel}
            </span>
          </div>
        </div>

        {/* Teams & Short Codes */}
        <div className="py-3 my-2 border-y border-slate-800/80 space-y-2 bg-slate-950/50 px-3 rounded-lg">
          <div className="flex items-center justify-between text-sm font-semibold text-slate-100">
            <div className="flex items-center gap-2.5">
              <div
                className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold text-white shadow-sm"
                style={{ backgroundColor: match.team1.flagColor || '#334155' }}
              >
                {match.team1.code.slice(0, 3)}
              </div>
              <span className="text-sm text-slate-100 group-hover:text-emerald-300 transition-colors">
                {match.team1.name}
              </span>
            </div>
            <span className="text-xs font-mono text-slate-400 font-normal">
              {match.team1.shortName}
            </span>
          </div>

          <div className="flex items-center justify-between text-sm font-semibold text-slate-100">
            <div className="flex items-center gap-2.5">
              <div
                className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold text-white shadow-sm"
                style={{ backgroundColor: match.team2.flagColor || '#334155' }}
              >
                {match.team2.code.slice(0, 3)}
              </div>
              <span className="text-sm text-slate-100 group-hover:text-emerald-300 transition-colors">
                {match.team2.name}
              </span>
            </div>
            <span className="text-xs font-mono text-slate-400 font-normal">
              {match.team2.shortName}
            </span>
          </div>
        </div>

        {/* Scheduled Time */}
        <div className="flex items-center gap-2 text-xs text-amber-300/90 font-medium mb-3">
          <Clock className="w-3.5 h-3.5 text-amber-400 shrink-0" />
          <span>{match.timeStr}</span>
          <span className="text-slate-600">·</span>
          <span className="text-slate-400 text-[11px] font-mono">{match.gmtTime}</span>
        </div>
      </div>

      {/* Footer: Venue and Preview Action */}
      <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
        <div className="flex items-center gap-1.5 truncate max-w-[68%]">
          <MapPin className="w-3.5 h-3.5 text-slate-500 shrink-0" />
          <span className="truncate">{match.venue}, {match.city}</span>
        </div>
        <button
          onClick={() => onViewScorecard(match)}
          className="text-emerald-400 hover:text-emerald-300 font-medium flex items-center gap-1 cursor-pointer group-hover:translate-x-0.5 transition-transform"
        >
          <span>Match Preview</span>
          <ChevronRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900/90 to-slate-950 border border-slate-800 rounded-2xl p-6 mb-8 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold uppercase tracking-wider mb-1.5">
              <CalendarDays className="w-4 h-4" />
              <span>UPCOMING FIXTURES · NEXT 2 DAYS</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight font-['Cabinet_Grotesk']">
              Tomorrow & Next Day Cricket Schedule
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 mt-1">
              Complete schedule for <strong className="text-emerald-400 font-medium">{tomorrowFormatted} (Tomorrow)</strong> and <strong className="text-teal-400 font-medium">{dayAfterFormatted} (Day After)</strong>
            </p>
          </div>

          <div className="flex items-center gap-3 bg-slate-950/80 p-2 rounded-xl border border-slate-800/80 self-start md:self-auto font-mono text-xs">
            <div className="text-center px-3 py-1">
              <span className="block text-[10px] text-slate-500 font-sans">Tomorrow</span>
              <span className="text-base font-bold text-emerald-400">{tomorrowMatches.length}</span>
            </div>
            <div className="h-8 w-px bg-slate-800" />
            <div className="text-center px-3 py-1">
              <span className="block text-[10px] text-slate-500 font-sans">Day After</span>
              <span className="text-base font-bold text-teal-400">{dayAfterMatches.length}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Filter and Switcher Controls */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 mb-8 bg-slate-900/60 p-3 rounded-xl border border-slate-800">
        
        {/* Day selection tabs */}
        <div className="flex items-center gap-1.5 bg-slate-950 p-1.5 rounded-lg border border-slate-800 text-xs overflow-x-auto no-scrollbar">
          <button
            onClick={() => setDayFilter('ALL')}
            className={`px-3.5 py-1.5 rounded-md font-semibold transition-all whitespace-nowrap cursor-pointer ${
              dayFilter === 'ALL'
                ? 'bg-emerald-500 text-slate-950 font-bold shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            All (Tomorrow & Day After) ({tomorrowMatches.length + dayAfterMatches.length})
          </button>
          <button
            onClick={() => setDayFilter('TOMORROW')}
            className={`px-3.5 py-1.5 rounded-md font-semibold transition-all whitespace-nowrap cursor-pointer ${
              dayFilter === 'TOMORROW'
                ? 'bg-emerald-500 text-slate-950 font-bold shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Tomorrow ({tomorrowMatches.length})
          </button>
          <button
            onClick={() => setDayFilter('DAY_AFTER')}
            className={`px-3.5 py-1.5 rounded-md font-semibold transition-all whitespace-nowrap cursor-pointer ${
              dayFilter === 'DAY_AFTER'
                ? 'bg-emerald-500 text-slate-950 font-bold shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Day After ({dayAfterMatches.length})
          </button>
        </div>

        {/* Format / Category subfilters */}
        <div className="flex items-center gap-1 bg-slate-950 p-1.5 rounded-lg border border-slate-800 text-xs overflow-x-auto no-scrollbar">
          {['ALL', 'T20', 'Domestic', 'ODI', 'Test', "Women's"].map(fmt => (
            <button
              key={fmt}
              onClick={() => setFormatFilter(fmt)}
              className={`px-2.5 py-1 rounded transition-colors whitespace-nowrap cursor-pointer ${
                formatFilter === fmt
                  ? 'bg-slate-800 text-emerald-400 font-bold border border-slate-700'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {fmt === 'ALL' ? 'All Formats' : fmt}
            </button>
          ))}
        </div>

      </div>

      {/* SECTION 1: TOMORROW'S MATCHES */}
      {(dayFilter === 'ALL' || dayFilter === 'TOMORROW') && (
        <section className="mb-12">
          <div className="flex items-center justify-between mb-4 border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2.5">
              <div className="w-2.5 h-2.5 rounded-full bg-emerald-400"></div>
              <h2 className="text-lg sm:text-xl font-bold text-white font-['Cabinet_Grotesk']">
                Tomorrow's Cricket Matches
              </h2>
              <span className="text-xs font-mono px-2 py-0.5 rounded bg-slate-800 text-emerald-400 font-semibold">
                {tomorrowFormatted}
              </span>
            </div>
            <span className="text-xs text-slate-400 font-mono">
              {filteredTomorrow.length} Matches
            </span>
          </div>

          {filteredTomorrow.length === 0 ? (
            <div className="bg-slate-900/40 border border-slate-800 rounded-xl p-8 text-center text-slate-400 text-xs">
              No matches scheduled for tomorrow under the selected filter.
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {filteredTomorrow.map(m => renderMatchCard(m, 'Tomorrow'))}
            </div>
          )}
        </section>
      )}

      {/* SECTION 2: DAY AFTER TOMORROW'S MATCHES */}
      {(dayFilter === 'ALL' || dayFilter === 'DAY_AFTER') && (
        <section className="mb-10">
          <div className="flex items-center justify-between mb-4 border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2.5">
              <div className="w-2.5 h-2.5 rounded-full bg-teal-400"></div>
              <h2 className="text-lg sm:text-xl font-bold text-white font-['Cabinet_Grotesk']">
                Day After Tomorrow Matches
              </h2>
              <span className="text-xs font-mono px-2 py-0.5 rounded bg-slate-800 text-teal-400 font-semibold">
                {dayAfterFormatted}
              </span>
            </div>
            <span className="text-xs text-slate-400 font-mono">
              {filteredDayAfter.length} Matches
            </span>
          </div>

          {filteredDayAfter.length === 0 ? (
            <div className="bg-slate-900/40 border border-slate-800 rounded-xl p-8 text-center text-slate-400 text-xs">
              No matches scheduled for the day after tomorrow under the selected filter.
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {filteredDayAfter.map(m => renderMatchCard(m, 'Day After'))}
            </div>
          )}
        </section>
      )}

    </div>
  );
};
