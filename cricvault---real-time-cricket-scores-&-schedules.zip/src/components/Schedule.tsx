import React, { useState } from 'react';
import { CricketMatch } from '../types/cricket';
import { Calendar, MapPin, Clock, ChevronRight } from 'lucide-react';
import { formatDisplayDate } from '../services/cricketDatabase';

interface ScheduleProps {
  matches: CricketMatch[];
  onViewScorecard: (match: CricketMatch) => void;
}

export const Schedule: React.FC<ScheduleProps> = ({ matches, onViewScorecard }) => {
  const [filterType, setFilterType] = useState<string>('ALL');

  // Filter matches based on category/format tabs
  const filtered = matches.filter(m => {
    if (filterType === 'ALL') return true;
    if (filterType === 'International') return m.format === 'Test' || m.format === 'ODI' || (m.format === 'T20' && !m.series.includes('CSA') && !m.series.includes('County'));
    if (filterType === 'T20') return m.format === 'T20' || m.format === 'T20 League';
    if (filterType === 'Domestic') return m.format === 'Domestic' || m.series.includes('County') || m.series.includes('Australia Domestic');
    if (filterType === 'Women') return m.category === "Women's";
    return true;
  });

  // Group matches by date
  const groupedByDate: { [date: string]: CricketMatch[] } = {};
  filtered.forEach(m => {
    if (!groupedByDate[m.dateStr]) {
      groupedByDate[m.dateStr] = [];
    }
    groupedByDate[m.dateStr].push(m);
  });

  const sortedDates = Object.keys(groupedByDate).sort();

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      
      {/* Header */}
      <div className="mb-6">
        <div className="flex items-center gap-2 mb-1">
          <Calendar className="w-6 h-6 text-emerald-400" />
          <h1 className="text-2xl font-bold tracking-tight text-white font-['Cabinet_Grotesk']">
            Cricket Fixtures & Schedule
          </h1>
        </div>
        <p className="text-xs text-slate-400">
          International tours, domestic leagues, multi-day championships, and women's series
        </p>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-2 mb-6 bg-slate-900/80 p-1.5 rounded-xl border border-slate-800 text-xs w-full sm:w-auto">
        <button
          onClick={() => setFilterType('ALL')}
          className={`px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
            filterType === 'ALL' ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          All Matches
        </button>
        <button
          onClick={() => setFilterType('International')}
          className={`px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
            filterType === 'International' ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          International
        </button>
        <button
          onClick={() => setFilterType('T20')}
          className={`px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
            filterType === 'T20' ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          T20 Leagues
        </button>
        <button
          onClick={() => setFilterType('Domestic')}
          className={`px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
            filterType === 'Domestic' ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Domestic
        </button>
        <button
          onClick={() => setFilterType('Women')}
          className={`px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
            filterType === 'Women' ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Women
        </button>
      </div>

      {/* Schedule by Date Groups */}
      {sortedDates.length === 0 ? (
        <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-12 text-center text-slate-400">
          No matches scheduled for the selected category.
        </div>
      ) : (
        <div className="space-y-8">
          {sortedDates.map(dateKey => {
            const dateObj = new Date(dateKey + 'T00:00:00');
            const dayLabel = formatDisplayDate(dateObj);
            const matchesForDate = groupedByDate[dateKey];

            return (
              <div key={dateKey} className="space-y-3">
                <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
                  <span className="text-xs font-bold font-mono uppercase tracking-wider text-emerald-400">
                    {dayLabel}
                  </span>
                  <span className="text-xs text-slate-500 font-mono">
                    ({matchesForDate.length} {matchesForDate.length === 1 ? 'match' : 'matches'})
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {matchesForDate.map(match => (
                    <div
                      key={match.id}
                      className="bg-slate-900/70 border border-slate-800 rounded-xl p-4 hover:border-slate-700 transition-all flex flex-col justify-between"
                    >
                      <div>
                        <div className="flex items-start justify-between gap-2 mb-2">
                          <span className="text-[11px] font-semibold text-emerald-400 uppercase tracking-wide truncate">
                            {match.series}
                          </span>
                          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-400 shrink-0">
                            {match.format}
                          </span>
                        </div>

                        <div className="text-xs text-slate-300 font-medium mb-2.5">
                          {match.matchTitle}
                        </div>

                        <div className="py-2.5 border-y border-slate-800/80 space-y-1.5 my-2">
                          <div className="flex items-center justify-between text-sm font-semibold text-slate-100">
                            <div className="flex items-center gap-2">
                              <div
                                className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold text-white"
                                style={{ backgroundColor: match.team1.flagColor || '#334155' }}
                              >
                                {match.team1.code.slice(0, 3)}
                              </div>
                              <span>{match.team1.name}</span>
                            </div>
                            {match.team1.score && (
                              <span className="text-xs font-mono text-slate-300 tabular-nums">{match.team1.score}</span>
                            )}
                          </div>

                          <div className="flex items-center justify-between text-sm font-semibold text-slate-100">
                            <div className="flex items-center gap-2">
                              <div
                                className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold text-white"
                                style={{ backgroundColor: match.team2.flagColor || '#334155' }}
                              >
                                {match.team2.code.slice(0, 3)}
                              </div>
                              <span>{match.team2.name}</span>
                            </div>
                            {match.team2.score && (
                              <span className="text-xs font-mono text-emerald-400 tabular-nums">{match.team2.score}</span>
                            )}
                          </div>
                        </div>

                        <div className="flex items-center gap-1.5 text-xs text-amber-300/80 mb-2">
                          <Clock className="w-3.5 h-3.5" />
                          <span>{match.timeStr}</span>
                          <span className="text-slate-500">·</span>
                          <span className="text-slate-400 text-[11px]">{match.gmtTime}</span>
                        </div>
                      </div>

                      <div className="pt-2 border-t border-slate-800/60 flex items-center justify-between text-[11px] text-slate-400">
                        <div className="flex items-center gap-1.5 truncate max-w-[70%]">
                          <MapPin className="w-3 h-3 text-slate-500 shrink-0" />
                          <span className="truncate">{match.venue}</span>
                        </div>
                        <button
                          onClick={() => onViewScorecard(match)}
                          className="text-emerald-400 hover:text-emerald-300 font-medium flex items-center gap-0.5 cursor-pointer"
                        >
                          <span>Details</span>
                          <ChevronRight className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      )}

    </div>
  );
};
