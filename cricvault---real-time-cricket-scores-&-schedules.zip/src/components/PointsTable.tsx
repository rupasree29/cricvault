import React, { useState, useEffect } from 'react';
import { TournamentStandings } from '../types/cricket';
import { cricketApi } from '../services/cricketApi';
import { Trophy } from 'lucide-react';

export const PointsTable: React.FC = () => {
  const [standings, setStandings] = useState<TournamentStandings[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [selectedTournamentIdx, setSelectedTournamentIdx] = useState<number>(0);

  useEffect(() => {
    loadStandings();
  }, []);

  const loadStandings = async () => {
    setLoading(true);
    try {
      const data = await cricketApi.getStandings();
      setStandings(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="h-64 bg-slate-900/50 border border-slate-800 rounded-xl animate-pulse" />
      </div>
    );
  }

  if (standings.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-8 text-center text-slate-400">
        Data unavailable. No tournament standings currently active.
      </div>
    );
  }

  const currentTournament = standings[selectedTournamentIdx] || standings[0];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      
      {/* Header */}
      <div className="mb-6">
        <div className="flex items-center gap-2 mb-1">
          <Trophy className="w-6 h-6 text-emerald-400" />
          <h1 className="text-2xl font-bold tracking-tight text-white font-['Cabinet_Grotesk']">
            Tournament Standings & Points Table
          </h1>
        </div>
        <p className="text-xs text-slate-400">
          Official points, net run rates, and tournament progression tables
        </p>
      </div>

      {/* Tournament Selector Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-3 mb-6 no-scrollbar">
        {standings.map((tourn, idx) => (
          <button
            key={idx}
            onClick={() => setSelectedTournamentIdx(idx)}
            className={`px-4 py-2 rounded-lg text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
              selectedTournamentIdx === idx
                ? 'bg-emerald-500 text-slate-950 font-bold shadow-md'
                : 'bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:border-slate-700'
            }`}
          >
            {tourn.tournamentName}
          </button>
        ))}
      </div>

      {/* Points Table Container */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-xl overflow-hidden shadow-xl">
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-white font-['Cabinet_Grotesk']">
              {currentTournament.tournamentName}
            </h2>
            <div className="text-xs text-slate-400">
              Season: {currentTournament.season} · Format: {currentTournament.format}
            </div>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead>
              <tr className="bg-slate-950/60 border-b border-slate-800 text-slate-400 uppercase text-[10px] tracking-wider">
                <th className="py-3 px-4 text-center w-12">Pos</th>
                <th className="py-3 px-4">Team</th>
                <th className="py-3 px-3 text-right">P</th>
                <th className="py-3 px-3 text-right">W</th>
                <th className="py-3 px-3 text-right">L</th>
                <th className="py-3 px-3 text-right">T</th>
                <th className="py-3 px-3 text-right">NR</th>
                <th className="py-3 px-4 text-right font-bold text-emerald-400">PTS</th>
                <th className="py-3 px-4 text-right">NRR / PCT</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {currentTournament.table.map((row) => (
                <tr
                  key={row.teamCode}
                  className="hover:bg-slate-800/30 transition-colors"
                >
                  <td className="py-3 px-4 text-center font-bold text-slate-400 tabular-nums">
                    {row.position}
                  </td>
                  <td className="py-3 px-4 font-sans font-semibold text-slate-100 flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                    <span>{row.team}</span>
                    <span className="text-xs text-slate-500 font-mono">({row.teamCode})</span>
                  </td>
                  <td className="py-3 px-3 text-right tabular-nums text-slate-300">
                    {row.played}
                  </td>
                  <td className="py-3 px-3 text-right tabular-nums font-semibold text-white">
                    {row.won}
                  </td>
                  <td className="py-3 px-3 text-right tabular-nums text-slate-400">
                    {row.lost}
                  </td>
                  <td className="py-3 px-3 text-right tabular-nums text-slate-400">
                    {row.tied}
                  </td>
                  <td className="py-3 px-3 text-right tabular-nums text-slate-400">
                    {row.noResult}
                  </td>
                  <td className="py-3 px-4 text-right tabular-nums font-bold text-emerald-400 text-sm">
                    {row.points}
                  </td>
                  <td className="py-3 px-4 text-right tabular-nums text-slate-300 font-semibold">
                    {row.nrr}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
