import React, { useState, useEffect } from 'react';
import { CricketTeam } from '../types/cricket';
import { cricketApi } from '../services/cricketApi';
import { TeamCard } from './TeamCard';
import { Shield } from 'lucide-react';

interface TeamsListProps {
  onSelectTeam?: (teamName: string) => void;
}

export const TeamsList: React.FC<TeamsListProps> = ({ onSelectTeam }) => {
  const [teams, setTeams] = useState<CricketTeam[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [categoryFilter, setCategoryFilter] = useState<"Men's" | "Women's" | 'All'>('All');

  useEffect(() => {
    loadTeams();
  }, [categoryFilter]);

  const loadTeams = async () => {
    setLoading(true);
    try {
      const data = await cricketApi.getTeams(categoryFilter);
      setTeams(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Shield className="w-6 h-6 text-emerald-400" />
            <h1 className="text-2xl font-bold tracking-tight text-white font-['Cabinet_Grotesk']">
              Cricket Teams & Squads
            </h1>
          </div>
          <p className="text-xs text-slate-400">
            Current international rankings, domestic clubs, and head-to-head performance
          </p>
        </div>

        {/* Category switcher */}
        <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-lg border border-slate-800 text-xs self-start">
          <button
            onClick={() => setCategoryFilter('All')}
            className={`px-3 py-1 rounded transition-colors ${
              categoryFilter === 'All' ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            All Teams
          </button>
          <button
            onClick={() => setCategoryFilter("Men's")}
            className={`px-3 py-1 rounded transition-colors ${
              categoryFilter === "Men's" ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Men's Teams
          </button>
          <button
            onClick={() => setCategoryFilter("Women's")}
            className={`px-3 py-1 rounded transition-colors ${
              categoryFilter === "Women's" ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Women's Teams
          </button>
        </div>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="h-60 bg-slate-900/50 border border-slate-800 rounded-xl animate-pulse" />
          ))}
        </div>
      ) : teams.length === 0 ? (
        <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-12 text-center text-slate-400">
          No teams available for the selected filter.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {teams.map(team => (
            <TeamCard key={team.id} team={team} onViewSquad={onSelectTeam} />
          ))}
        </div>
      )}

    </div>
  );
};
