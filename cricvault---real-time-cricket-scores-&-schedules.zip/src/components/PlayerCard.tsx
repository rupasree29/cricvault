import React from 'react';
import { CricketPlayer } from '../types/cricket';
import { Shield, Award, Crown } from 'lucide-react';

interface PlayerCardProps {
  player: CricketPlayer;
  activeFormat?: 'Test' | 'ODI' | 'T20';
  onSelectPlayer?: (player: CricketPlayer) => void;
}

export const PlayerCard: React.FC<PlayerCardProps> = ({
  player,
  activeFormat = 'ODI',
  onSelectPlayer
}) => {
  const formatKey = activeFormat.toLowerCase() as 'test' | 'odi' | 't20';
  const formatStats = player.stats[formatKey];

  return (
    <div
      onClick={() => onSelectPlayer && onSelectPlayer(player)}
      className="bg-slate-900/70 border border-slate-800 rounded-xl p-4 hover:border-emerald-500/50 hover:bg-slate-900/90 transition-all flex flex-col justify-between group cursor-pointer shadow-md relative overflow-hidden"
    >
      <div>
        {/* Top Badges (Captain / Vice Captain) */}
        {(player.captainFormat || player.isCaptain || player.isViceCaptain) && (
          <div className="mb-2.5 flex items-center gap-1.5 flex-wrap">
            {player.captainFormat ? (
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/15 text-amber-300 border border-amber-500/40 shadow-xs">
                <Crown className="w-3 h-3 text-amber-400" />
                {player.captainFormat}
              </span>
            ) : player.isCaptain ? (
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/15 text-amber-300 border border-amber-500/40 shadow-xs">
                <Crown className="w-3 h-3 text-amber-400" />
                Captain
              </span>
            ) : null}

            {player.isViceCaptain && !player.captainFormat && (
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-sky-500/15 text-sky-300 border border-sky-500/40">
                <Award className="w-3 h-3 text-sky-400" />
                Vice-Captain
              </span>
            )}
          </div>
        )}

        {/* Player Header with Initials badge and Team */}
        <div className="flex items-start gap-3 mb-3">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-slate-800 to-slate-900 border border-slate-700 flex items-center justify-center text-emerald-400 font-black text-base shadow-sm group-hover:border-emerald-500/60 transition-colors shrink-0">
            {player.name.split(' ').map(n => n[0]).join('').slice(0, 2)}
          </div>

          <div className="flex-1 min-w-0">
            <h3 className="font-bold text-slate-100 text-sm group-hover:text-emerald-400 transition-colors truncate">
              {player.name}
            </h3>
            <div className="flex items-center gap-1.5 text-xs text-slate-400 mt-0.5">
              <span className="font-medium text-slate-300">{player.country}</span>
              <span className="text-slate-600">·</span>
              <span className="text-emerald-400 font-medium">{player.role}</span>
            </div>
            {player.team !== player.country && (
              <div className="text-[11px] text-slate-500 mt-0.5 truncate">
                {player.team}
              </div>
            )}
          </div>
        </div>

        {/* Styles info */}
        <div className="bg-slate-950/60 p-2.5 rounded-lg border border-slate-800/80 space-y-1 text-xs mb-3 font-mono">
          <div className="flex items-center justify-between text-slate-400">
            <span className="font-sans text-[11px]">Batting:</span>
            <span className="text-slate-200">{player.battingStyle}</span>
          </div>
          <div className="flex items-center justify-between text-slate-400">
            <span className="font-sans text-[11px]">Bowling:</span>
            <span className="text-slate-200 truncate ml-2 text-right">{player.bowlingStyle}</span>
          </div>
        </div>

        {/* Available Formats */}
        <div className="flex items-center gap-1.5 mb-3 text-[10px] font-mono">
          <span className="text-slate-500 font-sans">Formats:</span>
          {player.formats.map((f, i) => (
            <span
              key={i}
              className={`px-1.5 py-0.5 rounded ${
                f === activeFormat ? 'bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/30' : 'bg-slate-800 text-slate-400'
              }`}
            >
              {f}
            </span>
          ))}
        </div>
      </div>

      {/* Selected Format Career Statistics */}
      <div className="border-t border-slate-800/80 pt-2.5">
        <div className="text-[10px] uppercase tracking-wider text-slate-400 mb-1 flex items-center justify-between">
          <span>{activeFormat} Career Stats</span>
          {formatStats && <span className="font-mono">{formatStats.matches} Matches</span>}
        </div>

        {formatStats ? (
          <div className="grid grid-cols-4 gap-1 text-center font-mono text-xs">
            <div className="bg-slate-950/40 p-1.5 rounded border border-slate-800/50">
              <span className="block text-[10px] font-sans text-slate-500">Runs</span>
              <span className="font-bold text-white tabular-nums">{formatStats.runs}</span>
            </div>
            <div className="bg-slate-950/40 p-1.5 rounded border border-slate-800/50">
              <span className="block text-[10px] font-sans text-slate-500">Avg</span>
              <span className="font-bold text-slate-200 tabular-nums">{formatStats.average.toFixed(1)}</span>
            </div>
            <div className="bg-slate-950/40 p-1.5 rounded border border-slate-800/50">
              <span className="block text-[10px] font-sans text-slate-500">SR</span>
              <span className="font-bold text-slate-200 tabular-nums">{formatStats.strikeRate.toFixed(1)}</span>
            </div>
            <div className="bg-slate-950/40 p-1.5 rounded border border-slate-800/50">
              <span className="block text-[10px] font-sans text-slate-500">Wkts</span>
              <span className="font-bold text-emerald-400 tabular-nums">{formatStats.wickets}</span>
            </div>
          </div>
        ) : (
          <div className="text-center py-2 text-xs text-slate-500 italic">
            Data unavailable for {activeFormat}
          </div>
        )}
      </div>

    </div>
  );
};
