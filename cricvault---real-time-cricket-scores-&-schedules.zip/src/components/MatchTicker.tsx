import React from 'react';
import { CricketMatch } from '../types/cricket';

interface MatchTickerProps {
  matches: CricketMatch[];
  selectedMatchId?: string;
  onSelectMatch: (match: CricketMatch) => void;
}

export const MatchTicker: React.FC<MatchTickerProps> = ({
  matches,
  selectedMatchId,
  onSelectMatch
}) => {
  if (!matches.length) return null;

  return (
    <div className="bg-slate-900/90 border-b border-slate-800 text-xs py-2 px-4 overflow-x-auto select-none no-scrollbar">
      <div className="max-w-7xl mx-auto flex items-center gap-3">
        <div className="shrink-0 flex items-center gap-1.5 font-bold uppercase tracking-wider text-[11px] text-slate-400 border-r border-slate-700 pr-3">
          <span className="inline-block w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
          <span>MATCHES</span>
        </div>

        <div className="flex items-center gap-2 overflow-x-auto scroll-smooth">
          {matches.map(m => {
            const isSelected = m.id === selectedMatchId;
            let statusBadge = m.statusNote;
            if (m.status === 'LIVE') {
              statusBadge = `${m.team2.shortName || m.team1.shortName} live`;
            } else if (m.status === 'COMPLETED' && m.resultWinner) {
              statusBadge = `${m.resultWinner} won`;
            } else if (m.status === 'STUMPS') {
              statusBadge = 'Stumps';
            } else if (m.status === 'UPCOMING') {
              statusBadge = 'Preview';
            }

            return (
              <button
                key={m.id}
                onClick={() => onSelectMatch(m)}
                className={`shrink-0 flex items-center gap-2 px-3 py-1.5 rounded border transition-all text-left cursor-pointer ${
                  isSelected
                    ? 'bg-slate-800 border-emerald-500 text-white shadow-sm'
                    : 'bg-slate-950/60 border-slate-800/80 text-slate-300 hover:border-slate-700 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-1.5 font-medium">
                  {m.status === 'LIVE' && (
                    <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-ping" />
                  )}
                  <span>{m.team1.shortName} vs {m.team2.shortName}</span>
                </div>
                <span className="text-slate-500">·</span>
                <span className={`text-[11px] font-mono ${
                  m.status === 'LIVE' ? 'text-emerald-400 font-semibold' : 'text-slate-400'
                }`}>
                  {statusBadge}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
