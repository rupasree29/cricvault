import React, { useState } from 'react';
import { CricketMatch, MatchCategory, MatchFormat } from '../types/cricket';
import { Calendar, MapPin, ChevronRight, Clock } from 'lucide-react';
import { formatDisplayDate } from '../services/cricketDatabase';

interface TodayMatchesProps {
  matches: CricketMatch[];
  onViewScorecard: (match: CricketMatch) => void;
}

export const TodayMatches: React.FC<TodayMatchesProps> = ({
  matches,
  onViewScorecard
}) => {
  const [formatFilter, setFormatFilter] = useState<string>('ALL');
  const [categoryFilter, setCategoryFilter] = useState<string>('ALL');

  const todayFormatted = formatDisplayDate(new Date());

  const filteredMatches = matches.filter(m => {
    if (formatFilter !== 'ALL' && m.format !== formatFilter) return false;
    if (categoryFilter !== 'ALL' && m.category !== categoryFilter) return false;
    return true;
  });

  return (
    <section className="mb-10">
      
      {/* Section Header with dynamic current date */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
        <div>
          <div className="flex items-center gap-2">
            <Calendar className="w-5 h-5 text-emerald-400" />
            <h2 className="text-xl font-bold tracking-tight text-white font-['Cabinet_Grotesk']">
              Today's Cricket Matches
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Dynamic Schedule for <span className="text-emerald-400 font-semibold">{todayFormatted}</span>
          </p>
        </div>

        {/* Interactive Filter Controls */}
        <div className="flex flex-wrap items-center gap-1.5 bg-slate-900/90 p-1 rounded-lg border border-slate-800 text-xs">
          <button
            onClick={() => setFormatFilter('ALL')}
            className={`px-2.5 py-1 rounded transition-colors ${
              formatFilter === 'ALL' ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            All Formats
          </button>
          <button
            onClick={() => setFormatFilter('ODI')}
            className={`px-2.5 py-1 rounded transition-colors ${
              formatFilter === 'ODI' ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            ODI
          </button>
          <button
            onClick={() => setFormatFilter('Test')}
            className={`px-2.5 py-1 rounded transition-colors ${
              formatFilter === 'Test' ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Test
          </button>
          <button
            onClick={() => setFormatFilter('T20')}
            className={`px-2.5 py-1 rounded transition-colors ${
              formatFilter === 'T20' ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            T20
          </button>
          <button
            onClick={() => setFormatFilter('Domestic')}
            className={`px-2.5 py-1 rounded transition-colors ${
              formatFilter === 'Domestic' ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Domestic
          </button>
        </div>
      </div>

      {filteredMatches.length === 0 ? (
        <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-8 text-center">
          <Clock className="w-8 h-8 text-slate-600 mx-auto mb-2" />
          <p className="text-slate-300 font-medium text-sm">No matches scheduled.</p>
          <p className="text-xs text-slate-500 mt-1">No fixtures match your selected filter criteria for today.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredMatches.map(match => (
            <div
              key={match.id}
              className="bg-slate-900/70 border border-slate-800 rounded-lg p-4 hover:border-slate-700 transition-all flex flex-col justify-between"
            >
              <div>
                {/* Match Tournament & Status Header */}
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div className="truncate">
                    <span className="text-[11px] font-semibold text-emerald-400 uppercase tracking-wider block truncate">
                      {match.series}
                    </span>
                    <span className="text-xs text-slate-400">
                      {match.matchTitle}
                    </span>
                  </div>
                  <span className={`text-[10px] font-mono font-semibold px-2 py-0.5 rounded shrink-0 ${
                    match.status === 'LIVE'
                      ? 'bg-red-950/80 border border-red-800 text-red-400'
                      : match.status === 'STUMPS'
                      ? 'bg-amber-950/80 border border-amber-800 text-amber-300'
                      : match.status === 'COMPLETED'
                      ? 'bg-slate-800 text-slate-300'
                      : 'bg-emerald-950/60 border border-emerald-800 text-emerald-300'
                  }`}>
                    {match.status}
                  </span>
                </div>

                {/* Teams & Scores */}
                <div className="space-y-2 py-2 border-y border-slate-800/80 my-2">
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-2">
                      <div
                        className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold text-white"
                        style={{ backgroundColor: match.team1.flagColor || '#334155' }}
                      >
                        {match.team1.code.slice(0, 3)}
                      </div>
                      <span className="font-semibold text-slate-200">{match.team1.name}</span>
                    </div>
                    <span className="font-mono tabular-nums font-bold text-slate-200 text-xs">
                      {match.team1.score || '—'}
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-2">
                      <div
                        className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold text-white"
                        style={{ backgroundColor: match.team2.flagColor || '#334155' }}
                      >
                        {match.team2.code.slice(0, 3)}
                      </div>
                      <span className="font-semibold text-slate-200">{match.team2.name}</span>
                    </div>
                    <span className="font-mono tabular-nums font-bold text-emerald-400 text-xs">
                      {match.team2.score || '—'}
                    </span>
                  </div>
                </div>

                {/* Status Note */}
                <p className="text-xs text-amber-300/90 font-medium mb-3">
                  {match.statusNote}
                </p>
              </div>

              {/* Match Meta & Action */}
              <div className="pt-2 border-t border-slate-800/60 flex items-center justify-between text-[11px] text-slate-400">
                <div className="flex items-center gap-1.5 truncate max-w-[65%]">
                  <MapPin className="w-3 h-3 text-slate-500 shrink-0" />
                  <span className="truncate">{match.venue}</span>
                </div>
                <button
                  onClick={() => onViewScorecard(match)}
                  className="text-emerald-400 hover:text-emerald-300 font-medium flex items-center gap-0.5 cursor-pointer shrink-0"
                >
                  <span>Details</span>
                  <ChevronRight className="w-3 h-3" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </section>
  );
};
