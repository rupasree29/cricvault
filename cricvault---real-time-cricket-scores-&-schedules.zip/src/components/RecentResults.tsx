import React from 'react';
import { CricketMatch } from '../types/cricket';
import { CheckCircle, Award, MapPin, ChevronRight } from 'lucide-react';

interface RecentResultsProps {
  matches: CricketMatch[];
  onViewScorecard: (match: CricketMatch) => void;
}

export const RecentResults: React.FC<RecentResultsProps> = ({
  matches,
  onViewScorecard
}) => {
  return (
    <section className="mb-10">
      <div className="flex items-center gap-2 mb-4">
        <CheckCircle className="w-5 h-5 text-emerald-400" />
        <h2 className="text-xl font-bold tracking-tight text-white font-['Cabinet_Grotesk']">
          Recent Results
        </h2>
      </div>

      {matches.length === 0 ? (
        <div className="bg-slate-900/40 border border-slate-800 rounded-lg p-6 text-center text-slate-400 text-xs">
          No recent results found.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {matches.map(match => (
            <div
              key={match.id}
              className="bg-slate-900/70 border border-slate-800 rounded-lg p-4 hover:border-slate-700 transition-all flex flex-col justify-between"
            >
              <div>
                {/* Header */}
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div className="truncate">
                    <span className="text-[11px] font-semibold text-emerald-400 uppercase tracking-wider block truncate">
                      {match.series}
                    </span>
                    <span className="text-xs text-slate-300 font-medium">
                      {match.matchTitle}
                    </span>
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300 shrink-0">
                    {match.format}
                  </span>
                </div>

                {/* Teams & Scores */}
                <div className="space-y-2 py-2 border-y border-slate-800/60 my-2">
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-2">
                      <div
                        className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold text-white"
                        style={{ backgroundColor: match.team1.flagColor || '#334155' }}
                      >
                        {match.team1.code.slice(0, 3)}
                      </div>
                      <span className={`font-semibold ${match.resultWinner === match.team1.name ? 'text-white' : 'text-slate-400'}`}>
                        {match.team1.name}
                      </span>
                    </div>
                    <span className="font-mono tabular-nums font-bold text-slate-200 text-xs">
                      {match.team1.score || '—'}
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-2">
                      <div
                        className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold text-white"
                        style={{ backgroundColor: match.team2.flagColor || '#334155' }}
                      >
                        {match.team2.code.slice(0, 3)}
                      </div>
                      <span className={`font-semibold ${match.resultWinner === match.team2.name ? 'text-white' : 'text-slate-400'}`}>
                        {match.team2.name}
                      </span>
                    </div>
                    <span className="font-mono tabular-nums font-bold text-slate-200 text-xs">
                      {match.team2.score || '—'}
                    </span>
                  </div>
                </div>

                {/* Result Note */}
                <div className="text-xs font-semibold text-emerald-400 mb-2">
                  {match.statusNote}
                </div>

                {/* Player of the Match */}
                {match.playerOfTheMatch && (
                  <div className="flex items-center gap-1.5 text-xs text-amber-300/90 bg-amber-500/5 px-2.5 py-1 rounded border border-amber-500/10 mb-3">
                    <Award className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                    <span className="truncate">POTM: {match.playerOfTheMatch}</span>
                  </div>
                )}
              </div>

              {/* Venue & Action */}
              <div className="pt-2 border-t border-slate-800/60 flex items-center justify-between text-[11px] text-slate-400">
                <div className="flex items-center gap-1.5 truncate max-w-[65%]">
                  <MapPin className="w-3 h-3 text-slate-500 shrink-0" />
                  <span className="truncate">{match.venue}, {match.city}</span>
                </div>
                <button
                  onClick={() => onViewScorecard(match)}
                  className="text-emerald-400 hover:text-emerald-300 font-medium flex items-center gap-0.5 cursor-pointer"
                >
                  <span>Scorecard</span>
                  <ChevronRight className="w-3 h-3" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </section>
  );
};
