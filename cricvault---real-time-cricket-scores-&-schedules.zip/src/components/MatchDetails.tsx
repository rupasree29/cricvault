import React, { useState } from 'react';
import { CricketMatch } from '../types/cricket';
import { Scoreboard } from './Scoreboard';
import { X, MapPin, Calendar, Clock, Trophy, Award, Radio } from 'lucide-react';

interface MatchDetailsProps {
  match: CricketMatch;
  onClose: () => void;
}

export const MatchDetails: React.FC<MatchDetailsProps> = ({ match, onClose }) => {
  const [activeTab, setActiveTab] = useState<'scorecard' | 'info'>('scorecard');

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="bg-slate-950 p-5 border-b border-slate-800 flex items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-bold text-emerald-400 uppercase tracking-wide">
                {match.series}
              </span>
              <span className="text-slate-600">·</span>
              <span className="text-xs text-slate-400">{match.matchTitle}</span>
              <span className="text-slate-600">·</span>
              <span className="text-xs text-slate-400">{match.format}</span>
              {match.status === 'LIVE' && (
                <span className="flex items-center gap-1 text-[11px] font-bold text-red-400 bg-red-950/80 border border-red-800/80 px-2 py-0.5 rounded-full ml-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-ping" />
                  LIVE
                </span>
              )}
            </div>

            <h2 className="text-lg sm:text-xl font-bold text-white font-['Cabinet_Grotesk']">
              {match.team1.name} vs {match.team2.name}
            </h2>
            <div className="text-xs text-amber-300 font-medium mt-1">
              {match.statusNote}
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-lg bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Match Navigation Subtabs */}
        <div className="bg-slate-950/60 border-b border-slate-800 px-5 flex items-center gap-4 text-xs font-semibold">
          <button
            onClick={() => setActiveTab('scorecard')}
            className={`py-3 border-b-2 transition-colors cursor-pointer ${
              activeTab === 'scorecard'
                ? 'border-emerald-400 text-emerald-400 font-bold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Full Scorecard
          </button>
          <button
            onClick={() => setActiveTab('info')}
            className={`py-3 border-b-2 transition-colors cursor-pointer ${
              activeTab === 'info'
                ? 'border-emerald-400 text-emerald-400 font-bold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Match Information
          </button>
        </div>

        {/* Modal Body Content */}
        <div className="p-5 overflow-y-auto flex-1 space-y-6">
          {activeTab === 'scorecard' ? (
            <Scoreboard match={match} />
          ) : (
            <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-4 text-sm">
              <h3 className="text-base font-bold text-white font-['Cabinet_Grotesk'] border-b border-slate-800 pb-2">
                Match Details & Conditions
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                <div>
                  <span className="text-slate-400 block text-[11px]">Tournament / Series:</span>
                  <span className="font-semibold text-slate-200">{match.series}</span>
                </div>

                <div>
                  <span className="text-slate-400 block text-[11px]">Match Format:</span>
                  <span className="font-semibold text-slate-200">{match.format} ({match.category})</span>
                </div>

                <div>
                  <span className="text-slate-400 block text-[11px]">Venue & Ground:</span>
                  <span className="font-semibold text-slate-200">{match.venue}, {match.city}, {match.country}</span>
                </div>

                <div>
                  <span className="text-slate-400 block text-[11px]">Match Scheduled Time:</span>
                  <span className="font-semibold text-slate-200">{match.timeStr} ({match.gmtTime})</span>
                </div>

                <div>
                  <span className="text-slate-400 block text-[11px]">Toss:</span>
                  <span className="font-semibold text-slate-200">{match.tossText || 'Toss yet to take place'}</span>
                </div>

                <div>
                  <span className="text-slate-400 block text-[11px]">Current Status:</span>
                  <span className="font-semibold text-emerald-400">{match.status} - {match.statusNote}</span>
                </div>

                {match.playerOfTheMatch && (
                  <div>
                    <span className="text-slate-400 block text-[11px]">Player of the Match:</span>
                    <span className="font-semibold text-amber-300">{match.playerOfTheMatch}</span>
                  </div>
                )}

                <div>
                  <span className="text-slate-400 block text-[11px]">Winning Probability:</span>
                  <span className="font-semibold text-slate-200">
                    {match.winningProbability
                      ? `${match.team1.shortName}: ${match.winningProbability.team1}% | ${match.team2.shortName}: ${match.winningProbability.team2}%`
                      : 'Winning probability unavailable'}
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
