import React, { useState, useEffect } from 'react';
import { CricketPlayer } from '../types/cricket';
import { cricketApi } from '../services/cricketApi';
import { PlayerCard } from './PlayerCard';
import { Users, Search, Filter, Crown, Shield, Globe, Award } from 'lucide-react';

interface CountryTab {
  name: string;
  code: string;
  flag: string;
  color: string;
  caption?: string;
  highlights?: string;
}

const COUNTRIES: CountryTab[] = [
  { name: 'All', code: 'ALL', flag: '🌍', color: '#10B981', caption: 'All Rosters' },
  { name: 'India', code: 'IND', flag: '🇮🇳', color: '#0055A5', caption: 'ODI Capt: Shubman Gill · Test Capt: Rohit Sharma', highlights: 'ODI Capt: Shubman Gill | Test Capt: Rohit Sharma | T20I Capt: Suryakumar Yadav | Star All-Rounder: Nitish Kumar Reddy' },
  { name: 'Australia', code: 'AUS', flag: '🇦🇺', color: '#006400', caption: 'Capt: Pat Cummins & Mitch Marsh', highlights: 'Test & ODI Capt: Pat Cummins | T20I Capt: Mitchell Marsh | Key Stars: Travis Head, Glenn Maxwell' },
  { name: 'South Africa', code: 'RSA', flag: '🇿🇦', color: '#006633', caption: 'Capt: Temba Bavuma & Aiden Markram', highlights: 'Test & ODI Capt: Temba Bavuma | T20I Capt: Aiden Markram | Key Stars: Heinrich Klaasen, Kagiso Rabada' },
  { name: 'England', code: 'ENG', flag: '🏴󠁧󠁢󠁥󠁮󠁧󠁿', color: '#002B49', caption: 'Capt: Ben Stokes & Jos Buttler', highlights: 'Test Capt: Ben Stokes | ODI & T20I Capt: Jos Buttler | Key Stars: Joe Root, Harry Brook' },
  { name: 'New Zealand', code: 'NZ', flag: '🇳🇿', color: '#111111', caption: 'Capt: Tom Latham & Mitch Santner', highlights: 'Test Capt: Tom Latham | White-Ball Capt: Mitchell Santner | Key Star: Kane Williamson' },
  { name: 'Pakistan', code: 'PAK', flag: '🇵🇰', color: '#01411C', caption: 'Capt: Mohammad Rizwan & Shan Masood', highlights: 'ODI/T20 Capt: Mohammad Rizwan | Test Capt: Shan Masood | Key Stars: Babar Azam, Shaheen Afridi' },
  { name: 'West Indies', code: 'WI', flag: '🌴', color: '#7B003A', caption: 'Capt: Shai Hope & Rovman Powell', highlights: 'ODI Capt: Shai Hope | T20I Capt: Rovman Powell | Key Star: Nicholas Pooran' },
  { name: 'Sri Lanka', code: 'SL', flag: '🇱🇰', color: '#0C2340', caption: 'Capt: Charith Asalanka', highlights: 'ODI & T20I Capt: Charith Asalanka | Key Stars: Wanindu Hasaranga, Pathum Nissanka' },
  { name: 'Afghanistan', code: 'AFG', flag: '🇦🇫', color: '#007A3D', caption: 'Capt: Rashid Khan', highlights: 'T20I Capt: Rashid Khan | Key Stars: Rahmanullah Gurbaz, Mohammad Nabi' },
  { name: 'Bangladesh', code: 'BAN', flag: '🇧🇩', color: '#006A4E', caption: 'Capt: Najmul Hossain Shanto', highlights: 'All-Format Capt: Najmul Hossain Shanto | Key Stars: Litton Das, Taskin Ahmed' },
];

interface PlayerListProps {
  initialCountry?: string;
}

export const PlayerList: React.FC<PlayerListProps> = ({ initialCountry = 'All' }) => {
  const [selectedCountry, setSelectedCountry] = useState<string>(initialCountry);
  const [players, setPlayers] = useState<CricketPlayer[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [categoryFilter, setCategoryFilter] = useState<"Men's" | "Women's" | 'All'>('All');
  const [formatFilter, setFormatFilter] = useState<'Test' | 'ODI' | 'T20' | 'All'>('All');
  const [roleFilter, setRoleFilter] = useState<'All' | 'Batter' | 'Bowler' | 'All-Rounder' | 'Wicketkeeper'>('All');

  useEffect(() => {
    if (initialCountry && initialCountry !== selectedCountry) {
      setSelectedCountry(initialCountry);
    }
  }, [initialCountry]);

  useEffect(() => {
    loadPlayers();
  }, [selectedCountry, categoryFilter, formatFilter, roleFilter, searchQuery]);

  const loadPlayers = async () => {
    setLoading(true);
    try {
      const data = await cricketApi.getPlayers({
        country: selectedCountry === 'All' ? undefined : selectedCountry,
        category: categoryFilter,
        format: formatFilter,
        search: searchQuery
      });

      let filtered = data;
      if (roleFilter !== 'All') {
        filtered = filtered.filter(p => p.role === roleFilter);
      }

      setPlayers(filtered);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const currentCountryMeta = COUNTRIES.find(c => c.name === selectedCountry) || COUNTRIES[0];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Users className="w-6 h-6 text-emerald-400" />
            <h1 className="text-2xl font-bold tracking-tight text-white font-['Cabinet_Grotesk']">
              Cricket Players Directory & Squads
            </h1>
          </div>
          <p className="text-xs text-slate-400">
            Real-time player profiles, current international squads, official captains, and career stats
          </p>
        </div>

        {/* Live sync badge */}
        <div className="flex items-center gap-2 bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-lg text-xs self-start md:self-auto">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-slate-300 font-medium">Live Squads & Captaincy Roster</span>
        </div>
      </div>

      {/* Country Selection Tab Bar */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-2.5">
          <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-300 uppercase tracking-wider">
            <Globe className="w-3.5 h-3.5 text-emerald-400" />
            <span>Select Team / Country to View Players</span>
          </div>
          <span className="text-[11px] text-slate-500">
            Click any country for instant squad list
          </span>
        </div>

        {/* Scrollable / wrap country buttons */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-thin scrollbar-thumb-slate-800">
          {COUNTRIES.map(country => {
            const isSelected = selectedCountry === country.name;
            return (
              <button
                key={country.name}
                onClick={() => {
                  setSelectedCountry(country.name);
                  setSearchQuery('');
                }}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold transition-all whitespace-nowrap border shrink-0 cursor-pointer ${
                  isSelected
                    ? 'bg-slate-800 text-white border-emerald-500 shadow-md shadow-emerald-950/40 ring-1 ring-emerald-500/40'
                    : 'bg-slate-900/80 text-slate-300 border-slate-800 hover:border-slate-700 hover:bg-slate-900'
                }`}
              >
                <span className="text-base">{country.flag}</span>
                <span>{country.name}</span>
                {isSelected && (
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 ml-0.5" />
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Selected Country Spotlight Banner */}
      {selectedCountry !== 'All' && (
        <div className="bg-gradient-to-r from-slate-900 via-slate-900/90 to-slate-950 border border-slate-800 rounded-xl p-4 sm:p-5 mb-6 shadow-lg relative overflow-hidden">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
            
            <div className="flex items-start sm:items-center gap-3.5">
              <div
                className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl border border-white/10 shrink-0 shadow-inner"
                style={{ backgroundColor: currentCountryMeta.color + '25' }}
              >
                {currentCountryMeta.flag}
              </div>
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <h2 className="text-lg font-bold text-white font-['Cabinet_Grotesk']">
                    {selectedCountry} National Squad
                  </h2>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                    Active Squad
                  </span>
                </div>
                <p className="text-xs text-slate-400 mt-0.5">
                  {currentCountryMeta.caption}
                </p>
              </div>
            </div>

            {/* Leadership & Star Highlights */}
            {selectedCountry === 'India' && (
              <div className="flex flex-wrap items-center gap-2">
                <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-amber-500/15 text-amber-300 border border-amber-500/30">
                  <Crown className="w-3.5 h-3.5 text-amber-400" />
                  <span>ODI Captain: Shubman Gill</span>
                </div>
                <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-blue-500/15 text-blue-300 border border-blue-500/30">
                  <span>Test Captain: Rohit Sharma</span>
                </div>
                <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-purple-500/15 text-purple-300 border border-purple-500/30">
                  <span>T20I Captain: Suryakumar Yadav</span>
                </div>
                <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
                  <Award className="w-3.5 h-3.5 text-emerald-400" />
                  <span>All-Rounder: Nitish Kumar Reddy</span>
                </div>
              </div>
            )}

            {selectedCountry === 'Australia' && (
              <div className="flex flex-wrap items-center gap-2">
                <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-amber-500/15 text-amber-300 border border-amber-500/30">
                  <Crown className="w-3.5 h-3.5 text-amber-400" />
                  <span>Test & ODI Captain: Pat Cummins</span>
                </div>
                <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
                  <span>T20I Captain: Mitchell Marsh</span>
                </div>
              </div>
            )}

            {selectedCountry === 'South Africa' && (
              <div className="flex flex-wrap items-center gap-2">
                <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-amber-500/15 text-amber-300 border border-amber-500/30">
                  <Crown className="w-3.5 h-3.5 text-amber-400" />
                  <span>Test & ODI Captain: Temba Bavuma</span>
                </div>
                <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
                  <span>T20I Captain: Aiden Markram</span>
                </div>
              </div>
            )}

            {selectedCountry === 'England' && (
              <div className="flex flex-wrap items-center gap-2">
                <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-amber-500/15 text-amber-300 border border-amber-500/30">
                  <Crown className="w-3.5 h-3.5 text-amber-400" />
                  <span>Test Captain: Ben Stokes</span>
                </div>
                <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-sky-500/15 text-sky-300 border border-sky-500/30">
                  <span>ODI & T20I Captain: Jos Buttler</span>
                </div>
              </div>
            )}

            {selectedCountry !== 'India' && selectedCountry !== 'Australia' && selectedCountry !== 'South Africa' && selectedCountry !== 'England' && (
              <div className="text-xs text-slate-300 bg-slate-950/60 px-3 py-1.5 rounded-lg border border-slate-800">
                {currentCountryMeta.highlights}
              </div>
            )}

          </div>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 mb-6 flex flex-col lg:flex-row items-center justify-between gap-4">
        
        {/* Search input */}
        <div className="relative w-full lg:w-80">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by player name or style..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-emerald-500"
          />
        </div>

        {/* Role Filters */}
        <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs overflow-x-auto w-full lg:w-auto">
          {(['All', 'Batter', 'All-Rounder', 'Bowler', 'Wicketkeeper'] as const).map(role => (
            <button
              key={role}
              onClick={() => setRoleFilter(role)}
              className={`px-2.5 py-1 rounded transition-colors whitespace-nowrap ${
                roleFilter === role ? 'bg-slate-800 text-emerald-400 font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {role === 'All' ? 'All Roles' : `${role}s`}
            </button>
          ))}
        </div>

        {/* Category filters (Men's / Women's) & Format filters */}
        <div className="flex flex-wrap items-center gap-2 w-full lg:w-auto justify-end">
          <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs">
            <button
              onClick={() => setCategoryFilter('All')}
              className={`px-3 py-1 rounded transition-colors ${
                categoryFilter === 'All' ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              All
            </button>
            <button
              onClick={() => setCategoryFilter("Men's")}
              className={`px-3 py-1 rounded transition-colors ${
                categoryFilter === "Men's" ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Men's
            </button>
            <button
              onClick={() => setCategoryFilter("Women's")}
              className={`px-3 py-1 rounded transition-colors ${
                categoryFilter === "Women's" ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Women's
            </button>
          </div>

          {/* Format filters (Test / ODI / T20) */}
          <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs">
            <button
              onClick={() => setFormatFilter('All')}
              className={`px-2.5 py-1 rounded transition-colors ${
                formatFilter === 'All' ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              All Formats
            </button>
            <button
              onClick={() => setFormatFilter('Test')}
              className={`px-2.5 py-1 rounded transition-colors ${
                formatFilter === 'Test' ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Test
            </button>
            <button
              onClick={() => setFormatFilter('ODI')}
              className={`px-2.5 py-1 rounded transition-colors ${
                formatFilter === 'ODI' ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              ODI
            </button>
            <button
              onClick={() => setFormatFilter('T20')}
              className={`px-2.5 py-1 rounded transition-colors ${
                formatFilter === 'T20' ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              T20
            </button>
          </div>
        </div>

      </div>

      {/* Results Header Count */}
      <div className="flex items-center justify-between text-xs text-slate-400 mb-4 px-1">
        <span>
          Showing <strong className="text-white">{players.length}</strong> players
          {selectedCountry !== 'All' && <span> for <strong>{selectedCountry}</strong></span>}
          {roleFilter !== 'All' && <span> ({roleFilter}s)</span>}
        </span>
        {selectedCountry !== 'All' && (
          <button
            onClick={() => setSelectedCountry('All')}
            className="text-emerald-400 hover:underline cursor-pointer"
          >
            Clear Country Filter
          </button>
        )}
      </div>

      {/* Players Grid */}
      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {[...Array(8)].map((_, i) => (
            <div key={i} className="h-64 bg-slate-900/50 border border-slate-800 rounded-xl animate-pulse" />
          ))}
        </div>
      ) : players.length === 0 ? (
        <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-12 text-center">
          <Users className="w-10 h-10 text-slate-600 mx-auto mb-3" />
          <p className="text-slate-300 font-medium">No players found.</p>
          <p className="text-xs text-slate-500 mt-1">Try adjusting your filters or selecting a different country.</p>
          {selectedCountry !== 'All' && (
            <button
              onClick={() => setSelectedCountry('All')}
              className="mt-4 px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs font-semibold cursor-pointer"
            >
              View All International Players
            </button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {players.map(player => (
            <PlayerCard
              key={player.id}
              player={player}
              activeFormat={formatFilter === 'All' ? 'ODI' : formatFilter}
            />
          ))}
        </div>
      )}

    </div>
  );
};

