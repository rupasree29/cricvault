import React, { useState } from 'react';
import { CricketMatch, InningsScorecard } from '../types/cricket';
import { Users, Target, Activity } from 'lucide-react';

interface ScoreboardProps {
  match: CricketMatch;
}

export const Scoreboard: React.FC<ScoreboardProps> = ({ match }) => {
  const inningsList = match.innings || [];
  const [selectedInningsIdx, setSelectedInningsIdx] = useState<number>(0);

  if (inningsList.length === 0) {
    return (
      <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-8 text-center">
        <Activity className="w-8 h-8 text-slate-600 mx-auto mb-2" />
        <p className="text-slate-300 font-medium">Detailed scorecard data unavailable for this match.</p>
        <p className="text-xs text-slate-500 mt-1">Live match score is currently tracked in summary view.</p>
      </div>
    );
  }

  const currentInnings: InningsScorecard = inningsList[selectedInningsIdx] || inningsList[0];

  return (
    <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5 shadow-xl">
      
      {/* Innings Selector Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-3 mb-5 overflow-x-auto">
        {inningsList.map((inn, idx) => (
          <button
            key={idx}
            onClick={() => setSelectedInningsIdx(idx)}
            className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer whitespace-nowrap ${
              selectedInningsIdx === idx
                ? 'bg-emerald-500 text-slate-950 shadow-md font-bold'
                : 'bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700'
            }`}
          >
            {inn.teamName} Innings ({inn.runs}/{inn.wickets} in {inn.overs} ov)
          </button>
        ))}
      </div>

      {/* Innings Header Summary */}
      <div className="bg-slate-950/80 p-4 rounded-lg border border-slate-800/80 flex flex-wrap items-center justify-between gap-4 mb-6">
        <div>
          <span className="text-xs text-slate-400 block">{currentInnings.teamName} Innings</span>
          <div className="text-2xl font-bold font-mono text-white tabular-nums">
            {currentInnings.runs}/{currentInnings.wickets}
            <span className="text-sm font-normal text-slate-400 ml-2">({currentInnings.overs} Overs)</span>
          </div>
        </div>

        <div className="flex items-center gap-6 text-xs text-slate-300 font-mono">
          <div>
            <span className="text-slate-500 block text-[11px]">Run Rate</span>
            <span className="font-semibold text-slate-200 tabular-nums">
              {(currentInnings.runs / Math.max(1, currentInnings.overs)).toFixed(2)}
            </span>
          </div>
          {currentInnings.extras && (
            <div>
              <span className="text-slate-500 block text-[11px]">Extras</span>
              <span className="font-semibold text-slate-200 tabular-nums">
                {currentInnings.extras.total} (b {currentInnings.extras.byes}, lb {currentInnings.extras.legByes}, w {currentInnings.extras.wides}, nb {currentInnings.extras.noBalls})
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Batting Scorecard Table */}
      <div className="mb-6">
        <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300 mb-2 flex items-center gap-2">
          <span>Batting</span>
        </h4>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 uppercase text-[10px] tracking-wider">
                <th className="py-2.5 px-3">Batter</th>
                <th className="py-2.5 px-3">Dismissal</th>
                <th className="py-2.5 px-3 text-right">R</th>
                <th className="py-2.5 px-3 text-right">B</th>
                <th className="py-2.5 px-3 text-right">4s</th>
                <th className="py-2.5 px-3 text-right">6s</th>
                <th className="py-2.5 px-3 text-right">SR</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {currentInnings.batting.map((batter, idx) => (
                <tr key={idx} className="hover:bg-slate-800/30 transition-colors">
                  <td className="py-2.5 px-3 font-sans font-semibold text-slate-100 flex items-center gap-1.5">
                    <span>{batter.name}</span>
                    {batter.isOnStrike && <span className="text-emerald-400 font-bold">*</span>}
                  </td>
                  <td className="py-2.5 px-3 font-sans text-slate-400 text-[11px]">
                    {batter.dismissal || 'not out'}
                  </td>
                  <td className="py-2.5 px-3 text-right font-bold text-white tabular-nums text-sm">
                    {batter.runs}
                  </td>
                  <td className="py-2.5 px-3 text-right text-slate-300 tabular-nums">
                    {batter.balls}
                  </td>
                  <td className="py-2.5 px-3 text-right text-slate-300 tabular-nums">
                    {batter.fours}
                  </td>
                  <td className="py-2.5 px-3 text-right text-slate-300 tabular-nums">
                    {batter.sixes}
                  </td>
                  <td className="py-2.5 px-3 text-right text-emerald-400 font-medium tabular-nums">
                    {batter.strikeRate.toFixed(1)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Bowling Scorecard Table */}
      <div className="mb-6">
        <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300 mb-2 flex items-center gap-2">
          <span>Bowling</span>
        </h4>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 uppercase text-[10px] tracking-wider">
                <th className="py-2.5 px-3">Bowler</th>
                <th className="py-2.5 px-3 text-right">O</th>
                <th className="py-2.5 px-3 text-right">M</th>
                <th className="py-2.5 px-3 text-right">R</th>
                <th className="py-2.5 px-3 text-right">W</th>
                <th className="py-2.5 px-3 text-right">Econ</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {currentInnings.bowling.map((bowler, idx) => (
                <tr key={idx} className="hover:bg-slate-800/30 transition-colors">
                  <td className="py-2.5 px-3 font-sans font-semibold text-slate-100">
                    {bowler.name}
                  </td>
                  <td className="py-2.5 px-3 text-right text-slate-300 tabular-nums">
                    {bowler.overs.toFixed(1)}
                  </td>
                  <td className="py-2.5 px-3 text-right text-slate-400 tabular-nums">
                    {bowler.maidens}
                  </td>
                  <td className="py-2.5 px-3 text-right text-slate-300 tabular-nums">
                    {bowler.runs}
                  </td>
                  <td className="py-2.5 px-3 text-right font-bold text-emerald-400 tabular-nums text-sm">
                    {bowler.wickets}
                  </td>
                  <td className="py-2.5 px-3 text-right text-slate-300 tabular-nums">
                    {bowler.economy.toFixed(2)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Fall of Wickets */}
      {currentInnings.fallOfWickets && currentInnings.fallOfWickets.length > 0 && (
        <div className="border-t border-slate-800 pt-4">
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
            Fall of Wickets
          </h4>
          <div className="flex flex-wrap gap-2 text-xs font-mono">
            {currentInnings.fallOfWickets.map((fow, i) => (
              <span
                key={i}
                className="bg-slate-950/60 border border-slate-800 px-2.5 py-1 rounded text-slate-300"
              >
                <span className="text-white font-bold">{fow.score}/{fow.wicket}</span> ({fow.batsman}, {fow.over} ov)
              </span>
            ))}
          </div>
        </div>
      )}

    </div>
  );
};
