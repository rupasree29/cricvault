import React, { useState, useEffect } from 'react';
import { CricketPlayer } from '../types/cricket';
import { cricketApi } from '../services/cricketApi';
import { BarChart2, Award, Zap, Target } from 'lucide-react';

export const Statistics: React.FC = () => {
  const [players, setPlayers] = useState<CricketPlayer[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [selectedFormat, setSelectedFormat] = useState<'Test' | 'ODI' | 'T20'>('ODI');
  const [selectedCategory, setSelectedCategory] = useState<"Men's" | "Women's">("Men's");

  useEffect(() => {
    loadPlayers();
  }, [selectedCategory, selectedFormat]);

  const loadPlayers = async () => {
    setLoading(true);
    try {
      const data = await cricketApi.getPlayers({
        category: selectedCategory,
        format: selectedFormat
      });
      setPlayers(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const formatKey = selectedFormat.toLowerCase() as 'test' | 'odi' | 't20';

  // Sort top run scorers
  const topBatters = [...players]
    .filter(p => p.stats[formatKey]?.runs !== undefined && (p.stats[formatKey]?.runs || 0) > 0)
    .sort((a, b) => (b.stats[formatKey]?.runs || 0) - (a.stats[formatKey]?.runs || 0))
    .slice(0, 5);

  // Sort top wicket takers
  const topBowlers = [...players]
    .filter(p => p.stats[formatKey]?.wickets !== undefined && (p.stats[formatKey]?.wickets || 0) > 0)
    .sort((a, b) => (b.stats[formatKey]?.wickets || 0) - (a.stats[formatKey]?.wickets || 0))
    .slice(0, 5);

  // Sort top strike rates (min 200 runs)
  const topStrikeRates = [...players]
    .filter(p => (p.stats[formatKey]?.runs || 0) > 200)
    .sort((a, b) => (b.stats[formatKey]?.strikeRate || 0) - (a.stats[formatKey]?.strikeRate || 0))
    .slice(0, 5);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <BarChart2 className="w-6 h-6 text-emerald-400" />
            <h1 className="text-2xl font-bold tracking-tight text-white font-['Cabinet_Grotesk']">
              Cricket Statistics & Records
            </h1>
          </div>
          <p className="text-xs text-slate-400">
            Batting leaders, bowling aggregates, averages, and strike rates
          </p>
        </div>

        {/* Filter Switchers */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Gender */}
          <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-lg border border-slate-800 text-xs">
            <button
              onClick={() => setSelectedCategory("Men's")}
              className={`px-3 py-1 rounded transition-colors ${
                selectedCategory === "Men's" ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Men's
            </button>
            <button
              onClick={() => setSelectedCategory("Women's")}
              className={`px-3 py-1 rounded transition-colors ${
                selectedCategory === "Women's" ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Women's
            </button>
          </div>

          {/* Format */}
          <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-lg border border-slate-800 text-xs">
            {(['Test', 'ODI', 'T20'] as const).map(fmt => (
              <button
                key={fmt}
                onClick={() => setSelectedFormat(fmt)}
                className={`px-3 py-1 rounded transition-colors ${
                  selectedFormat === fmt ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {fmt}
              </button>
            ))}
          </div>
        </div>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="h-64 bg-slate-900/50 border border-slate-800 rounded-xl animate-pulse" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          
          {/* Leading Run Scorers */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5 shadow-lg">
            <div className="flex items-center gap-2 mb-4 border-b border-slate-800 pb-3">
              <Award className="w-5 h-5 text-amber-400" />
              <h2 className="font-bold text-slate-100 text-sm font-['Cabinet_Grotesk']">
                Most Runs ({selectedFormat})
              </h2>
            </div>

            {topBatters.length === 0 ? (
              <div className="py-8 text-center text-slate-500 text-xs italic">
                Data unavailable
              </div>
            ) : (
              <div className="space-y-3 font-mono text-xs">
                {topBatters.map((player, idx) => {
                  const stats = player.stats[formatKey];
                  return (
                    <div
                      key={player.id}
                      className="flex items-center justify-between p-2.5 bg-slate-950/60 rounded-lg border border-slate-800/60"
                    >
                      <div className="flex items-center gap-2.5">
                        <span className="w-5 font-bold text-slate-500 text-center">{idx + 1}</span>
                        <div>
                          <span className="font-sans font-semibold text-slate-100 block text-xs">
                            {player.name}
                          </span>
                          <span className="text-[10px] text-slate-500 font-sans">{player.team}</span>
                        </div>
                      </div>
                      <div className="text-right">
                        <span className="font-bold text-emerald-400 text-sm tabular-nums">
                          {stats?.runs}
                        </span>
                        <span className="block text-[10px] text-slate-400">
                          Avg: {stats?.average.toFixed(1)}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Leading Wicket Takers */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5 shadow-lg">
            <div className="flex items-center gap-2 mb-4 border-b border-slate-800 pb-3">
              <Target className="w-5 h-5 text-emerald-400" />
              <h2 className="font-bold text-slate-100 text-sm font-['Cabinet_Grotesk']">
                Top Wicket Takers ({selectedFormat})
              </h2>
            </div>

            {topBowlers.length === 0 ? (
              <div className="py-8 text-center text-slate-500 text-xs italic">
                Data unavailable
              </div>
            ) : (
              <div className="space-y-3 font-mono text-xs">
                {topBowlers.map((player, idx) => {
                  const stats = player.stats[formatKey];
                  return (
                    <div
                      key={player.id}
                      className="flex items-center justify-between p-2.5 bg-slate-950/60 rounded-lg border border-slate-800/60"
                    >
                      <div className="flex items-center gap-2.5">
                        <span className="w-5 font-bold text-slate-500 text-center">{idx + 1}</span>
                        <div>
                          <span className="font-sans font-semibold text-slate-100 block text-xs">
                            {player.name}
                          </span>
                          <span className="text-[10px] text-slate-500 font-sans">{player.team}</span>
                        </div>
                      </div>
                      <div className="text-right">
                        <span className="font-bold text-emerald-400 text-sm tabular-nums">
                          {stats?.wickets} Wkts
                        </span>
                        <span className="block text-[10px] text-slate-400">
                          Avg: {stats?.average.toFixed(1)}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Highest Strike Rates */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5 shadow-lg">
            <div className="flex items-center gap-2 mb-4 border-b border-slate-800 pb-3">
              <Zap className="w-5 h-5 text-teal-400" />
              <h2 className="font-bold text-slate-100 text-sm font-['Cabinet_Grotesk']">
                Highest Strike Rates ({selectedFormat})
              </h2>
            </div>

            {topStrikeRates.length === 0 ? (
              <div className="py-8 text-center text-slate-500 text-xs italic">
                Data unavailable
              </div>
            ) : (
              <div className="space-y-3 font-mono text-xs">
                {topStrikeRates.map((player, idx) => {
                  const stats = player.stats[formatKey];
                  return (
                    <div
                      key={player.id}
                      className="flex items-center justify-between p-2.5 bg-slate-950/60 rounded-lg border border-slate-800/60"
                    >
                      <div className="flex items-center gap-2.5">
                        <span className="w-5 font-bold text-slate-500 text-center">{idx + 1}</span>
                        <div>
                          <span className="font-sans font-semibold text-slate-100 block text-xs">
                            {player.name}
                          </span>
                          <span className="text-[10px] text-slate-500 font-sans">{player.team}</span>
                        </div>
                      </div>
                      <div className="text-right">
                        <span className="font-bold text-teal-400 text-sm tabular-nums">
                          {stats?.strikeRate.toFixed(1)}
                        </span>
                        <span className="block text-[10px] text-slate-400">
                          {stats?.runs} runs
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

        </div>
      )}

    </div>
  );
};
