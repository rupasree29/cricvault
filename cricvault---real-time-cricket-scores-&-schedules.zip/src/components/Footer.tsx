import React from 'react';
import { Radio, Shield, Trophy, Download } from 'lucide-react';

interface FooterProps {
  onSelectTab: (tab: any) => void;
  onOpenDownload?: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onSelectTab, onOpenDownload }) => {
  return (
    <footer className="bg-slate-950 border-t border-slate-900 mt-16 text-slate-400 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-8">
          
          {/* Brand & About */}
          <div className="col-span-2 md:col-span-1">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-6 h-6 rounded bg-emerald-500 flex items-center justify-center text-slate-950 font-black text-xs">
                CV
              </div>
              <span className="text-base font-bold text-white font-['Cabinet_Grotesk'] tracking-tight">
                Cric<span className="text-emerald-400">Vault</span>
              </span>
            </div>
            <p className="text-slate-500 text-[11px] leading-relaxed mb-4">
              Real-time cricket scoreboards, dynamic date-based fixtures, career statistical archives, and tournament standings.
            </p>
            <div className="flex items-center gap-1 text-[11px] text-emerald-400 font-mono">
              <span className="inline-block w-2 h-2 rounded-full bg-emerald-500"></span>
              <span>2026 Active Live Feed</span>
            </div>
          </div>

          {/* Quick Matches & Schedule */}
          <div>
            <h4 className="text-slate-200 font-semibold uppercase tracking-wider text-[11px] mb-3">
              Matches & Tours
            </h4>
            <ul className="space-y-2 text-slate-400 text-xs">
              <li>
                <button onClick={() => onSelectTab('home')} className="hover:text-emerald-400 transition-colors cursor-pointer">
                  Today's Matches
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('home')} className="hover:text-emerald-400 transition-colors cursor-pointer">
                  Live Scores
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('schedule')} className="hover:text-emerald-400 transition-colors cursor-pointer">
                  Tomorrow's Fixtures
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('schedule')} className="hover:text-emerald-400 transition-colors cursor-pointer">
                  International Tours 2026
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('schedule')} className="hover:text-emerald-400 transition-colors cursor-pointer">
                  Domestic Championships
                </button>
              </li>
            </ul>
          </div>

          {/* Standings & Stats */}
          <div>
            <h4 className="text-slate-200 font-semibold uppercase tracking-wider text-[11px] mb-3">
              Standings & Stats
            </h4>
            <ul className="space-y-2 text-slate-400 text-xs">
              <li>
                <button onClick={() => onSelectTab('standings')} className="hover:text-emerald-400 transition-colors cursor-pointer">
                  Points Table
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('standings')} className="hover:text-emerald-400 transition-colors cursor-pointer">
                  ICC World Test Championship
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('teams')} className="hover:text-emerald-400 transition-colors cursor-pointer">
                  Team Rankings
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('players')} className="hover:text-emerald-400 transition-colors cursor-pointer">
                  Players Directory
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('stats')} className="hover:text-emerald-400 transition-colors cursor-pointer">
                  Top Run Scorers & Bowlers
                </button>
              </li>
            </ul>
          </div>

          {/* Company & Platforms */}
          <div>
            <h4 className="text-slate-200 font-semibold uppercase tracking-wider text-[11px] mb-3">
              Mobile & Platforms
            </h4>
            <p className="text-slate-500 text-[11px] mb-3">
              Optimized for mobile viewports with fast tabular updates and ball-by-ball delivery feeds.
            </p>
            <div className="space-y-1.5 text-xs text-slate-400">
              <div>Android / PWA Ready</div>
              <div>iOS Safari Optimized</div>
              <div>Desktop 1440p High-Density</div>
            </div>
          </div>

        </div>

        {/* Bottom Legal bar */}
        <div className="border-t border-slate-900 pt-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-[11px] text-slate-500">
          <div>
            © 2026 CricVault. Built for real-time live cricket sports broadcasting.
          </div>
          <div className="flex items-center gap-4">
            <span className="hover:text-slate-400">Terms of Service</span>
            <span>·</span>
            <span className="hover:text-slate-400">Privacy Policy</span>
            <span>·</span>
            <span className="hover:text-slate-400">Live API Feeds</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
