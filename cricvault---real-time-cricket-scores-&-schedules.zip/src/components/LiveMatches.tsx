import React from 'react';
import { CricketMatch } from '../types/cricket';
import { LiveMatchCard } from './LiveMatchCard';
import { Radio } from 'lucide-react';

interface LiveMatchesProps {
  matches: CricketMatch[];
  onViewScorecard: (match: CricketMatch) => void;
}

export const LiveMatches: React.FC<LiveMatchesProps> = ({
  matches,
  onViewScorecard
}) => {
  const liveList = matches.filter(m => m.status === 'LIVE' || m.isLive);

  return (
    <section className="mb-10">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2.5">
          <div className="w-3 h-3 rounded-full bg-red-500 animate-ping"></div>
          <h2 className="text-xl font-bold tracking-tight text-white font-['Cabinet_Grotesk'] flex items-center gap-2">
            <span>LIVE NOW</span>
            {liveList.length > 0 && (
              <span className="text-xs font-mono px-2 py-0.5 rounded bg-red-950/60 border border-red-800 text-red-300 font-semibold">
                {liveList.length} In Progress
              </span>
            )}
          </h2>
        </div>
      </div>

      {liveList.length === 0 ? (
        <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-8 text-center">
          <Radio className="w-8 h-8 text-slate-600 mx-auto mb-2" />
          <p className="text-slate-400 font-medium text-sm">No live matches currently.</p>
          <p className="text-xs text-slate-500 mt-1">Check today's schedule below for upcoming fixtures.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          {liveList.map(match => (
            <LiveMatchCard
              key={match.id}
              match={match}
              onViewScorecard={onViewScorecard}
            />
          ))}
        </div>
      )}
    </section>
  );
};
