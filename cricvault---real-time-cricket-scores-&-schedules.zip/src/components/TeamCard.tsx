import React from 'react';
import { CricketTeam } from '../types/cricket';
import { Shield, Trophy, TrendingUp } from 'lucide-react';

interface TeamCardProps {
  team: CricketTeam;
  onViewSquad?: (teamName: string) => void;
}

export const TeamCard: React.FC<TeamCardProps> = ({ team, onViewSquad }) => {
  return (
    <div className="bg-slate-900/70 border border-slate-800 rounded-xl p-5 hover:border-emerald-500/50 transition-all flex flex-col justify-between shadow-md">
      <div>
        {/* Team Header */}
        <div className="flex items-center gap-3.5 mb-4">
          <div
            className="w-12 h-12 rounded-xl flex items-center justify-center text-white font-bold text-base shadow-inner border border-white/10"
            style={{ backgroundColor: team.flagColor }}
          >
            {team.code}
          </div>
          <div>
            <h3 className="text-base font-bold text-white font-['Cabinet_Grotesk']">
              {team.name}
            </h3>
            <div className="text-xs text-slate-400">
              {team.category} Cricket Team
            </div>
          </div>
        </div>

        {/* ICC Rankings Bar */}
        {(team.ranking.test || team.ranking.odi || team.ranking.t20) && (
          <div className="bg-slate-950/70 p-2.5 rounded-lg border border-slate-800/80 mb-4">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1.5 flex items-center gap-1">
              <Trophy className="w-3 h-3 text-amber-400" />
              <span>ICC Rankings</span>
            </span>
            <div className="grid grid-cols-3 gap-2 text-center text-xs font-mono">
              <div className="bg-slate-900/60 p-1 rounded border border-slate-800/50">
                <span className="block text-[10px] text-slate-500 font-sans">Test</span>
                <span className="font-bold text-white tabular-nums">
                  {team.ranking.test ? `#${team.ranking.test}` : '—'}
                </span>
              </div>
              <div className="bg-slate-900/60 p-1 rounded border border-slate-800/50">
                <span className="block text-[10px] text-slate-500 font-sans">ODI</span>
                <span className="font-bold text-white tabular-nums">
                  {team.ranking.odi ? `#${team.ranking.odi}` : '—'}
                </span>
              </div>
              <div className="bg-slate-900/60 p-1 rounded border border-slate-800/50">
                <span className="block text-[10px] text-slate-500 font-sans">T20I</span>
                <span className="font-bold text-white tabular-nums">
                  {team.ranking.t20 ? `#${team.ranking.t20}` : '—'}
                </span>
              </div>
            </div>
          </div>
        )}

        {/* Key Squad Players */}
        <div className="mb-4">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1.5">
            Key Players
          </span>
          <div className="flex flex-wrap gap-1.5">
            {team.keyPlayers.map((player, idx) => (
              <span
                key={idx}
                className="bg-slate-800/80 text-slate-300 text-xs px-2 py-0.5 rounded border border-slate-700/60"
              >
                {player}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Career Win Percentage Stats */}
      <div className="border-t border-slate-800/80 pt-3">
        <div className="flex items-center justify-between text-xs text-slate-400 font-mono">
          <span>Overall Matches: <strong className="text-slate-200">{team.stats.played}</strong></span>
          <span className="text-emerald-400 font-bold">{team.stats.winPercentage}% Win Rate</span>
        </div>
        <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden mt-1.5 mb-3">
          <div
            className="h-full bg-emerald-500 rounded-full"
            style={{ width: `${team.stats.winPercentage}%` }}
          />
        </div>

        {onViewSquad && (
          <button
            onClick={() => onViewSquad(team.name.replace(/ Women$/, ''))}
            className="w-full py-2 bg-slate-800 hover:bg-emerald-600 hover:text-slate-950 text-slate-200 rounded-lg text-xs font-semibold transition-all cursor-pointer flex items-center justify-center gap-1.5"
          >
            <span>View {team.name} Players</span>
            <span>→</span>
          </button>
        )}
      </div>

    </div>
  );
};
