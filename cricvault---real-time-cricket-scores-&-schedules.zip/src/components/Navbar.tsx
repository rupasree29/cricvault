import React from 'react';
import { RefreshCw, Radio, Calendar, CalendarDays, Users, Trophy, BarChart2, Shield, Download } from 'lucide-react';

export type NavTab = 'home' | 'tomorrow' | 'schedule' | 'teams' | 'standings' | 'players' | 'stats';

interface NavbarProps {
  currentTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  lastUpdatedTime: string;
  isUpdating: boolean;
  onManualRefresh: () => void;
  autoRefresh: boolean;
  onToggleAutoRefresh: () => void;
  onOpenDownload?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  onSelectTab,
  lastUpdatedTime,
  isUpdating,
  onManualRefresh,
  autoRefresh,
  onToggleAutoRefresh,
  onOpenDownload
}) => {
  return (
    <header className="sticky top-0 z-50 bg-slate-950/95 backdrop-blur-md border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Zone 1: Brand Title */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => onSelectTab('home')}
              className="flex items-center gap-2.5 text-left focus:outline-none group"
            >
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-emerald-500 to-teal-700 flex items-center justify-center text-slate-950 font-black text-lg shadow-sm shadow-emerald-500/20 group-hover:scale-105 transition-transform">
                CV
              </div>
              <div>
                <span className="text-xl font-bold tracking-tight text-white font-['Cabinet_Grotesk']">
                  Cric<span className="text-emerald-400">Vault</span>
                </span>
              </div>
            </button>
          </div>

          {/* Zone 2: Navigation Links */}
          <nav className="hidden md:flex items-center gap-1 text-sm font-medium">
            <button
              onClick={() => onSelectTab('home')}
              className={`px-3.5 py-2 rounded-md transition-colors flex items-center gap-1.5 ${
                currentTab === 'home'
                  ? 'text-emerald-400 bg-slate-900 font-semibold'
                  : 'text-slate-300 hover:text-white hover:bg-slate-900/60'
              }`}
            >
              <Radio className="w-4 h-4" />
              <span>Live & Today</span>
            </button>

            {/* Right next to Live & Today: Tomorrow Schedule */}
            <button
              onClick={() => onSelectTab('tomorrow')}
              className={`px-3.5 py-2 rounded-md transition-colors flex items-center gap-2 ${
                currentTab === 'tomorrow'
                  ? 'text-emerald-400 bg-slate-900 font-semibold'
                  : 'text-slate-300 hover:text-white hover:bg-slate-900/60'
              }`}
            >
              <CalendarDays className="w-4 h-4 text-emerald-400" />
              <span>Tomorrow Schedule</span>
              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                Next 2 Days
              </span>
            </button>

            <button
              onClick={() => onSelectTab('schedule')}
              className={`px-3.5 py-2 rounded-md transition-colors flex items-center gap-1.5 ${
                currentTab === 'schedule'
                  ? 'text-emerald-400 bg-slate-900 font-semibold'
                  : 'text-slate-300 hover:text-white hover:bg-slate-900/60'
              }`}
            >
              <Calendar className="w-4 h-4" />
              <span>Schedule</span>
            </button>

            <button
              onClick={() => onSelectTab('teams')}
              className={`px-3.5 py-2 rounded-md transition-colors flex items-center gap-1.5 ${
                currentTab === 'teams'
                  ? 'text-emerald-400 bg-slate-900 font-semibold'
                  : 'text-slate-300 hover:text-white hover:bg-slate-900/60'
              }`}
            >
              <Shield className="w-4 h-4" />
              <span>Teams</span>
            </button>

            <button
              onClick={() => onSelectTab('standings')}
              className={`px-3.5 py-2 rounded-md transition-colors flex items-center gap-1.5 ${
                currentTab === 'standings'
                  ? 'text-emerald-400 bg-slate-900 font-semibold'
                  : 'text-slate-300 hover:text-white hover:bg-slate-900/60'
              }`}
            >
              <Trophy className="w-4 h-4" />
              <span>Points Table</span>
            </button>

            <button
              onClick={() => onSelectTab('players')}
              className={`px-3.5 py-2 rounded-md transition-colors flex items-center gap-1.5 ${
                currentTab === 'players'
                  ? 'text-emerald-400 bg-slate-900 font-semibold'
                  : 'text-slate-300 hover:text-white hover:bg-slate-900/60'
              }`}
            >
              <Users className="w-4 h-4" />
              <span>Players</span>
            </button>

            <button
              onClick={() => onSelectTab('stats')}
              className={`px-3.5 py-2 rounded-md transition-colors flex items-center gap-1.5 ${
                currentTab === 'stats'
                  ? 'text-emerald-400 bg-slate-900 font-semibold'
                  : 'text-slate-300 hover:text-white hover:bg-slate-900/60'
              }`}
            >
              <BarChart2 className="w-4 h-4" />
              <span>Statistics</span>
            </button>
          </nav>

          {/* Zone 3: Live Sync / Auto Refresh Controls */}
          <div className="flex items-center gap-3">
            <div className="hidden sm:flex flex-col text-right">
              <span className="text-[11px] text-slate-400">
                Last Updated: <span className="font-mono tabular-nums text-slate-200">{lastUpdatedTime}</span>
              </span>
              <button 
                onClick={onToggleAutoRefresh}
                className="text-[10px] text-emerald-400 hover:text-emerald-300 text-right cursor-pointer"
              >
                {autoRefresh ? '● Auto-refresh active' : '○ Auto-refresh paused'}
              </button>
            </div>

            {/* Download ZIP Button */}
            <button
              onClick={onOpenDownload}
              title="Download project as ZIP folder to your desktop"
              className="px-3 py-1.5 rounded-lg bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 hover:bg-emerald-500 hover:text-slate-950 font-medium text-xs transition-all flex items-center gap-1.5 cursor-pointer shadow-sm shadow-emerald-500/10 group"
            >
              <Download className="w-3.5 h-3.5 group-hover:-translate-y-0.5 transition-transform" />
              <span className="hidden sm:inline font-semibold">Download ZIP</span>
              <span className="sm:hidden font-semibold">ZIP</span>
            </button>

            <button
              onClick={onManualRefresh}
              title="Refresh match data"
              disabled={isUpdating}
              className="p-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 hover:text-emerald-400 hover:border-slate-700 transition-colors cursor-pointer disabled:opacity-50"
            >
              <RefreshCw className={`w-4 h-4 ${isUpdating ? 'animate-spin text-emerald-400' : ''}`} />
            </button>
          </div>

        </div>

        {/* Mobile secondary navigation */}
        <div className="md:hidden flex items-center justify-between py-2 border-t border-slate-900 text-xs overflow-x-auto gap-2 no-scrollbar">
          <button
            onClick={() => onSelectTab('home')}
            className={`px-2.5 py-1 rounded whitespace-nowrap ${currentTab === 'home' ? 'bg-slate-800 text-emerald-400 font-semibold' : 'text-slate-400'}`}
          >
            Live & Today
          </button>
          <button
            onClick={() => onSelectTab('tomorrow')}
            className={`px-2.5 py-1 rounded whitespace-nowrap flex items-center gap-1 ${currentTab === 'tomorrow' ? 'bg-slate-800 text-emerald-400 font-bold' : 'text-slate-300'}`}
          >
            <span>Tomorrow Schedule</span>
            <span className="text-[9px] px-1 py-0.2 bg-emerald-500/20 text-emerald-300 rounded">Next 2 Days</span>
          </button>
          <button
            onClick={() => onSelectTab('schedule')}
            className={`px-2.5 py-1 rounded whitespace-nowrap ${currentTab === 'schedule' ? 'bg-slate-800 text-emerald-400' : 'text-slate-400'}`}
          >
            Schedule
          </button>
          <button
            onClick={() => onSelectTab('teams')}
            className={`px-2.5 py-1 rounded whitespace-nowrap ${currentTab === 'teams' ? 'bg-slate-800 text-emerald-400' : 'text-slate-400'}`}
          >
            Teams
          </button>
          <button
            onClick={() => onSelectTab('standings')}
            className={`px-2.5 py-1 rounded whitespace-nowrap ${currentTab === 'standings' ? 'bg-slate-800 text-emerald-400' : 'text-slate-400'}`}
          >
            Standings
          </button>
          <button
            onClick={() => onSelectTab('players')}
            className={`px-2.5 py-1 rounded whitespace-nowrap ${currentTab === 'players' ? 'bg-slate-800 text-emerald-400' : 'text-slate-400'}`}
          >
            Players
          </button>
          <button
            onClick={() => onSelectTab('stats')}
            className={`px-2.5 py-1 rounded whitespace-nowrap ${currentTab === 'stats' ? 'bg-slate-800 text-emerald-400' : 'text-slate-400'}`}
          >
            Stats
          </button>
          <button
            onClick={onOpenDownload}
            className="px-2.5 py-1 rounded whitespace-nowrap bg-emerald-500/20 text-emerald-400 font-semibold border border-emerald-500/30 flex items-center gap-1"
          >
            <Download className="w-3 h-3" />
            <span>Download ZIP</span>
          </button>
        </div>

      </div>
    </header>
  );
};
